/* عامل خدمة BUK: يُظهر إشعارات التذكير على مستوى النظام ويُعيد المستخدم للتطبيق عند الضغط. */

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    (async () => {
      const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      const existing = windows[0];
      if (existing) {
        await existing.focus();
        return;
      }
      await self.clients.openWindow('/mypuki');
    })()
  );
});

/* إشعارات الدفع القادمة من الخادم (تُستخدم لاحقًا للتذكير والتطبيق مغلق). */
self.addEventListener('push', (event) => {
  let payload = {};
  try {
    payload = event.data ? event.data.json() : {};
  } catch {
    payload = {};
  }
  event.waitUntil(
    self.registration.showNotification(payload.title || 'BUK', {
      body: payload.body || 'لديك تذكير',
      tag: payload.tag || 'buk-reminder',
      renotify: true,
      requireInteraction: true,
      vibrate: [900, 300, 900, 300, 900],
      dir: 'rtl',
      lang: 'ar'
    })
  );
});
