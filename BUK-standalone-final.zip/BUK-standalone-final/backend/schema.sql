CREATE TABLE IF NOT EXISTS buk_standalone_accounts (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE,
  phone TEXT UNIQUE,
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS buk_standalone_entities (
  entity_name TEXT NOT NULL,
  id TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY(entity_name, id)
);
CREATE INDEX IF NOT EXISTS buk_standalone_entity_owner_idx ON buk_standalone_entities(entity_name, owner_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS buk_standalone_entity_payload_gin ON buk_standalone_entities USING GIN(payload);

CREATE TABLE IF NOT EXISTS buk_standalone_files (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL,
  public BOOLEAN NOT NULL DEFAULT FALSE,
  original_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_path TEXT NOT NULL,
  size_bytes BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS buk_standalone_files_owner_idx ON buk_standalone_files(owner_id, created_at DESC);

CREATE TABLE IF NOT EXISTS buk_standalone_password_resets (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES buk_standalone_accounts(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
