'use strict';

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const multer = require('multer');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(express.json({ limit: '12mb' }));

const PORT = Number(process.env.PORT || 10000);
const JWT_SECRET = String(process.env.JWT_SECRET || '');
const PUBLIC_APP_URL = String(process.env.PUBLIC_APP_URL || '').replace(/\/$/, '');
const storageRoot = path.resolve(process.env.STORAGE_DIR || path.join(__dirname, 'storage'));
fs.mkdirSync(storageRoot, { recursive: true });
fs.mkdirSync(path.join(storageRoot, '.incoming'), { recursive: true });
const pool = process.env.DATABASE_URL ? new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'false' ? false : (process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined),
  max: Number(process.env.PG_POOL_SIZE || 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
}) : null;

const allowedOrigins = new Set((process.env.FRONTEND_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean));
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && (allowedOrigins.has(origin) || origin === req.headers.host || /^https?:\/\/localhost(:\d+)?$/.test(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: 'draft-8', legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: 'draft-8', legacyHeaders: false });
const upload = multer({
  dest: path.join(storageRoot, '.incoming'),
  limits: { fileSize: Number(process.env.MAX_UPLOAD_MB || 80) * 1024 * 1024, files: 1 }
});
app.use('/api', limiter);

let schemaPromise = null;
async function ensureSchema() {
  if (!pool) return false;
  if (schemaPromise) return schemaPromise;
  schemaPromise = (async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS buk_standalone_accounts (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE,
      phone TEXT UNIQUE,
      display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS buk_standalone_entities (
      entity_name TEXT NOT NULL,
      id TEXT NOT NULL,
      owner_id TEXT NOT NULL,
      payload JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY(entity_name, id)
    );
    CREATE INDEX IF NOT EXISTS buk_standalone_entity_owner_idx ON buk_standalone_entities(entity_name, owner_id, updated_at DESC);
    CREATE INDEX IF NOT EXISTS buk_standalone_entity_payload_gin ON buk_standalone_entities USING GIN(payload);
    CREATE TABLE IF NOT EXISTS buk_standalone_files (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      public BOOLEAN NOT NULL DEFAULT FALSE,
      original_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_path TEXT NOT NULL,
      size_bytes BIGINT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS buk_standalone_files_owner_idx ON buk_standalone_files(owner_id, created_at DESC);
    CREATE TABLE IF NOT EXISTS buk_standalone_password_resets (
      id TEXT PRIMARY KEY,
      account_id TEXT NOT NULL REFERENCES buk_standalone_accounts(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TIMESTAMPTZ NOT NULL,
      used_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  return true;
  })().catch(err => { console.error('Database initialization failed:', err.message); schemaPromise = null; return false; });
  return schemaPromise;
}
void ensureSchema();

function tokenFor(account) {
  if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('الخادم يحتاج مفتاح JWT_SECRET بطول 32 حرفًا على الأقل.');
  return jwt.sign({ sub: String(account.id), email: account.email || '', phone: account.phone || '' }, JWT_SECRET, { expiresIn: '7d', issuer: 'buk-standalone' });
}
function publicAccount(a) {
  return { id: String(a.id), email: a.email || '', phone: a.phone || '', full_name: a.display_name || '', display_name: a.display_name || '' };
}
function readToken(req) {
  const h = String(req.headers.authorization || '');
  const raw = h.replace(/^Bearer\s+/i, '');
  if (!raw || !JWT_SECRET || JWT_SECRET.length < 32) return null;
  try { return jwt.verify(raw, JWT_SECRET, { issuer: 'buk-standalone' }); } catch { return null; }
}
function requireAuth(req, res, next) {
  const auth = readToken(req);
  if (!auth) return res.status(401).json({ error: 'انتهت الجلسة أو أنها غير صالحة. سجّل الدخول مجددًا.' });
  req.auth = auth;
  next();
}
async function requireDb(req, res, next) {
  if (!pool || !(await ensureSchema())) return res.status(503).json({ error: 'قاعدة البيانات غير جاهزة. اضبط DATABASE_URL في إعدادات الخادم.' });
  if (!JWT_SECRET || JWT_SECRET.length < 32) return res.status(503).json({ error: 'اضبط JWT_SECRET آمنًا في إعدادات الخادم.' });
  next();
}
app.use('/api', async (req, res, next) => {
  if (['/health', '/app/public-settings', '/auth/register', '/auth/login', '/auth/forgot-password', '/auth/reset-password', '/files/public'].some(p => req.path === p)) return next();
  await requireDb(req, res, next);
});

app.get('/api/health', async (_req, res) => {
  const dbReady = Boolean(pool && await ensureSchema());
  res.status(dbReady ? 200 : 503).json({ service: 'BUK Standalone API', database: dbReady ? 'connected' : 'not_configured' });
});
app.get('/api/app/public-settings', (_req, res) => res.json({ id: 'buk-standalone', public_settings: { name: 'BUK', independent: true } }));

function normalizePhone(value) {
  const raw = String(value || '').trim().replace(/[\s()-]/g, '');
  if (!raw) return '';
  let digits = raw.replace(/\D/g, '');
  if (raw.startsWith('+')) return digits.length >= 8 && digits.length <= 15 ? `+${digits}` : '';
  if (digits.startsWith('00')) digits = digits.slice(2);
  else if (digits.startsWith('0')) digits = `962${digits.slice(1)}`;
  return digits.length >= 8 && digits.length <= 15 ? `+${digits}` : '';
}
function normalizeEmail(value) { return String(value || '').trim().toLowerCase(); }

app.post('/api/auth/register', authLimiter, async (req, res) => {
  const email = normalizeEmail(req.body?.email);
  const phone = normalizePhone(req.body?.phone);
  const password = String(req.body?.password || '');
  const name = String(req.body?.name || email.split('@')[0] || 'مستخدم BUK').trim().slice(0, 80);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'أدخل بريدًا إلكترونيًا صحيحًا.' });
  if (phone && !/^\+[1-9]\d{7,14}$/.test(phone)) return res.status(400).json({ error: 'رقم الهاتف غير صحيح.' });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل.' });
  if (name.length < 2) return res.status(400).json({ error: 'أدخل اسمًا من حرفين على الأقل.' });
  try {
    if (!pool || !(await ensureSchema())) return res.status(503).json({ error: 'قاعدة البيانات غير جاهزة.' });
    const hash = await bcrypt.hash(password, 12);
    const account = { id: crypto.randomUUID(), email, phone: phone || null, display_name: name, password_hash: hash };
    await pool.query('INSERT INTO buk_standalone_accounts(id,email,phone,display_name,password_hash) VALUES($1,$2,$3,$4,$5)', [account.id, account.email, account.phone, account.display_name, account.password_hash]);
    const access_token = tokenFor(account);
    return res.status(201).json({ access_token, user: publicAccount(account) });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'البريد الإلكتروني أو رقم الهاتف مستخدم بالفعل.' });
    console.error('Register failed:', err.message);
    return res.status(500).json({ error: 'تعذر إنشاء الحساب الآن.' });
  }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const method = String(req.body?.method || 'email');
  const identity = method === 'phone' ? normalizePhone(req.body?.identity || req.body?.phone) : normalizeEmail(req.body?.identity || req.body?.email);
  const password = String(req.body?.password || '');
  if (!['email', 'phone'].includes(method) || !identity || !password) return res.status(400).json({ error: 'أدخل بيانات تسجيل الدخول.' });
  try {
    if (!pool || !(await ensureSchema())) return res.status(503).json({ error: 'قاعدة البيانات غير جاهزة.' });
    const column = method === 'phone' ? 'phone' : 'email';
    const result = await pool.query(`SELECT * FROM buk_standalone_accounts WHERE ${column}=$1 LIMIT 1`, [identity]);
    const account = result.rows[0];
    if (!account || !(await bcrypt.compare(password, account.password_hash))) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة.' });
    return res.json({ access_token: tokenFor(account), user: publicAccount(account) });
  } catch (err) {
    console.error('Login failed:', err.message);
    return res.status(500).json({ error: 'تعذر تسجيل الدخول الآن.' });
  }
});
app.get('/api/auth/me', requireAuth, async (req, res) => {
  const r = await pool.query('SELECT id,email,phone,display_name FROM buk_standalone_accounts WHERE id=$1', [req.auth.sub]);
  if (!r.rows[0]) return res.status(404).json({ error: 'الحساب غير موجود.' });
  res.json({ user: publicAccount(r.rows[0]) });
});
app.post('/api/auth/forgot-password', authLimiter, async (req, res) => {
  if (!pool || !(await ensureSchema())) return res.status(503).json({ error: 'قاعدة البيانات غير جاهزة.' });
  const email = normalizeEmail(req.body?.email || req.body?.identity);
  if (!email) return res.status(400).json({ error: 'أدخل بريدًا صحيحًا.' });
  const smtpHost = String(process.env.SMTP_HOST || '').trim();
  const smtpUser = String(process.env.SMTP_USER || '').trim();
  const smtpPass = String(process.env.SMTP_PASS || '');
  const mailFrom = String(process.env.MAIL_FROM || smtpUser).trim();
  if (!smtpHost || !smtpUser || !smtpPass || !mailFrom) return res.status(503).json({ error: 'خدمة البريد غير مهيأة على الخادم.' });
  try {
    const q = await pool.query('SELECT id FROM buk_standalone_accounts WHERE email=$1', [email]);
    if (q.rows[0]) {
      const raw = crypto.randomBytes(32).toString('hex');
      const hash = crypto.createHash('sha256').update(raw).digest('hex');
      await pool.query('INSERT INTO buk_standalone_password_resets(id,account_id,token_hash,expires_at) VALUES($1,$2,$3,NOW()+INTERVAL \'30 minutes\')', [crypto.randomUUID(), q.rows[0].id, hash]);
      const link = `${PUBLIC_APP_URL || 'http://localhost:5173'}/reset-password?token=${raw}`;
      const transporter = nodemailer.createTransport({ host: smtpHost, port: Number(process.env.SMTP_PORT || 587), secure: Number(process.env.SMTP_PORT || 587) === 465, auth: { user: smtpUser, pass: smtpPass } });
      await transporter.sendMail({ from: mailFrom, to: email, subject: 'استعادة كلمة مرور BUK', text: `افتح الرابط خلال 30 دقيقة لإعادة تعيين كلمة المرور: ${link}` });
    }
    res.json({ message: 'إذا كان البريد مرتبطًا بحساب BUK فستصلك تعليمات الاستعادة.' });
  } catch (err) { console.error('Password recovery failed:', err.message); res.status(503).json({ error: 'تعذر إرسال رسالة الاستعادة.' }); }
});
app.post('/api/auth/reset-password', authLimiter, async (req, res) => {
  if (!pool || !(await ensureSchema())) return res.status(503).json({ error: 'قاعدة البيانات غير جاهزة.' });
  const raw = String(req.body?.token || '');
  const password = String(req.body?.password || '');
  if (!/^[a-f0-9]{64}$/.test(raw)) return res.status(400).json({ error: 'رابط الاستعادة غير صالح أو منتهي.' });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.' });
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const q = await client.query('SELECT id,account_id FROM buk_standalone_password_resets WHERE token_hash=$1 AND used_at IS NULL AND expires_at>NOW() FOR UPDATE', [hash]);
    if (!q.rows[0]) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'رابط الاستعادة غير صالح أو منتهي.' }); }
    const pw = await bcrypt.hash(password, 12);
    await client.query('UPDATE buk_standalone_accounts SET password_hash=$1,updated_at=NOW() WHERE id=$2', [pw, q.rows[0].account_id]);
    await client.query('UPDATE buk_standalone_password_resets SET used_at=NOW() WHERE id=$1', [q.rows[0].id]);
    await client.query('COMMIT');
    res.json({ message: 'تم تغيير كلمة المرور بنجاح.' });
  } catch (err) { await client.query('ROLLBACK').catch(() => {}); console.error(err.message); res.status(500).json({ error: 'تعذر تغيير كلمة المرور.' }); }
  finally { client.release(); }
});

function plainObject(v) { return v && typeof v === 'object' && !Array.isArray(v); }
function same(a, b) { return String(a ?? '') === String(b ?? ''); }
function matchesOne(value, condition) {
  if (plainObject(condition) && Object.keys(condition).some(k => k.startsWith('$'))) {
    for (const [op, expected] of Object.entries(condition)) {
      if (op === '$eq' && !same(value, expected)) return false;
      if (op === '$ne' && (Array.isArray(value) ? value.some(x => same(x, expected)) : same(value, expected))) return false;
      if (op === '$in' && !(expected || []).some(x => Array.isArray(value) ? value.some(y => same(y, x)) : same(value, x))) return false;
      if (op === '$nin' && (expected || []).some(x => Array.isArray(value) ? value.some(y => same(y, x)) : same(value, x))) return false;
      if (op === '$regex') {
        try { if (!new RegExp(String(expected), String(condition.$options || 'i')).test(String(value ?? ''))) return false; }
        catch { return false; }
      }
      if (op === '$gt' && !(value > expected)) return false;
      if (op === '$gte' && !(value >= expected)) return false;
      if (op === '$lt' && !(value < expected)) return false;
      if (op === '$lte' && !(value <= expected)) return false;
      if (op === '$exists' && ((value !== undefined && value !== null) !== Boolean(expected))) return false;
    }
    return true;
  }
  if (Array.isArray(value)) return value.some(x => same(x, condition));
  if (plainObject(value) && plainObject(condition)) return Object.entries(condition).every(([k, v]) => matchesOne(value[k], v));
  return same(value, condition);
}
function matchesQuery(doc, query = {}) {
  if (!plainObject(query)) return true;
  if (Array.isArray(query.$and) && !query.$and.every(q => matchesQuery(doc, q))) return false;
  if (Array.isArray(query.$or) && !query.$or.some(q => matchesQuery(doc, q))) return false;
  if (Array.isArray(query.$nor) && query.$nor.some(q => matchesQuery(doc, q))) return false;
  return Object.entries(query).filter(([k]) => !k.startsWith('$')).every(([k, v]) => matchesOne(doc[k], v));
}
function ownerVisible(entity, row, user) {
  const id = String(user.id);
  if (['BukProfile', 'Story', 'LiveChannel', 'LiveArchive', 'LiveFollow'].includes(entity)) return true;
  if (entity === 'Conversation') return row.is_public === true || same(row.owner_id, id) || (row.member_ids || []).some(x => same(x, id));
  if (entity === 'Message') return same(row.sender_id, id) || same(row.recipient_id, id) || Boolean(row.__conversation_access);
  if (entity === 'Call') return same(row.caller_id, id) || same(row.callee_id, id);
  if (entity === 'Meeting') return same(row.host_id, id) || row.kind === 'live';
  if (entity === 'Contact' || entity === 'ContactInvite') return same(row.owner_id, id);
  if (entity === 'Notification') return same(row.user_id, id);
  if (entity === 'Reminder' || entity === 'Note' || entity === 'AiMessage') return same(row.owner_id, id);
  if (entity === 'UserSettings') return same(row.user_id, id) || same(row.owner_id, id);
  if (entity === 'User') return same(row.id, id) || same(row.user_id, id);
  return same(row.owner_id, id) || same(row.user_id, id) || same(row.sender_id, id) || same(row.host_id, id) || same(row.caller_id, id) || same(row.callee_id, id) || row.is_public === true;
}

function canDelete(entity, row, user) {
  if (entity === 'Message') return same(row.sender_id, user.id);
  return canMutate(entity, row, user);
}

function canMutate(entity, row, user) {
  const id = String(user.id);
  if (entity === 'BukProfile' || entity === 'Story' || entity === 'LiveChannel' || entity === 'LiveArchive') return same(row.owner_id, id) || same(row.user_id, id);
  if (entity === 'LiveFollow') return same(row.user_id, id);
  if (entity === 'Conversation') return same(row.owner_id, id) || (row.member_ids || []).some(x => same(x, id)) || row.is_public === true;
  if (entity === 'Message') return same(row.sender_id, id) || same(row.recipient_id, id) || Boolean(row.__conversation_access);
  if (entity === 'Call') return same(row.caller_id, id) || same(row.callee_id, id);
  if (entity === 'Meeting') return same(row.host_id, id);
  if (entity === 'Contact' || entity === 'ContactInvite') return same(row.owner_id, id);
  if (entity === 'Notification') return same(row.user_id, id);
  if (entity === 'Reminder' || entity === 'Note' || entity === 'AiMessage') return same(row.owner_id, id);
  if (entity === 'UserSettings') return same(row.user_id, id) || same(row.owner_id, id);
  if (entity === 'User') return same(row.id, id) || same(row.user_id, id);
  return same(row.owner_id, id) || same(row.user_id, id) || same(row.sender_id, id) || same(row.host_id, id) || same(row.caller_id, id) || same(row.callee_id, id);
}

async function hydrateEntityRows(entity, rows, user) {
  if (entity !== 'Message' || !rows.length) return rows;
  const convIds = [...new Set(rows.map(r => String(r.conversation_id || '')).filter(Boolean))];
  if (!convIds.length) return rows;
  const convs = await pool.query('SELECT payload FROM buk_standalone_entities WHERE entity_name=$1 AND id=ANY($2::text[])', ['Conversation', convIds]);
  const allowed = new Set(convs.rows.filter(r => ownerVisible('Conversation', r.payload, user)).map(r => String(r.payload.id)));
  return rows.map(r => ({ ...r, __conversation_access: allowed.has(String(r.conversation_id)) }));
}
async function getRows(entity) {
  const q = await pool.query('SELECT id,payload,created_at,updated_at FROM buk_standalone_entities WHERE entity_name=$1 ORDER BY updated_at DESC LIMIT 5000', [entity]);
  return q.rows.map(r => ({ ...r.payload, id: r.id, created_date: r.payload.created_date || r.created_at?.toISOString?.() || r.created_at, updated_date: r.updated_at?.toISOString?.() || r.updated_at }));
}
function sanitizeEntity(entity, row, user) {
  const data = { ...row };
  delete data.__conversation_access;
  if (entity === 'BukProfile' && !same(row.user_id, user.id)) {
    delete data.email; delete data.phone; delete data.phone_key;
  }
  return data;
}
async function visibleRows(entity, user) {
  let rows = await getRows(entity);
  rows = await hydrateEntityRows(entity, rows, user);
  return rows.filter(row => ownerVisible(entity, row, user));
}
function applyUpdate(doc, update) {
  const out = { ...doc };
  if (!plainObject(update)) return out;
  if (!Object.keys(update).some(k => k.startsWith('$'))) return { ...out, ...update };
  if (plainObject(update.$set)) Object.assign(out, update.$set);
  if (plainObject(update.$unset)) Object.keys(update.$unset).forEach(k => delete out[k]);
  for (const [key, val] of Object.entries(update.$push || {})) {
    const arr = Array.isArray(out[key]) ? [...out[key]] : [];
    if (plainObject(val) && Array.isArray(val.$each)) arr.push(...val.$each); else arr.push(val);
    out[key] = arr;
  }
  for (const [key, val] of Object.entries(update.$addToSet || {})) {
    const arr = Array.isArray(out[key]) ? [...out[key]] : [];
    const vals = plainObject(val) && Array.isArray(val.$each) ? val.$each : [val];
    vals.forEach(v => { if (!arr.some(x => same(x, v))) arr.push(v); }); out[key] = arr;
  }
  for (const [key, val] of Object.entries(update.$pull || {})) {
    const arr = Array.isArray(out[key]) ? out[key] : [];
    const values = plainObject(val) && Array.isArray(val.$in) ? val.$in : [val];
    out[key] = arr.filter(x => !values.some(v => same(x, v)));
  }
  return out;
}
async function saveEntity(entity, row, ownerId) {
  const id = String(row.id || crypto.randomUUID());
  const created = row.created_date || new Date().toISOString();
  const data = { ...row, id, created_date: created, updated_date: new Date().toISOString() };
  const q = await pool.query(`INSERT INTO buk_standalone_entities(entity_name,id,owner_id,payload) VALUES($1,$2,$3,$4::jsonb)
    ON CONFLICT(entity_name,id) DO NOTHING`, [entity, id, String(ownerId || data.owner_id || data.user_id || ''), JSON.stringify(data)]);
  if (!q.rowCount) throw Object.assign(new Error('السجل موجود مسبقًا.'), { code: '23505' });
  return data;
}
async function updateEntity(entity, id, patch, user) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const q = await client.query('SELECT payload FROM buk_standalone_entities WHERE entity_name=$1 AND id=$2 FOR UPDATE', [entity, String(id)]);
    if (!q.rows[0]) { await client.query('ROLLBACK'); return null; }
    const old = { ...q.rows[0].payload, id: String(id) };
    const all = await hydrateEntityRows(entity, [old], user);
    if (!canMutate(entity, all[0], user)) { await client.query('ROLLBACK'); return null; }
    const safePatch = { ...(plainObject(patch) ? patch : {}) };
    for (const field of ['owner_id','user_id','sender_id','host_id','caller_id','callee_id']) delete safePatch[field];
    if (entity === 'Message') {
      for (const field of ['conversation_id','recipient_id','sender_name']) delete safePatch[field];
    }
    if (entity === 'Message' && !same(old.sender_id, user.id)) {
      const allowed = new Set(['is_read','read','read_at','is_delivered','delivered','delivered_at','status','read_by','delivered_to','hidden_for_ids']);
      if (Object.keys(safePatch).some(field => !allowed.has(field))) { await client.query('ROLLBACK'); return null; }
      for (const field of ['read_by','delivered_to','hidden_for_ids']) {
        if (Array.isArray(safePatch[field])) {
          const previous=Array.isArray(old[field])?old[field].map(String):[];
          const additions=safePatch[field].map(String).filter(value=>!previous.includes(value));
          if (additions.some(value=>value!==String(user.id))) { await client.query('ROLLBACK'); return null; }
          safePatch[field]=[...new Set([...previous,...additions])];
        }
      }
    }
    if (entity === 'Conversation' && !same(old.owner_id,user.id)) {
      const allowed = new Set(['last_message_at','last_message_text','member_ids','muted_ids']);
      if (Object.keys(safePatch).some(field=>!allowed.has(field))) { await client.query('ROLLBACK'); return null; }
      if (Array.isArray(safePatch.member_ids)) {
        const previous=Array.isArray(old.member_ids)?old.member_ids.map(String):[];
        const requested=safePatch.member_ids.map(String);
        if (previous.some(value=>!requested.includes(value)) || requested.some(value=>!previous.includes(value)&&value!==String(user.id))) { await client.query('ROLLBACK'); return null; }
        safePatch.member_ids=[...new Set([...previous,...requested,String(user.id)])];
      }
      if (Array.isArray(safePatch.muted_ids)) {
        const previous=Array.isArray(old.muted_ids)?old.muted_ids.map(String):[];
        const requested=safePatch.muted_ids.map(String);
        const previousOthers=previous.filter(value=>value!==String(user.id));
        const requestedOthers=requested.filter(value=>value!==String(user.id));
        if (previousOthers.length!==requestedOthers.length || previousOthers.some(value=>!requestedOthers.includes(value))) { await client.query('ROLLBACK'); return null; }
        safePatch.muted_ids=[...new Set([...previousOthers,...(requested.includes(String(user.id))?[String(user.id)]:[])])];
      }
    }
    const merged = { ...applyUpdate(old, safePatch), id: String(id), updated_date: new Date().toISOString() };
    const ownerId = old.owner_id || old.user_id || old.sender_id || old.host_id || user.id;
    await client.query('UPDATE buk_standalone_entities SET owner_id=$3,payload=$4::jsonb,updated_at=NOW() WHERE entity_name=$1 AND id=$2', [entity, String(id), String(ownerId), JSON.stringify(merged)]);
    await client.query('COMMIT');
    return merged;
  } catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; }
  finally { client.release(); }
}

async function canPostToConversation(conversationId, userId) {
  const id = String(conversationId || '');
  if (!id) return false;
  const result = await pool.query(
    "SELECT payload FROM buk_standalone_entities WHERE entity_name='Conversation' AND id=$1 LIMIT 1",
    [id]
  );
  if (!result.rows[0]) return false;
  return ownerVisible('Conversation', result.rows[0].payload, { id: String(userId) });
}

const validEntity = name => /^[A-Za-z][A-Za-z0-9]{0,63}$/.test(name);
app.post('/api/entities/:entity/filter', requireAuth, async (req, res) => {
  const entity = req.params.entity;
  if (!validEntity(entity)) return res.status(400).json({ error: 'اسم كيان غير صالح.' });
  try {
    let rows = (await visibleRows(entity, { id: req.auth.sub })).filter(row => matchesQuery(row, req.body?.query || {}));
    const total = rows.length;
    const sort = String(req.body?.sort || req.body?.options?.sort || '');
    if (sort) {
      const desc = sort.startsWith('-'); const field = desc ? sort.slice(1) : sort;
      rows.sort((a,b) => { const av=a[field], bv=b[field]; const an=Date.parse(av), bn=Date.parse(bv); const d=Number.isFinite(an)&&Number.isFinite(bn)?an-bn:(String(av??'').localeCompare(String(bv??''),undefined,{numeric:true})); return desc?-d:d; });
    }
    const limit = Math.max(1, Math.min(500, Number(req.body?.limit || req.body?.options?.limit || 100)));
    const skip = Math.max(0, Number(req.body?.skip || req.body?.options?.skip || 0));
    rows = rows.slice(skip, skip + limit).map(row => sanitizeEntity(entity, row, { id: req.auth.sub }));
    const out = { items: rows, total, limit, skip, length: rows.length };
    rows.forEach((r,i) => { out[i] = r; });
    res.json(out);
  } catch (err) { console.error('Entity filter failed:', entity, err.message); res.status(500).json({ error: 'تعذر تحميل البيانات.' }); }
});
app.post('/api/entities/:entity/list', requireAuth, async (req,res) => {
  try {
    const entity=req.params.entity;
    let rows=(await visibleRows(entity,{id:req.auth.sub})).filter(row=>matchesQuery(row,req.body?.query||{}));
    const sort=String(req.body?.sort||'');
    if(sort){const desc=sort.startsWith('-');const field=desc?sort.slice(1):sort;rows.sort((a,b)=>{const av=a[field],bv=b[field];const an=Date.parse(av),bn=Date.parse(bv);const d=Number.isFinite(an)&&Number.isFinite(bn)?an-bn:String(av??'').localeCompare(String(bv??''),undefined,{numeric:true});return desc?-d:d;});}
    const limit=Math.max(1,Math.min(500,Number(req.body?.limit||100)));const skip=Math.max(0,Number(req.body?.skip||0));
    rows=rows.slice(skip,skip+limit).map(row=>sanitizeEntity(entity,row,{id:req.auth.sub}));
    const out={items:rows,total:rows.length,length:rows.length};rows.forEach((r,i)=>{out[i]=r;});res.json(out);
  }catch(err){console.error(err.message);res.status(500).json({error:'تعذر تحميل البيانات.'});}
});
app.get('/api/entities/:entity/:id', requireAuth, async (req,res) => {
  const entity=req.params.entity;
  try {
    const rows=await visibleRows(entity,{id:req.auth.sub});
    const row=rows.find(x=>String(x.id)===String(req.params.id));
    if (!row) return res.status(404).json({error:'السجل غير موجود.'});
    res.json(sanitizeEntity(entity,row,{id:req.auth.sub}));
  } catch(err){console.error(err.message);res.status(500).json({error:'تعذر تحميل السجل.'});}
});
app.post('/api/entities/:entity', requireAuth, async (req,res) => {
  const entity=req.params.entity; const data=plainObject(req.body)?req.body:{}; const userId=String(req.auth.sub);
  if (!validEntity(entity)) return res.status(400).json({error:'اسم كيان غير صالح.'});
  const ownerField = ['Reminder','Note','AiMessage','Contact','ContactInvite','LiveChannel','LiveArchive'].includes(entity) ? 'owner_id' : (['BukProfile','Story','Notification','UserSettings'].includes(entity) ? 'user_id' : (['Conversation','Meeting'].includes(entity) ? (entity==='Meeting'?'host_id':'owner_id') : (entity==='Call'?'caller_id':'')));
  const row={...data};
  if (ownerField) row[ownerField]=userId;
  if (entity==='Conversation') {
    row.owner_id=userId;
    const members=Array.isArray(row.member_ids)?row.member_ids.map(String).filter(Boolean):[];
    row.member_ids=[...new Set([userId,...members])].slice(0,100);
  }
  if (entity==='Message') {
    if (!await canPostToConversation(row.conversation_id, userId)) return res.status(403).json({error:'لا تملك صلاحية إرسال رسالة إلى هذه المحادثة.'});
    row.sender_id=userId;
  }
  if (entity==='Call') row.caller_id=userId;
  if (entity==='Meeting') row.host_id=userId;
  if (entity==='LiveFollow') row.user_id=userId;
  try { const saved=await saveEntity(entity,row,userId); res.status(201).json(saved); }
  catch(err){console.error('Entity create failed:',entity,err.message);res.status(500).json({error:'تعذر حفظ البيانات.'});}
});
app.patch('/api/entities/:entity/:id', requireAuth, async (req,res) => {
  try { const updated=await updateEntity(req.params.entity,req.params.id,req.body,{id:req.auth.sub}); if(!updated) return res.status(404).json({error:'السجل غير موجود أو لا تملك صلاحية تعديله.'}); res.json(updated); }
  catch(err){console.error('Entity update failed:',err.message);res.status(500).json({error:'تعذر تحديث البيانات.'});}
});
app.delete('/api/entities/:entity/:id', requireAuth, async (req,res) => {
  try {
    const rows=await visibleRows(req.params.entity,{id:req.auth.sub});
    const row=rows.find(x=>String(x.id)===String(req.params.id));
    if(!row || !canDelete(req.params.entity,row,{id:req.auth.sub})) return res.status(404).json({error:'السجل غير موجود أو لا تملك صلاحية حذفه.'});
    await pool.query('DELETE FROM buk_standalone_entities WHERE entity_name=$1 AND id=$2',[req.params.entity,String(req.params.id)]);
    res.json({ok:true});
  } catch(err){console.error(err.message);res.status(500).json({error:'تعذر حذف السجل.'});}
});
app.post('/api/entities/:entity/bulk-create', requireAuth, async (req,res) => {
  const entity=req.params.entity;
  if(!validEntity(entity))return res.status(400).json({error:'اسم كيان غير صالح.'});
  const values=Array.isArray(req.body?.items)?req.body.items.slice(0,500):[]; const out=[]; const userId=String(req.auth.sub);
  const ownerField=['Reminder','Note','AiMessage','Contact','ContactInvite','LiveChannel','LiveArchive'].includes(entity)?'owner_id':(['BukProfile','Story','Notification','UserSettings'].includes(entity)?'user_id':(['Conversation','Meeting'].includes(entity)?(entity==='Meeting'?'host_id':'owner_id'):(entity==='Call'?'caller_id':'')));
  try {
    for(const raw of values){
      if(!plainObject(raw))continue;
      const row={...raw};
      if(ownerField)row[ownerField]=userId;
      if(entity==='Conversation'){row.owner_id=userId;const members=Array.isArray(row.member_ids)?row.member_ids.map(String).filter(Boolean):[];row.member_ids=[...new Set([userId,...members])].slice(0,100);}
      if(entity==='Message') {
        if (!await canPostToConversation(row.conversation_id, userId)) throw Object.assign(new Error('not_conversation_member'), { code: '42501' });
        row.sender_id=userId;
      }
      if(entity==='Call')row.caller_id=userId;
      if(entity==='Meeting')row.host_id=userId;
      if(entity==='LiveFollow')row.user_id=userId;
      out.push(await saveEntity(entity,row,userId));
    }
    res.status(201).json({items:out});
  }catch(err){
    console.error('Bulk entity create failed:',entity,err.message);
    const status=err.code==='23505'?409:err.code==='42501'?403:500;
    const message=err.code==='23505'?'يوجد سجل مكرر ضمن المجموعة.':err.code==='42501'?'لا تملك صلاحية الكتابة في إحدى المحادثات المحددة.':'تعذر حفظ المجموعة.';
    res.status(status).json({error:message});
  }
});
app.post('/api/entities/:entity/bulk-update', requireAuth, async (req,res) => {
  const updates=Array.isArray(req.body?.items)?req.body.items.slice(0,500):[]; const out=[];
  try { for(const u of updates){ const id=u.id; if(!id) continue; const patch={...u}; delete patch.id; const saved=await updateEntity(req.params.entity,id,patch,{id:req.auth.sub}); if(saved) out.push(saved); } res.json({items:out}); }
  catch(err){console.error(err.message);res.status(500).json({error:'تعذر تحديث المجموعة.'});}
});
app.post('/api/entities/:entity/update-many', requireAuth, async (req,res) => {
  const entity=req.params.entity; const query=req.body?.query||{}; const patch=req.body?.update||{};
  try { const rows=(await visibleRows(entity,{id:req.auth.sub})).filter(r=>matchesQuery(r,query)).slice(0,500); const out=[]; for(const r of rows){const saved=await updateEntity(entity,r.id,patch,{id:req.auth.sub});if(saved)out.push(saved);} res.json({updated:out.length,items:out}); }
  catch(err){console.error(err.message);res.status(500).json({error:'تعذر تحديث السجلات.'});}
});
app.post('/api/entities/:entity/delete-many', requireAuth, async (req,res) => {
  const entity=req.params.entity; const query=req.body?.query||{};
  try { const rows=(await visibleRows(entity,{id:req.auth.sub})).filter(r=>matchesQuery(r,query)&&canDelete(entity,r,{id:req.auth.sub})).slice(0,500); for(const r of rows) await pool.query('DELETE FROM buk_standalone_entities WHERE entity_name=$1 AND id=$2',[entity,r.id]); res.json({deleted:rows.length}); }
  catch(err){console.error(err.message);res.status(500).json({error:'تعذر حذف السجلات.'});}
});
app.post('/api/entities/:entity/count', requireAuth, async (req,res) => {
  try {const rows=(await visibleRows(req.params.entity,{id:req.auth.sub})).filter(r=>matchesQuery(r,req.body?.query||{}));res.json({count:rows.length});}
  catch(err){console.error(err.message);res.status(500).json({error:'تعذر حساب السجلات.'});}
});
app.post('/api/entities/:entity/aggregate', requireAuth, async (req,res) => {
  try {const q=req.body?.query||{};const field=String(req.body?.groupBy||'');const rows=(await visibleRows(req.params.entity,{id:req.auth.sub})).filter(r=>matchesQuery(r,q));const map=new Map();rows.forEach(r=>{const k=String(r[field]??'');map.set(k,(map.get(k)||0)+1);});res.json({rows:[...map.entries()].map(([k,count])=>({[field]:k,count}))});}
  catch(err){console.error(err.message);res.status(500).json({error:'تعذر تجميع البيانات.'});}
});

app.post('/api/files/upload', requireAuth, upload.single('file'), async (req,res) => {
  if(!req.file) return res.status(400).json({error:'لم يتم اختيار ملف.'});
  const id=crypto.randomUUID(); const ext=path.extname(req.file.originalname).slice(0,12).replace(/[^.a-zA-Z0-9]/g,''); const finalPath=path.join(storageRoot,`${id}${ext}`);
  try {
    fs.renameSync(req.file.path,finalPath);
    const pub=req.body?.public==='true';
    await pool.query('INSERT INTO buk_standalone_files(id,owner_id,public,original_name,mime_type,file_path,size_bytes) VALUES($1,$2,$3,$4,$5,$6,$7)',[id,req.auth.sub,pub,path.basename(req.file.originalname).slice(0,180),req.file.mimetype,finalPath,req.file.size]);
    const url=`/api/files/${id}`;
    res.status(201).json({file_uri:`private:${id}`,file_url:pub?url:'',file_id:id});
  } catch(err){fs.unlink(finalPath,()=>{});console.error(err.message);res.status(500).json({error:'تعذر تخزين الملف.'});}
});
app.post('/api/files/signed-url', requireAuth, async (req,res) => {
  const uri=String(req.body?.file_uri||'');const id=uri.replace(/^private:/,'');
  const q=await pool.query('SELECT id,owner_id,public FROM buk_standalone_files WHERE id=$1',[id]);
  if(!q.rows[0]||(!q.rows[0].public&&!same(q.rows[0].owner_id,req.auth.sub))) return res.status(404).json({error:'الملف غير موجود.'});
  const hours=Math.max(1,Math.min(24,Math.ceil(Number(req.body?.expires_in||3600)/3600)));const sig=jwt.sign({sub:String(req.auth.sub),file:id},JWT_SECRET,{expiresIn:`${hours}h`,issuer:'buk-standalone-file'});
  res.json({signed_url:`/api/files/${id}?sig=${encodeURIComponent(sig)}`});
});
app.get('/api/files/:id', async (req,res) => {
  try {
    const q=await pool.query('SELECT * FROM buk_standalone_files WHERE id=$1',[req.params.id]);const f=q.rows[0];if(!f) return res.status(404).end();
    if(!f.public){let ok=false;try{const sig=jwt.verify(String(req.query.sig||''),JWT_SECRET,{issuer:'buk-standalone-file'});ok=same(sig.file,f.id)&&same(sig.sub,f.owner_id);}catch{} if(!ok)return res.status(403).end();}
    res.setHeader('Content-Type',f.mime_type||'application/octet-stream');res.setHeader('Content-Disposition',`inline; filename*=UTF-8''${encodeURIComponent(f.original_name)}`);res.sendFile(f.file_path);
  }catch(err){console.error(err.message);res.status(500).end();}
});

async function invokeOpenAI(messages, opts={}) {
  const key=String(process.env.OPENAI_API_KEY||'').trim();
  if(!key) throw Object.assign(new Error('ميزة المساعد تحتاج ضبط OPENAI_API_KEY في إعدادات الخادم المستقل.'),{status:503});
  const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4o-mini',messages,temperature:0.4,...opts})});
  const data=await response.json().catch(()=>({}));if(!response.ok)throw Object.assign(new Error(data.error?.message||'فشل مزود الذكاء الاصطناعي.'),{status:502});
  return data.choices?.[0]?.message?.content||'';
}
async function doAssistant(req,res,body,user){
  const action=String(body.action||'chat');const text=String(body.text||'').slice(0,4000).trim();
  if(action==='translate'){
    if(!text)return res.status(400).json({error:'text is required'});
    try{const translation=await invokeOpenAI([{role:'system',content:`ترجم النص إلى ${String(body.target||'en')} ترجمة طبيعية ودقيقة فقط. المصدر: ${String(body.source||'auto')}. أعد الترجمة فقط.`},{role:'user',content:text}]);return res.json({translation:translation.trim()});}
    catch(e){return res.status(e.status||502).json({error:e.message});}
  }
  if(action==='transcribe'){
    const rawUrl=String(body.audio_url||'');
    if(!rawUrl)return res.status(400).json({error:'audio_url is required'});
    try{
      const key=String(process.env.OPENAI_API_KEY||'').trim();
      if(!key)return res.status(503).json({error:'ميزة التفريغ الصوتي تحتاج OPENAI_API_KEY.'});
      const parsed=new URL(rawUrl, PUBLIC_APP_URL || 'http://localhost');
      let audioBuffer; let mime='audio/webm';
      const fileMatch=parsed.pathname.match(/^\/api\/files\/([A-Za-z0-9-]+)$/);
      if(fileMatch){
        const q=await pool.query('SELECT file_path,mime_type FROM buk_standalone_files WHERE id=$1 AND owner_id=$2',[fileMatch[1],user.id]);
        if(!q.rows[0])return res.status(403).json({error:'الملف الصوتي غير متاح.'});
        audioBuffer=fs.readFileSync(q.rows[0].file_path); mime=q.rows[0].mime_type||mime;
      } else {
        if(parsed.protocol!=='https:')return res.status(400).json({error:'رابط الصوت غير آمن.'});
        const remote=await fetch(parsed,{signal:AbortSignal.timeout(20000)});
        if(!remote.ok)return res.status(400).json({error:'تعذر تحميل المقطع الصوتي.'});
        const contentLength=Number(remote.headers.get('content-length')||0);
        if(contentLength>25*1024*1024)return res.status(413).json({error:'حجم المقطع الصوتي أكبر من 25 ميغابايت.'});
        audioBuffer=Buffer.from(await remote.arrayBuffer());
        if(audioBuffer.length>25*1024*1024)return res.status(413).json({error:'حجم المقطع الصوتي أكبر من 25 ميغابايت.'});
        mime=remote.headers.get('content-type')||mime;
      }
      const form=new FormData();
      form.append('file',new Blob([audioBuffer],{type:mime}),`voice.${mime.includes('mp4')?'m4a':'webm'}`);
      form.append('model','whisper-1');
      const out=await fetch('https://api.openai.com/v1/audio/transcriptions',{method:'POST',headers:{Authorization:`Bearer ${key}`},body:form,signal:AbortSignal.timeout(45000)});
      const data=await out.json().catch(()=>({}));
      if(!out.ok)return res.status(502).json({error:data.error?.message||'تعذر تفريغ التسجيل.'});
      return res.json({transcript:String(data.text||'').trim()});
    }catch(e){console.error('Transcription failed:',e.message);return res.status(502).json({error:'تعذر تفريغ التسجيل الصوتي.'});}
  }
  if(action==='speak')return res.status(503).json({error:'توليد الكلام الصوتي غير مهيأ. يمكن استخدام نطق الجهاز من إعدادات الهاتف.'});
  if(action==='chat'||action==='assistant'){
    if(!text)return res.status(400).json({error:'text is required'});
    const isMyBuki=body.agent==='mypuki';
    const persona=isMyBuki
      ? `أنت My Buki، مساعد شخصي عربي. الوقت المحلي للمستخدم: ${String(body.local_now||'غير محدد')}؛ المنطقة الزمنية: ${String(body.tz_name||'غير محددة')}. ساعد في الأسئلة والملاحظات والتذكيرات. أعد JSON فقط بالشكل {"reply":"نص الرد","action":"none"} أو عند طلب ضبط تذكير واضح {"reply":"تأكيد مختصر","action":"create_reminder","title":"عنوان قصير","at":"تاريخ ISO 8601 مع المنطقة الزمنية أو offset","repeat":"none|daily|weekly|monthly"}. لا تنشئ تذكيرًا إلا إذا ذكر المستخدم وقتًا أو موعدًا واضحًا. لا تخترع موعدًا؛ عند غموض الوقت اسأل سؤالًا داخل reply واجعل action=none. يجب أن يكون at في المستقبل.`
      : 'أنت BUK AI، المساعد الذكي داخل تطبيق BUK. أجب بالعربية الواضحة والمباشرة.';
    const history=Array.isArray(body.history)?body.history.slice(-12).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content||'').slice(0,1200)})):[];
    try{
      const messages=[{role:'system',content:persona},...history,{role:'user',content:text}];
      if(isMyBuki){
        const raw=await invokeOpenAI(messages,{response_format:{type:'json_object'}});
        let result;try{result=JSON.parse(raw);}catch{result={reply:raw,action:'none'};}
        const blocks=[];
        if(result.action==='create_reminder'){
          const at=new Date(result.at);
          const title=String(result.title||'').trim().slice(0,120);
          const repeat=['daily','weekly','monthly'].includes(result.repeat)?result.repeat:'none';
          if(title&&Number.isFinite(at.getTime())&&at.getTime()>Date.now()+30000){
            const saved=await saveEntity('Reminder',{owner_id:user.id,title,at:at.toISOString(),repeat,status:'scheduled',tone:'default',alerted:false},user.id);
            blocks.push({type:'reminder',id:saved.id,title:saved.title,at:saved.at,repeat:saved.repeat});
          }
        }
        return res.json({reply:String(result.reply||'').trim()||'أنا جاهز لمساعدتك.',blocks});
      }
      const reply=await invokeOpenAI(messages);
      return res.json({reply:reply.trim(),blocks:[]});
    }catch(e){return res.status(e.status||502).json({error:e.message});}
  }
  return res.status(400).json({error:'Unknown assistant action'});
}

async function meetingFunction(body,user,res){
  const action=String(body.action||'sync');const now=Date.now();
  const readList=v=>(Array.isArray(v)?v:[]).map(x=>{try{return typeof x==='string'?JSON.parse(x):x;}catch{return null;}}).filter(Boolean);
  const fresh=list=>{const m=new Map();readList(list).forEach(p=>{if(!p?.id)return;const old=m.get(p.id);if(!old||Number(p.seen||0)>=Number(old.seen||0))m.set(p.id,p);});return [...m.values()].filter(p=>p.host||now-Number(p.seen||0)<25000);};
  const mini=p=>({id:p.id,name:p.name||'ضيف',guest:!!p.guest,host:!!p.host,mic:p.mic!==false,cam:!!p.cam,sharing:!!p.sharing,mutedByHost:!!p.mutedByHost});
  const state=(m,ps)=>({id:m.id,code:m.code,kind:m.kind||'meeting',channel_id:m.channel_id||'',title:m.title||'اجتماع BUK',status:m.status,host_id:m.host_id,host_name:m.host_name,blocked_ids:m.blocked_ids||[],participants:ps.map(mini),chat:readList(m.chat).slice(-120)});
  if(action==='create'){
    if(!user)return res.status(401).json({error:'auth_required'});
    let code; for(let i=0;i<10;i++){code=Math.random().toString(36).slice(2,8).toUpperCase();const q=await pool.query("SELECT 1 FROM buk_standalone_entities WHERE entity_name='Meeting' AND payload->>'code'=$1",[code]);if(!q.rowCount)break;}
    const r=await saveEntity('Meeting',{host_id:user.id,host_name:user.full_name||user.email||'المضيف',title:String(body.title||'').trim()||'اجتماع BUK',kind:body.kind==='live'?'live':'meeting',channel_id:String(body.channel_id||''),code,status:'open',participants:[],signals:[],chat:[],blocked_ids:[]},user.id);
    return res.json({meeting:state(r,[])});
  }
  if(action==='live'){
    const rows=await visibleRows('Meeting',user||{id:''});const rooms=rows.filter(m=>m.kind==='live'&&m.status!=='ended').map(m=>({id:m.id,code:m.code,title:m.title||'بث BUK مباشر',host_name:m.host_name||'مضيف BUK',host_id:m.host_id,channel_id:m.channel_id||'',started_at:m.started_at||m.created_date,viewers:fresh(m.participants).length})).filter(m=>m.viewers>0);return res.json({rooms});
  }
  const code=String(body.code||'').toUpperCase().trim();if(!code)return res.status(400).json({error:'code_required'});
  const q=await pool.query("SELECT id,payload FROM buk_standalone_entities WHERE entity_name='Meeting' AND payload->>'code'=$1 LIMIT 1",[code]);const meeting=q.rows[0]?{...q.rows[0].payload,id:q.rows[0].id}:null;if(!meeting)return res.status(404).json({error:'not_found'});
  let participants=fresh(meeting.participants);const blocked=meeting.blocked_ids||[];const isHost=!!user&&String(user.id)===String(meeting.host_id);const guestRequested=String(body.id||body.from||'');const myId=user?String(user.id):(guestRequested.startsWith('guest-')?guestRequested.slice(0,80):'');
  const updateMeeting=async patch=>{const updated={...meeting,...patch,updated_date:new Date().toISOString()};await pool.query("UPDATE buk_standalone_entities SET payload=$3::jsonb,updated_at=NOW() WHERE entity_name=$1 AND id=$2",['Meeting',meeting.id,JSON.stringify(updated)]);Object.assign(meeting,updated);};
  if(action==='info')return res.json({info:{code:meeting.code,title:meeting.title||'',kind:meeting.kind||'meeting',channel_id:meeting.channel_id||'',host_id:meeting.host_id,host_name:meeting.host_name,status:meeting.status,started_at:meeting.started_at||meeting.created_date,viewers:participants.length}});
  if(action==='join'){
    if(!myId)return res.status(400).json({error:'id_required'});if(blocked.includes(myId))return res.json({blocked:true,meeting:state(meeting,participants)});if(meeting.status==='ended')return res.json({ended:true,meeting:state(meeting,participants)});
    const old=participants.find(p=>p.id===myId);if(!old&&participants.length>=12)return res.status(409).json({error:'full'});
    const entry={id:myId,name:old?.name||String(body.name||'').trim()||user?.full_name||'ضيف',guest:!isHost,host:isHost,mic:typeof body.mic==='boolean'?body.mic:true,cam:typeof body.cam==='boolean'?body.cam:!!old?.cam,sharing:false,mutedByHost:!!old?.mutedByHost,joined:old?.joined||now,seen:now};
    participants=[...participants.filter(p=>p.id!==myId),entry];await updateMeeting({participants:participants.map(JSON.stringify),status:meeting.status==='open'?'live':meeting.status,started_at:meeting.started_at||new Date().toISOString()});return res.json({meeting:state(meeting,participants),me:myId,is_host:isHost});
  }
  if(action==='leave'){if(!isHost&&!participants.some(p=>p.id===myId))return res.status(403).json({error:'not_a_participant'});participants=participants.filter(p=>p.id!==myId);await updateMeeting({participants:participants.map(JSON.stringify)});return res.json({ok:true});}
  if(action==='media'){const p=participants.find(p=>p.id===myId);if(!p&&!isHost)return res.status(403).json({error:'not_a_participant'});if(p){Object.assign(p,{seen:now});['mic','cam','sharing'].forEach(k=>{if(typeof body[k]==='boolean')p[k]=body[k];});await updateMeeting({participants:participants.map(JSON.stringify)});}return res.json({ok:true});}
  if(action==='signal'){
    if(!isHost&&!participants.some(p=>p.id===myId))return res.status(403).json({error:'not_a_participant'});
    const target=String(body.to||'');
    const targetIsHost=target===String(meeting.host_id);
    const targetIsParticipant=participants.some(p=>p.id===target);
    if(!target||(!targetIsHost&&!targetIsParticipant))return res.status(404).json({error:'signal_target_not_in_meeting'});
    const sig={from:myId,to:target,kind:String(body.kind||'ice').slice(0,32),payload:body.payload,at:now};
    const list=readList(meeting.signals).filter(s=>now-Number(s.at||0)<60000);
    list.push(sig);
    await updateMeeting({signals:list.slice(-300).map(JSON.stringify)});
    return res.json({ok:true});
  }
  if(action==='sync'||action==='state'){
    if(myId){let p=participants.find(p=>p.id===myId);if(!p||now-Number(p.seen||0)>10000){p={...(p||{}),id:myId,name:p?.name||String(body.name||'').trim()||user?.full_name||'مشارك',guest:p?!!p.guest:!isHost,host:p?!!p.host:isHost,mic:p?p.mic!==false:true,cam:!!p?.cam,sharing:!!p?.sharing,mutedByHost:!!p?.mutedByHost,joined:p?.joined||now,seen:now};participants=[...participants.filter(x=>x.id!==myId),p];}}
    const all=readList(meeting.signals);const mine=all.filter(s=>s.to===myId);await updateMeeting({participants:participants.map(JSON.stringify),signals:all.filter(s=>s.to!==myId&&now-Number(s.at||0)<60000).map(JSON.stringify)});
    return res.json({blocked:blocked.includes(myId),ended:meeting.status==='ended',meeting:state(meeting,participants),signals:mine});
  }
  if(action==='chat'){if(!isHost&&!participants.some(p=>p.id===myId))return res.status(403).json({error:'not_a_participant'});const chat=readList(meeting.chat);chat.push({id:`${now}-${Math.random().toString(36).slice(2,7)}`,from:myId,name:String(body.name||'').trim()||user?.full_name||'مشارك',kind:['image','file'].includes(body.kind)?body.kind:'text',text:String(body.text||'').slice(0,2000),media_url:String(body.media_url||''),media_name:String(body.media_name||''),at:now});await updateMeeting({chat:chat.slice(-200).map(JSON.stringify)});return res.json({ok:true});}
  if(action==='host'){
    if(!isHost)return res.status(403).json({error:'forbidden'});const target=String(body.target_id||'');const mode=String(body.mode||'');
    if(mode==='end'){await updateMeeting({status:'ended',ended_at:new Date().toISOString(),participants:[],signals:[]});return res.json({ok:true});}
    if(mode==='mute'||mode==='unmute'){participants=participants.map(p=>p.id===target?{...p,mic:mode==='unmute',mutedByHost:mode==='mute',seen:now}:p);await updateMeeting({participants:participants.map(JSON.stringify)});return res.json({ok:true});}
    if(mode==='block'){if(!blocked.includes(target))blocked.push(target);participants=participants.filter(p=>p.id!==target);await updateMeeting({blocked_ids:blocked,participants:participants.map(JSON.stringify)});return res.json({ok:true});}
    if(mode==='unblock'){await updateMeeting({blocked_ids:blocked.filter(x=>x!==target)});return res.json({ok:true});}
  }
  return res.status(400).json({error:'unknown_action'});
}

app.post('/api/functions/:name', async (req,res) => {
  const name=req.params.name;const body=req.body||{};const auth=readToken(req);
  if(name==='meetingRoom') {
    let user=null;
    if(auth){const q=await pool.query('SELECT id,email,phone,display_name FROM buk_standalone_accounts WHERE id=$1',[auth.sub]);if(q.rows[0])user={id:String(q.rows[0].id),email:q.rows[0].email||'',phone:q.rows[0].phone||'',full_name:q.rows[0].display_name||''};}
    return meetingFunction(body,user,res);
  }
  if(!auth)return res.status(401).json({error:'يجب تسجيل الدخول أولاً.'});
  const accountQ=await pool.query('SELECT id,email,phone,display_name FROM buk_standalone_accounts WHERE id=$1',[auth.sub]);
  if(!accountQ.rows[0])return res.status(401).json({error:'الحساب غير موجود.'});
  const account=accountQ.rows[0];
  const user={id:String(account.id),email:account.email||'',phone:account.phone||'',full_name:account.display_name||''};
  if(name==='phoneLogin'){
    const phone=normalizePhone(body.phone);const password=String(body.password||'');const q=await pool.query('SELECT * FROM buk_standalone_accounts WHERE phone=$1 LIMIT 1',[phone]);const a=q.rows[0];if(!a||!(await bcrypt.compare(password,a.password_hash)))return res.status(401).json({error:'invalid phone or password'});return res.json({access_token:tokenFor(a)});
  }
  if(name==='bukAssistant')return doAssistant(req,res,body,user);
  if(name==='contactInvite'){
    if(body.action==='match'){
      const keys=(Array.isArray(body.numbers)?body.numbers:[]).map(r=>String(r.phone||'').replace(/\D/g,'').slice(-9)).filter(x=>x.length>=7);
      const profiles=await visibleRows('BukProfile',user);const matches={};profiles.forEach(p=>{const k=String(p.phone_key||'');if(keys.includes(k)&&String(p.user_id)!==user.id)matches[k]={on_buk:true,user_id:p.user_id,display_name:p.display_name||'مستخدم BUK',avatar_url:p.avatar_url||''};});return res.json({matches});
    }
    if(body.action==='invite'){
      const sid=String(process.env.TWILIO_ACCOUNT_SID||'');const secret=String(process.env.TWILIO_AUTH_TOKEN||'');const from=String(process.env.TWILIO_SENDER_ID||'');if(!sid||!secret||!from)return res.status(503).json({error:'not_configured'});
      const phone=normalizePhone(body.phone);if(!phone)return res.status(400).json({error:'invalid_phone'});
      const sender=user.full_name||user.email?.split('@')[0]||'صديقك';const params=new URLSearchParams({To:phone,From:from,Body:`${sender} يدعوك إلى BUK للمحادثات والمكالمات.\n${PUBLIC_APP_URL||'https://buk.app'}`});
      const out=await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`,{method:'POST',headers:{Authorization:`Basic ${Buffer.from(`${sid}:${secret}`).toString('base64')}`,'Content-Type':'application/x-www-form-urlencoded'},body:params});if(!out.ok){const e=await out.json().catch(()=>({}));return res.status(502).json({error:e.message||'send_failed'});}return res.json({ok:true});
    }
    return res.status(400).json({error:'unknown_action'});
  }
  return res.status(404).json({error:`الوظيفة ${name} غير متاحة في الخلفية المستقلة.`});
});

app.get('/api/users/search', requireAuth, async (req,res) => {
  const term=String(req.query.q||'').trim().toLowerCase();if(term.length<2)return res.json({users:[]});
  try{const q=await pool.query('SELECT id,email,phone,display_name FROM buk_standalone_accounts WHERE id<>$1 AND POSITION($2 IN LOWER(display_name))>0 ORDER BY display_name LIMIT 30',[req.auth.sub,term]);res.json({users:q.rows.map(a=>({id:a.id,name:a.display_name,email:a.email}))});}
  catch(err){console.error(err.message);res.status(500).json({error:'تعذر البحث عن المستخدمين.'});}
});

const distDir=path.resolve(__dirname,'..','dist');
app.use(express.static(distDir,{index:false,fallthrough:true}));
app.use((req,res,next)=>{
  if(req.method!=='GET'||req.path.startsWith('/api/'))return next();
  const index=path.join(distDir,'index.html');if(fs.existsSync(index))return res.sendFile(index);return res.status(404).send('BUK frontend is not built. Run npm run build.');
});
app.use((err,_req,res,_next)=>{console.error('Unhandled request error:',err.message);if(res.headersSent)return;res.status(err.status||500).json({error:err.message||'حدث خطأ في الخادم.'});});

app.listen(PORT,'0.0.0.0',()=>console.log(`BUK Standalone API listening on ${PORT}`));
