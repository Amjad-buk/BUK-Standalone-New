'use strict';
const { Pool } = require('pg');
(async () => {
  const url = String(process.env.DATABASE_URL || '').trim();
  if (!url) {
    console.error('DATABASE_URL is missing. Copy .env.example to .env and configure PostgreSQL.');
    process.exit(2);
  }
  const pool = new Pool({
    connectionString: url,
    ssl: process.env.DATABASE_SSL === 'false' ? false : (process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined),
    connectionTimeoutMillis: 8000,
    max: 1
  });
  try {
    const result = await pool.query('SELECT current_database() AS database, NOW() AS server_time');
    console.log(JSON.stringify({ ok: true, database: result.rows[0].database, server_time: result.rows[0].server_time }, null, 2));
  } catch (error) {
    console.error('PostgreSQL connection failed:', error.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
