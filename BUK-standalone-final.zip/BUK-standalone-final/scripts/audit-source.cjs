'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const src = path.join(root, 'src');
const failures = [];
const sourceExtensions = new Set(['.js', '.jsx', '.ts', '.tsx']);
function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) return walk(full);
    return sourceExtensions.has(path.extname(entry.name)) ? [full] : [];
  });
}
for (const file of walk(src)) {
  const text = fs.readFileSync(file, 'utf8');
  const imports = text.matchAll(/(?:from\s*|import\s*\()\s*["']([^"']+)["']/g);
  for (const match of imports) {
    const specifier = match[1];
    if (!(specifier.startsWith('@/') || specifier.startsWith('.'))) continue;
    const base = specifier.startsWith('@/')
      ? path.join(src, specifier.slice(2))
      : path.resolve(path.dirname(file), specifier);
    const candidates = [base];
    for (const ext of ['.js', '.jsx', '.ts', '.tsx', '.json']) candidates.push(`${base}${ext}`);
    for (const ext of ['.js', '.jsx', '.ts', '.tsx']) candidates.push(path.join(base, `index${ext}`));
    if (!candidates.some((candidate) => fs.existsSync(candidate))) {
      failures.push(`${path.relative(root, file)} -> ${specifier}`);
    }
  }
}
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
if (Object.keys(deps).some((name) => name.startsWith('@base44/'))) failures.push('Base44 SDK/runtime dependency remains in package.json');
if (failures.length) {
  console.error(`Source audit failed (${failures.length} issue(s)):`);
  failures.forEach((failure) => console.error(`- ${failure}`));
  process.exit(1);
}
console.log(`Source audit passed: ${walk(src).length} JS/JSX/TS/TSX files; no missing local imports or Base44 SDK dependencies.`);
