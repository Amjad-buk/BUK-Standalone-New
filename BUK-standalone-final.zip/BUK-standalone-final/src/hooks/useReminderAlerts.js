import { useCallback, useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { playTone, unlockAudio } from '@/lib/tone';
import { announce, primeSpeech, stopSpeaking } from '@/lib/speech';
import { ensureNotifyPermission, showSystemNotification } from '@/lib/notify';
import { dueFrom, fetchScheduledReminders, nextOccurrence } from '@/lib/reminders';

const RING_GAP = 2500;
const CHECK_MS = 10000;
/** مفتاح التذكير بعد رنّه حتى لا يتكرر في نفس الجلسة. */
const stampOf = (record) => `${record.id}|${record.at}`;

/**
 * محرك رنين التذكيرات — مفعّل دائمًا بلا أي إعداد من المستخدم:
 * مؤقت دقيق على لحظة الموعد، رنين ونطق متكرر، إشعار نظام خارج التطبيق،
 * وفحص فوري عند كل فتح أو عودة للتطبيق.
 */
export default function useReminderAlerts() {
  const { user, settings, L } = usePrefs();
  const [due, setDue] = useState(null);
  const dueRef = useRef(null);
  const timers = useRef([]);
  const nextTimer = useRef(null);
  const handled = useRef(new Set());

  const stop = useCallback(() => {
    timers.current.forEach(clearInterval);
    timers.current = [];
    stopSpeaking();
    if (navigator.vibrate) navigator.vibrate(0);
  }, []);

  const ring = useCallback(
    (tone) => {
      unlockAudio();
      playTone(tone || settings.reminder_tone);
      if (navigator.vibrate) navigator.vibrate([700, 250, 700]);
    },
    [settings.reminder_tone]
  );

  const speak = useCallback(
    (record) => {
      if (!record) return;
      announce(
        `${L('تذكير', 'Reminder')}: ${record.title}. ${L('حان الموعد الآن', 'It is due now')}`,
        settings.assistant_voice,
        settings.voice_gender
      );
    },
    [L, settings.assistant_voice, settings.voice_gender]
  );

  const start = useCallback(
    (record) => {
      stop();
      dueRef.current = record;
      setDue(record);
      unlockAudio();
      primeSpeech();
      ring(record.tone);
      speak(record);
      timers.current.push(setInterval(() => ring(record.tone), RING_GAP));
      timers.current.push(setInterval(() => speak(record), RING_GAP * 4));
      showSystemNotification(
        record.title || L('تذكير', 'Reminder'),
        L('حان موعد تذكيرك الآن', 'Your reminder is due now'),
        { tag: `buk-reminder-${record.id}` }
      );
    },
    [L, ring, speak, stop]
  );

  useEffect(() => {
    if (!user) return undefined;
    let alive = true;

    function schedule(records) {
      if (nextTimer.current) clearTimeout(nextTimer.current);
      nextTimer.current = null;
      const upcoming = records
        .map((record) => Date.parse(record.at))
        .filter((time) => Number.isFinite(time) && time > Date.now())
        .sort((a, b) => a - b)[0];
      if (!upcoming) return;
      // مؤقت على لحظة الموعد نفسها، فلا يضيع الرنين بسبب تباعد الفحص.
      const delay = Math.min(upcoming - Date.now(), 2147483000);
      nextTimer.current = setTimeout(() => {
        if (alive) check();
      }, delay);
    }

    async function check() {
      const records = await fetchScheduledReminders(user.id).catch(() => null);
      if (!alive || !records) return;
      schedule(records);
      const record = dueFrom(records).find((item) => !handled.current.has(stampOf(item)));
      if (!record) return;
      if (dueRef.current && dueRef.current.id === record.id) return;
      start(record);
    }

    check();
    ensureNotifyPermission().catch(() => {});

    const poller = setInterval(check, CHECK_MS);
    const wake = () => {
      if (document.visibilityState === 'visible') check();
    };
    document.addEventListener('visibilitychange', wake);
    window.addEventListener('focus', wake);
    window.addEventListener('pageshow', wake);
    window.addEventListener('online', wake);
    // الإشعارات والصوت يُفعَّلان تلقائيًا مع أول لمسة، دون أي إعداد من المستخدم.
    const prime = () => {
      unlockAudio();
      primeSpeech();
      ensureNotifyPermission().catch(() => {});
      check();
    };
    window.addEventListener('pointerdown', prime, { passive: true });
    window.addEventListener('touchstart', prime, { passive: true });
    window.addEventListener('keydown', prime);

    let unsubscribe = () => {};
    try {
      unsubscribe = base44.entities.Reminder.subscribe(() => check()) || (() => {});
    } catch {
      unsubscribe = () => {};
    }

    return () => {
      alive = false;
      clearInterval(poller);
      if (nextTimer.current) clearTimeout(nextTimer.current);
      nextTimer.current = null;
      document.removeEventListener('visibilitychange', wake);
      window.removeEventListener('focus', wake);
      window.removeEventListener('pageshow', wake);
      window.removeEventListener('online', wake);
      window.removeEventListener('pointerdown', prime);
      window.removeEventListener('touchstart', prime);
      window.removeEventListener('keydown', prime);
      try {
        unsubscribe();
      } catch {
        /* تجاهل */
      }
      stop();
    };
  }, [user, start, stop]);

  const dismiss = useCallback(() => {
    const record = dueRef.current;
    if (record) handled.current.add(stampOf(record));
    stop();
    dueRef.current = null;
    setDue(null);
  }, [stop]);

  const snooze = useCallback(async () => {
    const record = due;
    dismiss();
    if (!record) return;
    const at = new Date(Date.now() + 5 * 60000).toISOString();
    await base44.entities.Reminder.update(record.id, { at, alerted: false, status: 'scheduled' }).catch(() => {});
  }, [due, dismiss]);

  const complete = useCallback(async () => {
    const record = due;
    dismiss();
    if (!record) return;
    const next = nextOccurrence(record.at, record.repeat);
    await base44.entities.Reminder.update(
      record.id,
      next ? { at: next.toISOString(), alerted: false, status: 'scheduled' } : { status: 'done', alerted: true }
    ).catch(() => {});
  }, [due, dismiss]);

  const replay = useCallback(() => {
    if (!due) return;
    ring(due.tone);
    speak(due);
  }, [due, ring, speak]);

  return { due, snooze, complete, replay };
}