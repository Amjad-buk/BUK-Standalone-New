import { useCallback, useEffect, useRef, useState } from 'react';
import { roomApi } from '@/lib/meeting';

/**
 * خوادم الاتصال: STUN لاكتشاف العنوان، وTURN لتمرير الصوت والفيديو
 * عندما يكون أحد الطرفين خلف شبكة خلوية أو NAT متماثل.
 */
const RTC_CONFIG = {
  iceCandidatePoolSize: 4,
  iceServers: [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
    { urls: 'stun:stun.cloudflare.com:3478' },
    // خادم تمرير عام مفتوح: بدون تمرير يعمل لا تتصل الكاميرا والصوت
    // عندما يكون أحد الطرفين على شبكة خلوية (NAT متماثل) — وهي حالة أغلب الجوالات.
    {
      urls: [
        'turn:openrelay.metered.ca:80',
        'turn:openrelay.metered.ca:443',
        'turn:openrelay.metered.ca:443?transport=tcp'
      ],
      username: 'openrelayproject',
      credential: 'openrelayproject'
    },
    // بديل احتياطي للشبكات الخلوية التي تمنع الاتصال المباشر.
    {
      urls: ['turn:turn.anyfirewall.com:443?transport=tcp', 'turns:turn.anyfirewall.com:443?transport=tcp'],
      username: 'webrtc',
      credential: 'webrtc'
    }
  ]
};

const POLL_MS = 900;


const cameraMessage =
  'لم يسمح المتصفح بالكاميرا والميكروفون. اضغط أيقونة القفل بجانب العنوان، اسمح بهما، ثم اضغط «السماح والمحاولة».';

/** محرك الغرفة: الحضور، الفيديو المتعدد، الكاميرا والشاشة، والتحكم بالصوت. */
export default function useMeetingRoom({ code, identity }) {
  const myId = identity.id;
  const myName = identity.name;

  const [meeting, setMeeting] = useState(null);
  const [peers, setPeers] = useState({});
  const [peerStates, setPeerStates] = useState({});
  const [localStream, setLocalStream] = useState(null);
  const [notice, setNotice] = useState('');
  const [mediaError, setMediaError] = useState('');
  const [mediaAsked, setMediaAsked] = useState(false);
  const [joined, setJoined] = useState(false);
  const [ended, setEnded] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(false);
  const [facing, setFacing] = useState('user');
  const [sharing, setSharing] = useState(false);
  const [mutedByHost, setMutedByHost] = useState(false);
  // عدّاد إشارات الشبكة الواصلة — يوضّح إن كان التبادل يجري أصلًا.
  const [signalCount, setSignalCount] = useState(0);

  const streamRef = useRef(null);
  const cameraRef = useRef(null);
  const screenRef = useRef(null);
  const pcsRef = useRef(new Map());
  // حالة التفاوض لكل مشارك: من يبدأ العرض، والمرشحات المنتظرة، ومسارات الإرسال.
  const metaRef = useRef(new Map());
  // مراقبة الوسائط الواصلة من كل مشارك: متصل بلا صوت ولا صورة يعني اتصالًا تالفًا.
  const inboundRef = useRef(new Map());
  const syncRef = useRef(null);
  const camRef = useRef(false);
  const facingRef = useRef('user');
  const sharingRef = useRef(false);
  const mutedRef = useRef(false);
  const shareToggleRef = useRef(null);
  const rebuildRef = useRef(null);

  /**
   * نضع مسار الصوت والفيديو في قناة الإرسال مباشرة بدل addTrack،
   * فتبقى القنوات مفتوحة حتى لو لم تكن الكاميرا جاهزة وقت الاتصال،
   * وتُبثّ فور توفرها دون إعادة اتصال.
   */
  const attachMedia = useCallback((peerId) => {
    const slots = metaRef.current.get(peerId);
    if (!slots || !slots.audio || !slots.video) return;
    const stream = streamRef.current;
    const audio = stream ? stream.getAudioTracks()[0] || null : null;
    const video = sharingRef.current && screenRef.current
      ? screenRef.current
      : stream
        ? stream.getVideoTracks()[0] || null
        : null;
    slots.audio.sender.replaceTrack(audio).catch(() => {});
    slots.video.sender.replaceTrack(video).catch(() => {});
    // نثبّت الاتجاه على الإرسال والاستقبال حتى لا يخرج العرض أو الرد بأحادية اتجاه
    // فيمنع أحد الطرفين من إرسال صوته وصورته.
    slots.audio.direction = 'sendrecv';
    slots.video.direction = 'sendrecv';
  }, []);

  const publishAll = useCallback(() => {
    pcsRef.current.forEach((_, peerId) => attachMedia(peerId));
  }, [attachMedia]);

  useEffect(() => {
    let alive = true;
    let timer = null;

    const sendSignal = (to, kind, payload) => {
      roomApi('signal', { code, from: myId, to, kind, payload }).catch(() => {});
    };

    const bindStream = (next) => {
      streamRef.current = next;
      setLocalStream(next);
    };

    /** إرسال عرض اتصال جديد — الطرف غير المهذّب فقط هو من يبدأ. */
    const offerNow = async (peerId, pc, meta) => {
      if (meta.polite || pc.signalingState !== 'stable') return;
      try {
        meta.makingOffer = true;
        await pc.setLocalDescription();
        if (pc.localDescription) sendSignal(peerId, 'description', pc.localDescription.toJSON());
        meta.createdAt = Date.now();
      } catch {
        /* الجولة القادمة */
      } finally {
        meta.makingOffer = false;
      }
    };

    const createPeer = (peerId) => {
      const pc = new RTCPeerConnection(RTC_CONFIG);
      pcsRef.current.set(peerId, pc);

      /**
       * تفاوض قياسي (perfect negotiation): طرف واحد يبدأ العرض، والطرف الآخر
       * يتراجع عند التعارض بدل أن يجمُد الاثنان بلا صوت ولا صورة.
       */
      const meta = {
        polite: String(myId) > String(peerId),
        makingOffer: false,
        ignoreOffer: false,
        audio: null,
        video: null,
        pendingIce: []
      };
      metaRef.current.set(peerId, meta);

      const stream = streamRef.current;
      const localAudio = stream ? stream.getAudioTracks()[0] || null : null;
      const localVideo =
        sharingRef.current && screenRef.current
          ? screenRef.current
          : stream
            ? stream.getVideoTracks()[0] || null
            : null;
      // نضيف قناتي الصوت والصورة دائمًا (حتى قبل توفر الكاميرا) ثم نضع المسار فيهما،
      // فتصل الصورة والصوت فور توفرهما دون إعادة اتصال.
      meta.audio = pc.addTransceiver(localAudio || 'audio', { direction: 'sendrecv' });
      meta.video = pc.addTransceiver(localVideo || 'video', { direction: 'sendrecv' });
      attachMedia(peerId);

      pc.onicecandidate = (event) => {
        if (event.candidate) sendSignal(peerId, 'candidate', event.candidate.toJSON());
      };

      meta.createdAt = Date.now();
      pc.onnegotiationneeded = () => {
        offerNow(peerId, pc, meta);
      };

      pc.ontrack = (event) => {
        const remote = event.streams && event.streams[0];
        setPeers((prev) => {
          if (remote) return { ...prev, [peerId]: remote };
          const existing = prev[peerId] || new MediaStream();
          if (!existing.getTracks().includes(event.track)) existing.addTrack(event.track);
          return { ...prev, [peerId]: existing };
        });
      };

      const trackState = () => {
        const state =
          pc.connectionState === 'failed' || pc.iceConnectionState === 'failed'
            ? 'failed'
            : pc.connectionState === 'connected' || pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed'
              ? 'connected'
              : pc.connectionState === 'disconnected' || pc.iceConnectionState === 'disconnected'
                ? 'disconnected'
                : 'connecting';
        setPeerStates((prev) => ({ ...prev, [peerId]: state }));
        if (state === 'connected') setNotice('');
      };
      pc.oniceconnectionstatechange = trackState;
      trackState();

      pc.onconnectionstatechange = () => {
        trackState();
        if (pc.connectionState !== 'failed') return;
        setNotice('الشبكة تمنع الاتصال المباشر — جرّب شبكة Wi-Fi أو أعد المحاولة بعد لحظات.');
        if (pcsRef.current.get(peerId) === pc) pcsRef.current.delete(peerId);
        metaRef.current.delete(peerId);
        try {
          pc.close();
        } catch {
          /* أُغلق مسبقًا */
        }
        setPeers((prev) => {
          const next = { ...prev };
          delete next[peerId];
          return next;
        });
      };

      return pc;
    };

    const closePeer = (peerId) => {
      const pc = pcsRef.current.get(peerId);
      if (pc) {
        try {
          pc.close();
        } catch {
          /* أُغلق مسبقًا */
        }
        pcsRef.current.delete(peerId);
      }
      metaRef.current.delete(peerId);
      const previousInbound = inboundRef.current.get(peerId);
      inboundRef.current.set(peerId, { bytes: 0, at: 0, tries: previousInbound ? previousInbound.tries : 0 });
      setPeers((prev) => {
        const next = { ...prev };
        delete next[peerId];
        return next;
      });
      setPeerStates((prev) => {
        const next = { ...prev };
        delete next[peerId];
        return next;
      });
    };

    /**
     * استقبال إشارة من مشارك:وصف اتصال (عرض/رد) أو مرشح شبكة.
     * نطبّق قاعدة perfect negotiation كما هي معروفة في WebRTC.
     */
    const handleSignal = async (signal) => {
      const peerId = signal.from;
      if (!peerId || peerId === myId) return;
      const pc = pcsRef.current.get(peerId) || createPeer(peerId);
      const meta = metaRef.current.get(peerId);
      if (!meta) return;
      setSignalCount((count) => count + 1);
      try {
        if (signal.kind === 'description') {
          const description = signal.payload;
          if (!description || !description.type) return;
          const collision =
            description.type === 'offer' && (meta.makingOffer || pc.signalingState !== 'stable');
          meta.ignoreOffer = !meta.polite && collision;
          if (meta.ignoreOffer) return;
          if (collision && meta.polite) {
            // المهذّب يتراجع عن عرضه المتعارض ليقبل عرض الطرف الآخر.
            await pc.setLocalDescription({ type: 'rollback' }).catch(() => {});
          }
          await pc.setRemoteDescription(description);
          if (meta.pendingIce.length) {
            const queued = meta.pendingIce.splice(0, meta.pendingIce.length);
            for (const candidate of queued) {
              await pc.addIceCandidate(candidate).catch(() => {});
            }
          }
          if (description.type === 'offer') {
            await pc.setLocalDescription();
            if (pc.localDescription) sendSignal(peerId, 'description', pc.localDescription.toJSON());
          }
        } else if (signal.kind === 'candidate' || signal.kind === 'ice') {
          if (!signal.payload) return;
          if (!pc.remoteDescription || !pc.remoteDescription.type) {
            meta.pendingIce.push(signal.payload);
          } else {
            await pc.addIceCandidate(signal.payload).catch(() => {});
          }
        }
      } catch {
        /* إشارة متأخرة أو مكررة */
      }
    };

    /** ينشئ الاتصال إن لم يكن موجودًا ويحدّث مساري الإرسال — التفاوض يبدأ تلقائيًا بعدها. */
    const ensureConnection = (peerId) => {
      const existing = pcsRef.current.get(peerId);
      if (!existing) {
        createPeer(peerId);
        return;
      }
      attachMedia(peerId);
      const meta = metaRef.current.get(peerId);
      if (!meta) return;
      // ضاعت إشارة أو لم يصل العرض: نعيد المحاولة كل ست ثوانٍ حتى يبدأ التفاوض.
      if (Date.now() - meta.createdAt <= 6000) return;
      if (existing.signalingState === 'have-local-offer' && !existing.remoteDescription) {
        // عرض أُرسل ولم يصل ردّه: نعيد إرساله بدل البقاء معلّقين بلا صورة ولا صوت.
        if (existing.localDescription) sendSignal(peerId, 'description', existing.localDescription.toJSON());
        meta.createdAt = Date.now();
        return;
      }
      if (existing.signalingState === 'stable' && !existing.remoteDescription) {
        meta.createdAt = Date.now();
        offerNow(peerId, existing, meta);
      }
    };

    /**
     * إن كان الاتصال قائمًا والمشارك يبثّ فعلًا لكن لا تصل منه أي بايتات،
     * نعيد بناء الاتصال (مرتين فقط) حتى لا يبقى المضيف بشاشة سوداء بلا صوت.
     */
    const watchInbound = async (peerId, pc, person) => {
      if (!person || (!person.mic && !person.cam)) return;
      const entry = inboundRef.current.get(peerId) || { bytes: 0, at: 0, tries: 0 };
      // أول مرة نبدأ العدّاد فقط: نمنح الاتصال ست ثوانٍ قبل الحكم عليه.
      if (!entry.at) {
        entry.at = Date.now();
        inboundRef.current.set(peerId, entry);
        return;
      }
      if (Date.now() - entry.at < 6000) return;
      entry.at = Date.now();
      inboundRef.current.set(peerId, entry);
      let bytes = 0;
      try {
        const stats = await pc.getStats();
        stats.forEach((report) => {
          if (report.type === 'inbound-rtp' && typeof report.bytesReceived === 'number') bytes += report.bytesReceived;
        });
      } catch {
        return;
      }
      if (bytes > entry.bytes) {
        entry.bytes = bytes;
        entry.tries = 0;
        return;
      }
      if (pc.connectionState !== 'connected' || entry.tries >= 2) return;
      entry.tries += 1;
      closePeer(peerId);
      if (syncRef.current) syncRef.current().catch(() => {});
    };

    const sync = async () => {
      // طلب واحد يجلب الحضور والإشارات ويحدّث حضوري معًا.
      const data = await roomApi('sync', { code, id: myId, name: myName });
      if (!alive) return;
      if (data.error === 'not_found') {
        setNotice('هذا الاجتماع غير موجود أو انتهى.');
        return;
      }
      if (data.blocked) {
        setBlocked(true);
        return;
      }
      if (data.ended) {
        setEnded(true);
        return;
      }
      const room = data.meeting;
      if (!room) return;
      setMeeting(room);

      const mine = (room.participants || []).find((p) => p.id === myId);
      if (mine && mine.mutedByHost !== mutedRef.current) {
        mutedRef.current = mine.mutedByHost;
        setMutedByHost(mine.mutedByHost);
        const track = streamRef.current && streamRef.current.getAudioTracks()[0];
        if (mine.mutedByHost && track) {
          track.enabled = false;
          setMicOn(false);
        }
      }

      const live = new Set();
      (room.participants || []).forEach((person) => {
        if (person.id === myId) return;
        live.add(person.id);
        ensureConnection(person.id);
        const pc = pcsRef.current.get(person.id);
        if (pc) watchInbound(person.id, pc, person).catch(() => {});
      });
      Array.from(pcsRef.current.keys()).forEach((peerId) => {
        if (!live.has(peerId)) closePeer(peerId);
      });

      for (const signal of data.signals || []) await handleSignal(signal);
    };
    syncRef.current = sync;
    // عند الحصول على كاميرا أو ميكروفون بعد بدء الاجتماع نعيد بناء الاتصالات
    // حتى يبدأ البث فورًا بدل انتظار إعادة مفاوضة معقدة.
    rebuildRef.current = () => {
      Array.from(pcsRef.current.keys()).forEach(closePeer);
      metaRef.current.clear();
      sync().catch(() => {});
    };

    const loop = async () => {
      try {
        await sync();
      } catch {
        /* انقطاع مؤقت في الشبكة */
      }
      if (alive) timer = setTimeout(loop, POLL_MS);
    };

    const acquire = async (withVideo) => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setMediaError('UnsupportedError');
        return null;
      }
      if (withVideo) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            audio: { echoCancellation: true, noiseSuppression: true },
            video: { facingMode: 'user' }
          });
          setMediaError('');
          return stream;
        } catch (error) {
          setMediaError((error && error.name) || 'NotAllowedError');
        }
      }
      try {
        const audioOnly = await navigator.mediaDevices.getUserMedia({ audio: true });
        return audioOnly;
      } catch (error) {
        setMediaError((error && error.name) || 'NotAllowedError');
        return null;
      }
    };

    const start = async () => {
      // نطلب الإذن، لكن لا نعلّق دخول الغرفة على رد المتصفح:
      // إن ظلّت نافذة الإذن مفتوحة أو تأخر الجهاز يبقى المستخدم خارج الاجتماع بلا سبب.
      const mediaPromise = acquire(true);

      const result = await roomApi('join', {
        code,
        id: myId,
        name: myName,
        cam: false,
        mic: false
      }).catch(() => ({}));

      if (!alive) return;
      if (result.error === 'not_found') {
        setNotice('هذا الاجتماع غير موجود أو انتهى.');
        return;
      }
      if (result.error === 'full') {
        setNotice('الغرفة ممتلئة — الحد الأقصى 12 مشاركًا.');
        return;
      }
      if (result.blocked) {
        setBlocked(true);
        return;
      }
      if (result.ended) {
        setEnded(true);
        return;
      }
      setJoined(true);
      loop();

      // بعد الدخول ننتظر نتيجة طلب الكاميرا والميكروفون ثم نبدأ البث فورًا.
      const stream = await mediaPromise;
      if (!alive) {
        if (stream) stream.getTracks().forEach((track) => track.stop());
        return;
      }
      setMediaAsked(true);
      if (!stream) return;
      cameraRef.current = stream.getVideoTracks()[0] || null;
      camRef.current = !!cameraRef.current;
      setCamOn(!!cameraRef.current);
      bindStream(stream);
      roomApi('media', {
        code,
        id: myId,
        cam: !!cameraRef.current,
        mic: stream.getAudioTracks().length > 0
      }).catch(() => {});
      if (rebuildRef.current) rebuildRef.current();
    };

    start();

    return () => {
      alive = false;
      rebuildRef.current = null;
      if (timer) clearTimeout(timer);
      roomApi('leave', { code, id: myId }).catch(() => {});
      pcsRef.current.forEach((pc) => {
        try {
          pc.close();
        } catch {
          /* أُغلق مسبقًا */
        }
      });
      pcsRef.current.clear();
      metaRef.current.clear();
      const stream = streamRef.current;
      if (stream) stream.getTracks().forEach((track) => track.stop());
      if (screenRef.current) screenRef.current.stop();
    };
  }, [code, myId, myName, attachMedia]);

  const refresh = useCallback(() => {
    if (syncRef.current) syncRef.current().catch(() => {});
  }, []);

  const toggleMic = useCallback(async () => {
    let track = streamRef.current ? streamRef.current.getAudioTracks()[0] : null;
    if (!track) {
      try {
        const fresh = await navigator.mediaDevices.getUserMedia({ audio: true });
        track = fresh.getAudioTracks()[0];
        const next = new MediaStream([track, ...(streamRef.current ? streamRef.current.getVideoTracks() : [])]);
        streamRef.current = next;
        setLocalStream(next);
        publishAll();
        if (rebuildRef.current) rebuildRef.current();
      } catch {
        setNotice('الميكروفون ممنوع من المتصفح — اسمح به ثم أعد المحاولة.');
        return;
      }
    }
    track.enabled = !track.enabled;
    setMicOn(track.enabled);
    if (track.enabled) {
      mutedRef.current = false;
      setMutedByHost(false);
    }
    roomApi('media', { code, id: myId, mic: track.enabled }).catch(() => {});
  }, [code, myId, publishAll]);

  const toggleCam = useCallback(async () => {
    let track = cameraRef.current;
    if (!track) {
      try {
        const fresh = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        track = fresh.getVideoTracks()[0];
        cameraRef.current = track;
        const next = new MediaStream([...(streamRef.current ? streamRef.current.getAudioTracks() : []), track]);
        streamRef.current = next;
        setLocalStream(next);
        publishAll();
        camRef.current = true;
        setCamOn(true);
        setNotice('');
        roomApi('media', { code, id: myId, cam: true }).catch(() => {});
        if (rebuildRef.current) rebuildRef.current();
      } catch {
        setNotice('تعذر تشغيل الكاميرا — تأكد من إذن الكاميرا في المتصفح.');
      }
      return;
    }
    const next = !track.enabled;
    track.enabled = next;
    camRef.current = next;
    setCamOn(next);
    roomApi('media', { code, id: myId, cam: next }).catch(() => {});
  }, [code, myId, publishAll]);

  /** محاولة جديدة لفتح الكاميرا والميكروفون بعد منح الإذن. */
  const retryMedia = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
        video: { facingMode: 'user' }
      });
      const old = streamRef.current;
      if (old) old.getTracks().forEach((track) => track.stop());
      cameraRef.current = stream.getVideoTracks()[0] || null;
      camRef.current = !!cameraRef.current;
      setCamOn(!!cameraRef.current);
      setMicOn(true);
      streamRef.current = stream;
      setLocalStream(stream);
      publishAll();
      setNotice('');
      roomApi('media', { code, id: myId, cam: !!cameraRef.current, mic: true }).catch(() => {});
      if (rebuildRef.current) rebuildRef.current();
    } catch {
      setNotice(cameraMessage);
    }
  }, [code, myId, publishAll]);

  /** تبديل الكاميرا: يختار الكاميرا التالية المتاحة ويعيد بثها للمشاركين فورًا. */
  const switchCamera = useCallback(async () => {
    try {
      const stream = streamRef.current;
      const previous = cameraRef.current;
      const settings = previous && previous.getSettings ? previous.getSettings() : {};
      const devices = await navigator.mediaDevices.enumerateDevices().catch(() => []);
      const cameras = devices.filter((device) => device.kind === 'videoinput' && device.deviceId);

      let videoConstraints = { facingMode: { ideal: facingRef.current === 'user' ? 'environment' : 'user' } };
      if (cameras.length > 1) {
        const index = cameras.findIndex((device) => device.deviceId === settings.deviceId);
        const nextDevice = cameras[(index + 1) % cameras.length];
        videoConstraints = { deviceId: { exact: nextDevice.deviceId } };
      }

      const needAudio = !stream || stream.getAudioTracks().length === 0;
      const fresh = await navigator.mediaDevices.getUserMedia(
        needAudio ? { audio: true, video: videoConstraints } : { video: videoConstraints }
      );

      const nextTrack = fresh.getVideoTracks()[0];
      if (!nextTrack) throw new Error('no_camera');
      fresh.getVideoTracks().slice(1).forEach((extra) => extra.stop());
      nextTrack.enabled = true;

      const next = new MediaStream();
      const audio = needAudio ? fresh.getAudioTracks()[0] : stream.getAudioTracks()[0];
      if (audio) next.addTrack(audio);
      next.addTrack(nextTrack);
      if (sharingRef.current && screenRef.current) next.addTrack(screenRef.current);

      if (previous && previous !== nextTrack) previous.stop();
      cameraRef.current = nextTrack;
      camRef.current = true;
      setCamOn(true);
      streamRef.current = next;
      setLocalStream(next);
      publishAll();

      if (!videoConstraints.deviceId) {
        facingRef.current = facingRef.current === 'user' ? 'environment' : 'user';
      }
      setFacing(facingRef.current);
      setNotice('');
      roomApi('media', { code, id: myId, cam: true }).catch(() => {});
      if (!previous && rebuildRef.current) rebuildRef.current();
    } catch {
      setNotice('لم أتمكن من تبديل الكاميرا — قد يملك هذا الجهاز كاميرا واحدة، أو أن الكاميرا الأخرى مشغولة.');
    }
  }, [code, myId, publishAll]);

  const toggleShare = useCallback(async () => {
    const stream = streamRef.current;
    if (!stream) return;
    if (sharingRef.current) {
      if (screenRef.current) {
        screenRef.current.stop();
        screenRef.current = null;
      }
      sharingRef.current = false;
      setSharing(false);
      const rebuilt = new MediaStream([...stream.getAudioTracks(), ...(cameraRef.current ? [cameraRef.current] : [])]);
      streamRef.current = rebuilt;
      setLocalStream(rebuilt);
      publishAll();
      roomApi('media', { code, id: myId, sharing: false }).catch(() => {});
      return;
    }
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      const screen = display.getVideoTracks()[0];
      if (!screen) return;
      screenRef.current = screen;
      screen.onended = () => {
        if (sharingRef.current && shareToggleRef.current) shareToggleRef.current();
      };
      sharingRef.current = true;
      setSharing(true);
      const rebuilt = new MediaStream([...stream.getAudioTracks(), screen]);
      streamRef.current = rebuilt;
      setLocalStream(rebuilt);
      publishAll();
      roomApi('media', { code, id: myId, sharing: true }).catch(() => {});
    } catch {
      setNotice('المتصفح لم يمنح إذن مشاركة الشاشة.');
    }
  }, [code, myId, publishAll]);

  shareToggleRef.current = toggleShare;

  const hostAction = useCallback(
    async (mode, targetId) => {
      await roomApi('host', { code, mode, target_id: targetId }).catch(() => {});
      refresh();
    },
    [code, refresh]
  );

  return {
    meeting,
    peers,
    peerStates,
    localStream,
    notice,
    mediaError,
    mediaAsked,
    joined,
    ended,
    blocked,
    micOn,
    camOn,
    facing,
    sharing,
    mutedByHost,
    signalCount,
    toggleMic,
    toggleCam,
    switchCamera,
    retryMedia,
    toggleShare,
    hostAction,
    refresh
  };
}