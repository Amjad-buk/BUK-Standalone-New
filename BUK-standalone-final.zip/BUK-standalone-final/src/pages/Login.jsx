import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Loader2 } from "lucide-react";
import PasswordInput from "@/components/auth/PasswordInput";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import PhoneLoginForm from "@/components/auth/PhoneLoginForm";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Login() {
  const [method, setMethod] = useState("email");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const returnTo = safeReturnTo();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = returnTo;
    } catch (err) {
      setError(err.message || "البريد الإلكتروني أو كلمة المرور غير صحيحة");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    setError("تسجيل الدخول عبر Google يحتاج إعداد OAuth خاصًا بالخادم المستقل.");
  };

  return (
    <AuthLayout
      title="تسجيل الدخول"
      subtitle={method === "email" ? "أدخل بريدك الإلكتروني وكلمة المرور للمتابعة إلى BUK." : "أدخل رقم هاتفك وكلمة المرور للمتابعة إلى BUK."}
      footer={
        <>
          ليس لديك حساب؟{" "}
          <Link
            to={"/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")}
            className="text-primary font-medium hover:underline"
          >
            إنشاء حساب
          </Link>
        </>
      }
    >
      <Button
        variant="outline"
        className="w-full h-12 text-sm font-medium mb-6"
        onClick={handleGoogle}
      >
        <GoogleIcon className="w-5 h-5 me-2" />
        المتابعة بحساب Google
      </Button>

      <div className="relative mb-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs">
          <span className="bg-card px-3 text-muted-foreground">أو</span>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 gap-2 mb-5">
        <Button
          type="button"
          variant={method === "email" ? "default" : "outline"}
          className="h-11"
          onClick={() => { setMethod("email"); setError(""); }}
        >
          البريد الإلكتروني
        </Button>
        <Button
          type="button"
          variant={method === "phone" ? "default" : "outline"}
          className="h-11"
          onClick={() => { setMethod("phone"); setError(""); }}
        >
          رقم الهاتف
        </Button>
      </div>

      {method === "phone" ? <PhoneLoginForm returnTo={returnTo} /> : (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">البريد الإلكتروني</Label>
          <div className="relative">
            <Mail className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              autoFocus
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="ps-10 h-12"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">كلمة المرور</Label>
            <Link to="/forgot-password" className="text-xs text-primary hover:underline">
              نسيت كلمة المرور؟
            </Link>
          </div>
          <PasswordInput
            id="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 me-2 animate-spin" />
              جارٍ الدخول…
            </>
          ) : (
            "تسجيل الدخول"
          )}
        </Button>
      </form>
      )}
    </AuthLayout>
  );
}