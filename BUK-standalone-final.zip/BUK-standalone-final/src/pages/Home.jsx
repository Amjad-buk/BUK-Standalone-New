import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { Image } from '@/components/ui/image';

const TILES = [
  { to: '/chats', icon: '💬', ar: 'المحادثات', en: 'Chats' },
  { to: '/friends', icon: '👥', ar: 'الأصدقاء', en: 'Friends' },
  { to: '/calls', icon: '☎️', ar: 'المكالمات', en: 'Calls' },
  { to: '/games', icon: '🎮', ar: 'ألعاب وترفيه', en: 'Games & fun' }
];

/** الرئيسية بتصميم BUK: شريط المستخدم ثم بطاقات الخدمات السبع. */
export default function Home() {
  const { user, settings, L } = usePrefs();
  const navigate = useNavigate();
  const [notifCount, setNotifCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    base44.entities.Notification.count({ user_id: user.id, read: false })
      .then(setNotifCount)
      .catch(() => setNotifCount(0));
  }, [user]);

  const name = settings.display_name || (user && (user.full_name || user.email)) || 'مستخدم BUK';

  return (
    <section>
      <header className="buk-userbar">
        <div className="buk-userinfo">
          <div className="buk-userphoto">
            {settings.avatar_url
              ? <Image src={settings.avatar_url} alt={name} fittingType="fill" className="w-full h-full" />
              : '👤'}
          </div>
          <div className="buk-usertext">
            <b>{name}</b>
            <span><i className="buk-online-dot" />{L('متصل الآن', 'Online now')}</span>
          </div>
        </div>
        <div className="buk-head-actions">
          <button type="button" className="buk-head-icon" onClick={() => navigate('/search')}
            aria-label={L('بحث', 'Search')} title={L('بحث', 'Search')}>⌕</button>
          <button type="button" className="buk-head-icon" onClick={() => navigate('/notifications')}
            aria-label={L('الإشعارات الواردة', 'Notifications')} title={L('الإشعارات الواردة', 'Notifications')}>
            ♧
            {notifCount ? <span className="buk-notify-count">{notifCount}</span> : null}
          </button>
          <button type="button" className="buk-head-icon" onClick={() => navigate('/settings')}
            aria-label={L('الإعدادات', 'Settings')} title={L('الإعدادات', 'Settings')}>⚙</button>
        </div>
      </header>

      <div className="buk-tiles">
        {TILES.map((tile) => (
          <button key={tile.to} type="button" className="buk-tile" onClick={() => navigate(tile.to)}>
            <span className="ico-glow">{tile.icon}</span>
            <b>{L(tile.ar, tile.en)}</b>
          </button>
        ))}

        <button type="button" className="buk-tile hl" onClick={() => navigate('/meeting')}>
          <span className="ico-glow">👥</span>
          <b>BUK Meeting Room</b>
        </button>

        <button type="button" className="buk-tile hl small" onClick={() => navigate('/mypuki')}>
          <span className="ico-glow">✨</span>
          <b>My BUKI</b>
        </button>

        <button type="button" className="buk-tile hl live-compact" onClick={() => navigate('/contacts')}>
          <span className="ico-glow">📇</span>
          <b>مزامنة جهات الاتصال</b>
        </button>

        <button type="button" className="buk-tile hl live-compact" onClick={() => navigate('/live')}>
          <b>BUK مباشر</b>
          <span className="ico-glow">🔴</span>
        </button>
      </div>
    </section>
  );
}