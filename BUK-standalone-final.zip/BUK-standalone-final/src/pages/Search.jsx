import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { conversationIcon, conversationTitle } from '@/lib/chat';

const TABS = [
  { id: 'people', ar: 'الأشخاص', en: 'People' },
  { id: 'chats', ar: 'المحادثات', en: 'Chats' },
  { id: 'channels', ar: 'القنوات', en: 'Channels' }
];

export default function Search() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [tab, setTab] = useState('people');
  const [term, setTerm] = useState('');
  const [people, setPeople] = useState([]);
  const [chats, setChats] = useState([]);
  const [channels, setChannels] = useState([]);
  const [status, setStatus] = useState('');

  const run = async (which) => {
    const value = term.trim();
    if (value.length < 2) { setStatus('اكتب حرفين على الأقل.'); return; }
    setStatus('');
    if (which === 'people') {
      const page = await base44.entities.BukProfile.filter({ display_name: { $regex: value } }, { limit: 20 });
      setPeople((page.items || []).filter((r) => r.user_id !== (user && user.id)));
    }
    if (which === 'chats') {
      const page = await base44.entities.Conversation.filter({ member_ids: user.id, last_message_text: { $regex: value } }, { limit: 20 });
      setChats(page.items || []);
    }
    if (which === 'channels') {
      const page = await base44.entities.Conversation.filter({ type: 'channel', title: { $regex: value } }, { limit: 20 });
      setChannels(page.items || []);
    }
  };

  return (
    <section>
      <h2 className="buk-title">{L('البحث', 'Search')}</h2>
      <div className="buk-tiles" style={{ gridTemplateColumns: 'repeat(3, minmax(0,1fr))' }}>
        {TABS.map((item) => (
          <button key={item.id} type="button" className={`buk-btn ${tab === item.id ? '' : 'secondary'}`} onClick={() => { setTab(item.id); setStatus(''); }}>
            {L(item.ar, item.en)}
          </button>
        ))}
      </div>

      <div className="buk-search">
        <input value={term} onChange={(e) => setTerm(e.target.value)} placeholder={L('اكتب اسمًا أو كلمة', 'Type a name or a word')} />
        <button type="button" className="buk-btn" onClick={() => run(tab)}>{L('بحث', 'Search')}</button>
      </div>
      {status ? <div className="buk-note">{status}</div> : null}

      {tab === 'people' ? (
        <div className="buk-card">
          {!people.length ? <p className="buk-muted">{L('ابحث عن أشخاص باسمهم المسجّل.', 'Search people by their registered name.')}</p> : null}
          {people.map((profile) => (
            <div key={profile.id} className="buk-row">
              <div className="buk-avatar round">👤</div>
              <div className="buk-grow"><b>{profile.display_name}</b><div className="buk-small">{profile.bio || 'حساب BUK'}</div></div>
              <button type="button" className="buk-btn" onClick={() => navigate('/friends')}>{L('فتح في الأصدقاء', 'Open in Friends')}</button>
            </div>
          ))}
        </div>
      ) : null}

      {tab === 'chats' ? (
        <div className="buk-card">
          {!chats.length ? <p className="buk-muted">{L('ابحث داخل محادثاتك بكلمة من آخر رسالة.', 'Search your chats by a word in the last message.')}</p> : null}
          {chats.map((conversation) => (
            <button key={conversation.id} type="button" className="buk-row" style={{ background: 'none', border: 0, width: '100%', textAlign: 'start', color: 'inherit', cursor: 'pointer' }} onClick={() => navigate(`/chat/${conversation.id}`)}>
              <div className="buk-avatar">{conversationIcon(conversation)}</div>
              <div className="buk-grow"><b>{conversationTitle(conversation, user && user.id)}</b><div className="buk-small">{conversation.last_message_text}</div></div>
            </button>
          ))}
        </div>
      ) : null}

      {tab === 'channels' ? (
        <div className="buk-card">
          {!channels.length ? <p className="buk-muted">{L('ابحث عن قناة بالاسم.', 'Search a channel by name.')}</p> : null}
          {channels.map((channel) => (
            <button key={channel.id} type="button" className="buk-row" style={{ background: 'none', border: 0, width: '100%', textAlign: 'start', color: 'inherit', cursor: 'pointer' }} onClick={() => navigate(`/chat/${channel.id}`)}>
              <div className="buk-avatar">📢</div>
              <div className="buk-grow"><b>{channel.title}</b><div className="buk-small">{channel.description || 'قناة BUK'}</div></div>
            </button>
          ))}
        </div>
      ) : null}
    </section>
  );
}