import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import Composer from '@/components/chat/Composer';
import MessageBubble from '@/components/chat/MessageBubble';
import { conversationTitle, markDeliveredAndRead, previewOf } from '@/lib/chat';

export default function ChatRoom() {
  const { id } = useParams();
  const { user } = usePrefs();
  const navigate = useNavigate();
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [replyTo, setReplyTo] = useState(null);
  const [notice, setNotice] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [term, setTerm] = useState('');
  const endRef = useRef(null);

  const load = async () => {
    const page = await base44.entities.Message.filter({ conversation_id: id }, { sort: 'created_date', limit: 100 });
    setMessages(page.items || []);
  };

  useEffect(() => {
    if (!user) return;
    let alive = true;
    (async () => {
      const record = await base44.entities.Conversation.get(id).catch(() => null);
      if (!alive) return;
      if (!record) { setNotice('المحادثة غير موجودة'); return; }
      setConversation(record);
      await load();
      await markDeliveredAndRead(id, user.id).catch(() => {});
      await load();
    })();
    const unsubscribe = base44.entities.Message.subscribe((event) => {
      const data = event && event.data;
      if (!data || data.conversation_id !== id) return;
      load();
      if (data.sender_id !== user.id) {
        markDeliveredAndRead(id, user.id).catch(() => {});
      }
    });
    return () => { alive = false; unsubscribe(); };
  }, [id, user]);

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ block: 'end' });
  }, [messages.length]);

  const runSearch = async () => {
    if (term.trim().length < 2) { await load(); return; }
    const page = await base44.entities.Message.filter(
      { conversation_id: id, text: { $regex: term.trim() } },
      { limit: 50, sort: '-created_date' }
    );
    setMessages(page.items || []);
  };

  const onSent = async () => { await load(); };
  const onCopy = (message) => { if (message.text) navigator.clipboard.writeText(message.text); };
  const onDeleteForMe = async (message) => {
    await base44.entities.Message.update(message.id, {
      hidden_for_ids: Array.from(new Set([...(message.hidden_for_ids || []), user.id]))
    });
    await load();
  };
  const onDeleteForAll = async (message) => {
    await base44.entities.Message.update(message.id, { deleted_for_all: true, text: '', media_url: '' });
    await base44.entities.Conversation.update(id, { last_message_text: 'تم حذف الرسالة' }).catch(() => {});
    await load();
  };

  const visible = messages.filter((m) => !(m.hidden_for_ids || []).includes(user && user.id));

  return (
    <section>
      <div className="buk-row">
        <button type="button" className="buk-btn secondary" onClick={() => navigate('/chats')}>‹</button>
        <div className="buk-avatar">👤</div>
        <div className="buk-grow">
          <b>{conversationTitle(conversation, user && user.id)}</b>
          <div className="buk-small">{conversation && conversation.type === 'direct' ? 'محادثة فردية' : 'محادثة جماعية'}</div>
        </div>
        <button type="button" className="buk-btn secondary" onClick={() => setSearchOpen((v) => !v)} aria-label="بحث داخل المحادثة">⌕</button>
        <button type="button" className="buk-btn secondary" onClick={() => navigate('/calls')} aria-label="مكالمة">☎</button>
      </div>

      {searchOpen ? (
        <div className="buk-search">
          <input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="ابحث داخل المحادثة" />
          <button type="button" className="buk-btn" onClick={runSearch}>بحث</button>
        </div>
      ) : null}

      {notice ? <div className="buk-note">{notice}</div> : null}

      <div className="buk-card" style={{ minHeight: 200 }}>
        {!visible.length ? <p className="buk-muted">ابدأ المحادثة بإرسال أول رسالة.</p> : null}
        {visible.map((message) => (
          <MessageBubble
            key={message.id}
            message={message}
            myId={user && user.id}
            onReply={setReplyTo}
            onCopy={onCopy}
            onDeleteForMe={onDeleteForMe}
            onDeleteForAll={onDeleteForAll}
          />
        ))}
        <div ref={endRef} />
      </div>

      {conversation && user ? (
        <Composer
          conversation={conversation}
          me={user}
          replyTo={replyTo}
          onClearReply={() => setReplyTo(null)}
          onSent={onSent}
        />
      ) : null}
      {replyTo ? <p className="buk-small">↩︎ {previewOf(replyTo)}</p> : null}
    </section>
  );
}