import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';

const CONFIG = {
  groups: { type: 'group', ar: 'المجموعات', en: 'Groups', icon: '👨‍👩‍👧', note: 'مساحة تجمع الأصدقاء والفرق.' },
  channels: { type: 'channel', ar: 'القنوات', en: 'Channels', icon: '📢', note: 'انشر الرسائل والوسائط وتابع ما يهمك.' },
  communities: { type: 'community', ar: 'المجتمعات', en: 'Communities', icon: '🏙️', note: 'مجتمعات عامة يمكن للأعضاء الانضمام إليها.' }
};

export default function Spaces({ kind }) {
  const config = CONFIG[kind] || CONFIG.groups;
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [mine, setMine] = useState([]);
  const [publicSpaces, setPublicSpaces] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(kind === 'communities');
  const [status, setStatus] = useState('');

  const load = async () => {
    if (!user) return;
    const minePage = await base44.entities.Conversation.filter({ type: config.type, member_ids: user.id }, { limit: 50 });
    setMine(minePage.items || []);
    const publicPage = await base44.entities.Conversation.filter({ type: config.type, is_public: true }, { limit: 50 });
    setPublicSpaces((publicPage.items || []).filter((s) => !((s.member_ids || []).includes(user.id))));
  };

  useEffect(() => {
    load();
  }, [user, kind]);

  const create = async (event) => {
    event.preventDefault();
    const name = title.trim();
    if (!name) return;
    const created = await base44.entities.Conversation.create({
      type: config.type,
      title: name,
      description,
      owner_id: user.id,
      owner_name: user.full_name || user.email,
      member_ids: [user.id],
      admin_ids: [user.id],
      is_public: isPublic,
      invite_code: `${config.type}-${Math.random().toString(36).slice(2, 8)}`,
      last_message_at: new Date().toISOString()
    });
    setTitle('');
    setDescription('');
    setStatus(`تم إنشاء ${name}`);
    await load();
    navigate(`/chat/${created.id}`);
  };

  const join = async (space) => {
    await base44.entities.Conversation.update(space.id, {
      member_ids: Array.from(new Set([...(space.member_ids || []), user.id]))
    });
    await load();
  };

  const toggleMute = async (space) => {
    const muted = space.muted_ids || [];
    const next = muted.includes(user.id) ? muted.filter((id) => id !== user.id) : [...muted, user.id];
    await base44.entities.Conversation.update(space.id, { muted_ids: next });
    await load();
  };

  return (
    <section>
      <h2 className="buk-title">{L(config.ar, config.en)}</h2>
      <p className="buk-muted">{L(config.note, 'BUK spaces with saved messages.')}</p>

      <form className="buk-card" onSubmit={create}>
        <label className="buk-muted">{L(`إنشاء ${config.ar === 'القنوات' ? 'قناة' : 'مجموعة'} جديدة`, 'Create new')}</label>
        <input className="buk-field" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={L('الاسم', 'Name')} />
        <input className="buk-field" value={description} onChange={(e) => setDescription(e.target.value)} placeholder={L('الوصف (اختياري)', 'Description (optional)')} />
        <div className="buk-setting">
          <span>{L('عام لكل مستخدمي BUK', 'Public to all BUK users')}</span>
          <button type="button" className="buk-btn secondary" onClick={() => setIsPublic((v) => !v)}>{isPublic ? 'عام' : 'خاص'}</button>
        </div>
        <button className="buk-btn wide" type="submit">{L('إنشاء', 'Create')}</button>
        {status ? <p className="buk-small">{status}</p> : null}
      </form>

      <h3 className="buk-title" style={{ fontSize: '1.1rem' }}>{L('التي أنا عضو فيها', 'I am a member')}</h3>
      <div className="buk-card">
        {!mine.length ? <p className="buk-muted">{L('لا يوجد بعد.', 'Nothing yet.')}</p> : null}
        {mine.map((space) => (
          <div key={space.id} className="buk-row">
            <div className="buk-avatar">{config.icon}</div>
            <div className="buk-grow">
              <b>{space.title}</b>
              <div className="buk-small">{(space.member_ids || []).length} {L('عضوًا', 'members')} {space.is_public ? '· عام' : '· خاص'}</div>
            </div>
            <button type="button" className="buk-btn secondary" onClick={() => toggleMute(space)}>
              {(space.muted_ids || []).includes(user.id) ? L('تشغيل الإشعارات', 'Unmute') : L('كتم الإشعارات', 'Mute')}
            </button>
            <button type="button" className="buk-btn" onClick={() => navigate(`/chat/${space.id}`)}>{L('فتح', 'Open')}</button>
          </div>
        ))}
      </div>

      {publicSpaces.length ? (
        <>
          <h3 className="buk-title" style={{ fontSize: '1.1rem' }}>{L('مساحات عامة', 'Public spaces')}</h3>
          <div className="buk-card">
            {publicSpaces.map((space) => (
              <div key={space.id} className="buk-row">
                <div className="buk-avatar">{config.icon}</div>
                <div className="buk-grow">
                  <b>{space.title}</b>
                  <div className="buk-small">{space.description || L('مساحة عامة', 'Public space')}</div>
                </div>
                <button type="button" className="buk-btn" onClick={() => join(space)}>{L('انضمام', 'Join')}</button>
              </div>
            ))}
          </div>
        </>
      ) : null}

      <div className="buk-note">
        {L('تُحفظ رسائل المجموعات والقنوات في قاعدة بيانات BUK، ويمكن للمشرف كتم الإشعارات وإدارة الأعضاء.',
          'Group and channel messages are saved in the BUK database; admins can mute and manage members.')}
      </div>
    </section>
  );
}