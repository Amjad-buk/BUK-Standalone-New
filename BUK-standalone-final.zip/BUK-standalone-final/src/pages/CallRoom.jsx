import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';

const ICE_SERVERS = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };
const POLL_MS = 1200;
const NO_ANSWER_MS = 60000;

/** مكالمة فعلية بين جهازين: العرض والإجابة والمرشّحات تُتبادل عبر سجل المكالمة على الخادم. */
export default function CallRoom() {
  const { id } = useParams();
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [call, setCall] = useState(null);
  const [connected, setConnected] = useState(false);
  const [notice, setNotice] = useState('');
  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [seconds, setSeconds] = useState(0);

  const pcRef = useRef(null);
  const streamRef = useRef(null);
  const localRef = useRef(null);
  const remoteRef = useRef(null);
  const roleRef = useRef('');
  const myIceRef = useRef([]);
  const remoteIceRef = useRef([]);
  const answeredRef = useRef(false);
  const mutedAllRef = useRef(false);

  useEffect(() => {
    if (!user || !id) return undefined;
    let cancelled = false;
    let timer = null;
    let noAnswer = null;

    const stopMedia = () => {
      if (timer) clearInterval(timer);
      if (noAnswer) clearTimeout(noAnswer);
      if (streamRef.current) streamRef.current.getTracks().forEach((track) => track.stop());
      if (pcRef.current) { try { pcRef.current.close(); } catch (e) { /* تم الإغلاق */ } }
    };

    const start = async () => {
      const record = await base44.entities.Call.get(id).catch(() => null);
      if (cancelled) return;
      if (!record) { setNotice(L('المكالمة غير موجودة.', 'This call no longer exists.')); return; }
      setCall(record);

      const role = record.caller_id === user.id ? 'caller' : 'callee';
      roleRef.current = role;

      if (record.status === 'ended') { setNotice(L('انتهت المكالمة.', 'The call has ended.')); return; }
      if (role === 'caller' && record.status === 'declined') { setNotice(L('تم رفض المكالمة.', 'The call was declined.')); return; }

      let stream = null;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: record.mode === 'video' ? { facingMode: 'user' } : false
        });
      } catch (e) {
        setNotice(L('لم نتمكن من الوصول إلى الميكروفون أو الكاميرا. اسمح بالوصول ثم أعد الاتصال.',
          'We could not reach the microphone or camera. Allow access, then call again.'));
        await base44.entities.Call.update(id, { status: 'ended' }).catch(() => {});
        return;
      }
      if (cancelled) { stream.getTracks().forEach((track) => track.stop()); return; }

      streamRef.current = stream;
      if (localRef.current) localRef.current.srcObject = stream;

      const pc = new RTCPeerConnection(ICE_SERVERS);
      pcRef.current = pc;
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      pc.ontrack = (event) => {
        if (remoteRef.current) {
          remoteRef.current.srcObject = event.streams[0];
          remoteRef.current.play().catch(() => {});
        }
        setConnected(true);
      };

      pc.onicecandidate = (event) => {
        if (!event.candidate) return;
        myIceRef.current = [...myIceRef.current, JSON.stringify(event.candidate)];
        const field = role === 'caller' ? 'caller_ice' : 'callee_ice';
        base44.entities.Call.update(id, { [field]: myIceRef.current }).catch(() => {});
      };

      if (role === 'caller') {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await base44.entities.Call.update(id, {
          offer: JSON.stringify(pc.localDescription),
          status: 'ringing',
          caller_ice: [],
          callee_ice: []
        }).catch(() => {});
        noAnswer = setTimeout(() => {
          if (cancelled || answeredRef.current) return;
          base44.entities.Call.update(id, { status: 'ended' }).catch(() => {});
          stopMedia();
          setNotice(L('لا يوجد رد على المكالمة.', 'No answer.'));
        }, NO_ANSWER_MS);
      }

      timer = setInterval(async () => {
        const latest = await base44.entities.Call.get(id).catch(() => null);
        if (!latest || cancelled) return;
        setCall(latest);

        if (latest.status === 'ended') {
          stopMedia();
          setNotice(L('انتهت المكالمة.', 'The call has ended.'));
          return;
        }
        if (role === 'caller' && latest.status === 'declined') {
          stopMedia();
          setNotice(L('تم رفض المكالمة.', 'The call was declined.'));
          return;
        }

        if (role === 'callee' && latest.offer && !answeredRef.current) {
          answeredRef.current = true;
          await pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(latest.offer))).catch(() => {});
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          await base44.entities.Call.update(id, {
            answer: JSON.stringify(pc.localDescription),
            status: 'accepted'
          }).catch(() => {});
        }

        if (role === 'caller' && latest.answer && pc.signalingState === 'have-local-offer') {
          await pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(latest.answer))).catch(() => {});
        }

        const remoteList = (role === 'caller' ? latest.callee_ice : latest.caller_ice) || [];
        for (const raw of remoteList) {
          if (remoteIceRef.current.includes(raw)) continue;
          remoteIceRef.current = [...remoteIceRef.current, raw];
          try { await pc.addIceCandidate(new RTCIceCandidate(JSON.parse(raw))); } catch (e) { /* مرشّح غير صالح */ }
        }
      }, POLL_MS);
    };

    start();

    return () => {
      cancelled = true;
      stopMedia();
    };
  }, [id, user]);

  useEffect(() => {
    if (!connected) return undefined;
    const ticker = setInterval(() => setSeconds((value) => value + 1), 1000);
    return () => clearInterval(ticker);
  }, [connected]);

  useEffect(() => () => { mutedAllRef.current = true; }, []);

  const hangUp = async () => {
    mutedAllRef.current = true;
    await base44.entities.Call.update(id, { status: 'ended', ended_at: new Date().toISOString() }).catch(() => {});
    if (streamRef.current) streamRef.current.getTracks().forEach((track) => track.stop());
    if (pcRef.current) { try { pcRef.current.close(); } catch (e) { /* تم الإغلاق */ } }
    navigate('/calls');
  };

  const toggleMute = () => {
    const track = streamRef.current && streamRef.current.getAudioTracks()[0];
    if (!track) return;
    track.enabled = !track.enabled;
    setMuted(!track.enabled);
  };

  const toggleCamera = () => {
    const track = streamRef.current && streamRef.current.getVideoTracks()[0];
    if (!track) return;
    track.enabled = !track.enabled;
    setCamOff(!track.enabled);
  };

  const isVideo = !!(call && call.mode === 'video');
  const peerName = call ? (roleRef.current === 'caller' ? call.callee_name : call.caller_name) : '';
  const duration = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  const state = connected
    ? `${L('متصل', 'Connected')} · ${duration}`
    : (call && call.status === 'ringing' ? L('جارٍ الرنين…', 'Ringing…') : L('جارٍ الاتصال…', 'Connecting…'));

  return (
    <section>
      <h2 className="buk-title">{isVideo ? '📹' : '☎️'} {L('مكالمة', 'Call')}: {peerName || 'BUK'}</h2>
      <p className="buk-muted">{state}</p>

      <div className={`buk-video-stage buk-call-video${isVideo ? '' : ' audio-only'}`}>
        <video ref={remoteRef} autoPlay playsInline className="buk-call-remote" />
        {!isVideo ? <div className="buk-call-audio">☎️</div> : null}
      </div>

      {isVideo ? (
        <div className="buk-video-stage buk-call-video small">
          <video ref={localRef} autoPlay playsInline muted className="buk-call-local" />
        </div>
      ) : null}

      {notice ? <div className="buk-note">{notice}</div> : null}

      {connected && !isVideo ? (
        <button type="button" className="buk-btn secondary wide" onClick={() => { if (remoteRef.current) remoteRef.current.play().catch(() => {}); }}>
          🔊 {L('تشغيل الصوت', 'Play sound')}
        </button>
      ) : null}

      <div className="buk-tiles">
        <button type="button" className="buk-btn secondary" onClick={toggleMute}>
          {muted ? '🔇' : '🎙️'} {muted ? L('إلغاء الكتم', 'Unmute') : L('كتم الميكروفون', 'Mute')}
        </button>
        {isVideo ? (
          <button type="button" className="buk-btn secondary" onClick={toggleCamera}>
            {camOff ? '📷' : '🎥'} {L('الكاميرا', 'Camera')}
          </button>
        ) : null}
        <button type="button" className="buk-btn danger" onClick={hangUp}>{L('إنهاء المكالمة', 'End call')}</button>
      </div>
    </section>
  );
}