import React from 'react';
import { useNavigate } from 'react-router-dom';
import { usePrefs } from '@/lib/prefs';
import LiveInterpreter from '@/components/translate/LiveInterpreter';

export default function Translate() {
  const { L } = usePrefs();
  const navigate = useNavigate();

  return (
    <section>
      <div className="buk-row">
        <button type="button" className="buk-btn secondary" onClick={() => navigate('/')}>‹ {L('الرئيسية', 'Home')}</button>
        <div className="buk-grow">
          <h2 className="buk-title" style={{ margin: 0 }}>🌐 {L('المترجم الفوري الناطق', 'Spoken interpreter')}</h2>
          <div className="buk-small">
            {L('احكِ بلغتك فقط — يسمع الطرف الآخر الترجمة منطوقةً بلغته، والعكس.', 'Just speak — the other side hears the translation spoken in their language, both ways.')}
          </div>
        </div>
      </div>

      <LiveInterpreter />
    </section>
  );
}