import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { guestIdentity } from '@/lib/meeting';
import MeetingExperience from '@/components/meeting/MeetingExperience';

/** صفحة الضيف: تُفتح من رابط الدعوة خارج تطبيق BUK وبلا حاجة لحساب. */
export default function JoinMeeting() {
  const { code } = useParams();
  const roomCode = String(code || '').toUpperCase();
  const [name, setName] = useState(() => localStorage.getItem('buk-guest-name') || '');
  const [entered, setEntered] = useState(false);
  const [error, setError] = useState('');

  const enter = (event) => {
    event.preventDefault();
    const clean = name.trim();
    if (clean.length < 2) {
      setError('اكتب اسمك للظهور في الاجتماع.');
      return;
    }
    localStorage.setItem('buk-guest-name', clean);
    setError('');
    setEntered(true);
  };

  if (entered) {
    return (
      <MeetingExperience
        code={roomCode}
        identity={{ id: guestIdentity(), name }}
        onExit={() => setEntered(false)}
        exitLabel="رجوع"
      />
    );
  }

  return (
    <div className="mt-gate">
      <div className="mt-gate-card">
        <div className="mt-gate-logo">BUK</div>
        <h1>الانضمام إلى الاجتماع</h1>
        <p className="mt-gate-code">رمز الاجتماع: <b dir="ltr">{roomCode}</b></p>
        <form onSubmit={enter}>
          <input
            className="buk-field"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="اسمك للظهور في الاجتماع"
            autoFocus
          />
          <button type="submit" className="buk-btn wide">دخول الاجتماع</button>
        </form>
        {error ? <p className="mt-error">{error}</p> : null}
        <p className="mt-hint">لا تحتاج حسابًا في BUK — اكتب اسمك واسمح بالكاميرا والميكروفون.</p>
      </div>
    </div>
  );
}