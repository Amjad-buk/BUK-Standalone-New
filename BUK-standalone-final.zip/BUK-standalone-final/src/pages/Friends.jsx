import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { ensureProfile, findOrCreateDirect } from '@/lib/chat';
import { Image } from '@/components/ui/image';

export default function Friends() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [term, setTerm] = useState('');
  const [results, setResults] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [status, setStatus] = useState('');
  const [searched, setSearched] = useState(false);
  const [busy, setBusy] = useState(false);

  const loadContacts = async () => {
    if (!user) return;
    const rows = await base44.entities.Contact.filter({ owner_id: user.id });
    setContacts(rows || []);
  };

  useEffect(() => {
    if (!user) return;
    ensureProfile(user).catch(() => {});
    loadContacts();
  }, [user]);

  const search = async () => {
    const value = term.trim();
    if (value.length < 2) { setStatus('اكتب حرفين على الأقل من اسم الحساب للبحث.'); return; }
    setBusy(true);
    setStatus('');
    try {
      const rows = await base44.entities.BukProfile.filter(
        { is_searchable: true, display_name: { $regex: value } },
        { limit: 20 }
      );
      setResults((rows || []).filter((r) => r.user_id !== (user && user.id)));
      setSearched(true);
      if (!rows || !rows.length) setStatus('لا نتائج مطابقة.');
    } catch (e) {
      setStatus(e.message || 'تعذر البحث الآن.');
    } finally {
      setBusy(false);
    }
  };

  const addContact = async (profile) => {
    if (!user) return;
    const existing = contacts.find((c) => c.contact_id === profile.user_id);
    if (existing) return;
    await base44.entities.Contact.create({
      owner_id: user.id,
      contact_id: profile.user_id,
      contact_name: profile.display_name || '',
      contact_email: profile.email || '',
      status: 'accepted'
    });
    await base44.entities.Notification.create({
      user_id: profile.user_id, kind: 'friend', title: 'طلب صداقة جديد',
      body: `${user.full_name || user.email} أضافك إلى جهات اتصاله`, link: '/friends'
    }).catch(() => {});
    await loadContacts();
  };

  const openChat = async (profile) => {
    if (!user) return;
    setBusy(true);
    try {
      const conversation = await findOrCreateDirect(user, profile);
      navigate(`/chat/${conversation.id}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section>
      <h2 className="buk-title">{L('الأصدقاء', 'Friends')}</h2>
      <p className="buk-muted">{L('ابحث عن الأشخاص الذين لديهم حساب BUK فعلي.', 'Search for people who have a real BUK account.')}</p>

      <button type="button" className="buk-btn wide" onClick={() => navigate('/contacts')}>
        {L('مزامنة جهات الاتصال ودعوة الأصدقاء', 'Sync contacts and invite friends')}
      </button>

      <div className="buk-search">
        <input value={term} onChange={(e) => setTerm(e.target.value)} placeholder={L('اكتب اسم الصديق المسجّل', "Type the friend's registered name")} />
        <button type="button" className="buk-btn" onClick={search} disabled={busy}>{L('بحث', 'Search')}</button>
      </div>
      {status ? <div className="buk-note">{status}</div> : null}

      <div className="buk-card">
        {searched && !results.length && !status ? <p className="buk-muted">لا نتائج.</p> : null}
        {results.map((profile) => (
          <div key={profile.id} className="buk-row">
            <div className="buk-avatar round">
              {profile.avatar_url ? <Image src={profile.avatar_url} alt="" fittingType="fill" className="w-full h-full" /> : '👤'}
            </div>
            <div className="buk-grow">
              <b>{profile.display_name}</b>
              <div className="buk-small">{profile.bio || 'حساب BUK'}</div>
            </div>
            <button type="button" className="buk-btn secondary" onClick={() => addContact(profile)}>{L('إضافة', 'Add')}</button>
            <button type="button" className="buk-btn" onClick={() => openChat(profile)}>{L('محادثة', 'Chat')}</button>
          </div>
        ))}
        {!results.length ? <p className="buk-muted">{L('اكتب حرفين على الأقل للعثور على صديق.', 'Type at least two characters to find a friend.')}</p> : null}
      </div>

      <h3 className="buk-title" style={{ fontSize: '1.1rem' }}>{L('جهات اتصالي', 'My contacts')}</h3>
      <div className="buk-card">
        {!contacts.length ? <p className="buk-muted">{L('لا جهات اتصال بعد.', 'No contacts yet.')}</p> : null}
        {contacts.map((contact) => (
          <div key={contact.id} className="buk-row">
            <div className="buk-avatar round">👤</div>
            <div className="buk-grow">
              <b>{contact.contact_name || contact.contact_email || contact.contact_id.slice(0, 8)}</b>
              <div className="buk-small">{contact.status === 'accepted' ? 'صديق في BUK' : contact.status}</div>
            </div>
            <button
              type="button"
              className="buk-btn"
              onClick={async () => {
                const conversation = await findOrCreateDirect(user, { user_id: contact.contact_id, display_name: contact.contact_name });
                navigate(`/chat/${conversation.id}`);
              }}
            >
              {L('محادثة', 'Chat')}
            </button>
          </div>
        ))}
      </div>

      <div className="buk-note">
        {L('دعوات الأصدقاء تُرسل من صفحة مزامنة جهات الاتصال، وتظهر للمستلم باسم BUK وليس برقمك، وبعد موافقتك فقط.',
          'Friend invites are sent from the contact-sync page, appear to the recipient as BUK rather than your number, and only after your approval.')}
      </div>
    </section>
  );
}