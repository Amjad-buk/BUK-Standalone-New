import React, { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { serializeData, speechText } from '@/lib/buki';
import { speakAloud } from '@/lib/speech';
import ChatMessage from '@/components/buki/ChatMessage';
import BukiComposer from '@/components/buki/BukiComposer';
import Suggestions from '@/components/buki/Suggestions';
import BukiTools from '@/components/buki/BukiTools';
import LiveTranslateBox from '@/components/buki/LiveTranslateBox';

/** ماي بوكي: محادثة بسيطة بأسلوب ChatGPT — اكتب أو تكلم، وهو يجيب. */
export default function MyBuki() {
  const { user, settings, L } = usePrefs();
  const [items, setItems] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [busy, setBusy] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [status, setStatus] = useState('');
  const [tools, setTools] = useState(false);
  const [liveTranslate, setLiveTranslate] = useState(true);
  const [translateFrom, setTranslateFrom] = useState('ar');
  const [translateTo, setTranslateTo] = useState('en');
  const endRef = useRef(null);
  const busyRef = useRef(false);

  const load = async () => {
    if (!user) return;
    const chat = await base44.entities.AiMessage.filter({ owner_id: user.id, agent: 'mypuki' }, { sort: 'created_date', limit: 40 });
    setItems(chat.items || []);
    const list = await base44.entities.Reminder.filter({ owner_id: user.id, status: 'scheduled' }, { sort: 'at', limit: 50 });
    setReminders(list.items || []);
  };

  useEffect(() => { load(); }, [user]);
  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ block: 'end' });
  }, [items.length, thinking]);

  const speak = async (value) => {
    if (!value) return false;
    return speakAloud(value, 'ar', settings.assistant_voice, settings.voice_gender);
  };

  const ask = async (value, appendUser = true, historyOverride) => {
    const question = String(value || '').trim();
    if (!question || !user || busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setThinking(true);
    setStatus('');

    const history = historyOverride || items.map((m) => ({ role: m.role, content: m.content }));
    const userTempId = appendUser ? `tmp-u-${Date.now()}` : null;
    if (appendUser) setItems((prev) => [...prev, { id: userTempId, role: 'user', content: question, data: '' }]);

    try {
      const payload = {
        action: 'assistant',
        agent: 'mypuki',
        text: question,
        history,
        local_now: new Date().toLocaleString('sv-SE').slice(0, 16),
        tz_name: Intl.DateTimeFormat().resolvedOptions().timeZone,
        offset_minutes: new Date().getTimezoneOffset()
      };
      const response = await base44.functions.invoke('bukAssistant', payload);
      const data = (response && response.data) || {};
      const reply = String(data.reply || '').trim();
      if (!reply) {
        setStatus(L('لم يصل رد من المساعد.', 'No reply from the assistant.'));
        return;
      }

      const blocks = Array.isArray(data.blocks) ? data.blocks : [];
      const packed = serializeData(blocks);
      const assistantTempId = `tmp-a-${Date.now()}`;
      setItems((prev) => [...prev, { id: assistantTempId, role: 'assistant', content: reply, data: packed }]);

      if (settings.save_ai_history) {
        base44.entities.AiMessage.bulkCreate([
          { owner_id: user.id, agent: 'mypuki', role: 'user', content: question },
          { owner_id: user.id, agent: 'mypuki', role: 'assistant', content: reply, data: packed }
        ]).then((created) => {
          if (!Array.isArray(created) || created.length < 2) return;
          setItems((prev) => {
            const drop = new Set([userTempId, assistantTempId].filter(Boolean));
            return [...prev.filter((m) => !drop.has(m.id)), ...created];
          });
        }).catch(() => {});
      }

      // الرد ظهر على الشاشة: نحرّر صندوق الكتابة فورًا حتى يُنفَّذ الأمر التالي بلا انتظار.
      setThinking(false);
      setBusy(false);
      busyRef.current = false;

      if (blocks.some((block) => block.type === 'reminder')) load();

      if (settings.notif_sound) {
        const translation = blocks.find((block) => block.type === 'translation');
        const spoken = translation
          ? await speakAloud(translation.text, translation.target, settings.assistant_voice, settings.voice_gender)
          : await speak(speechText({ content: reply, data: packed }));
        if (!spoken) setStatus(L('تم الرد كتابةً، لكن تعذر توليد الصوت الآن.', 'Replied in text; audio is unavailable now.'));
      }
    } catch {
      setStatus(L('تعذر الاتصال بالمساعد. أعد المحاولة.', 'Could not reach the assistant. Try again.'));
    } finally {
      busyRef.current = false;
      setThinking(false);
      setBusy(false);
    }
  };

  const regenerate = async () => {
    if (busy) return;
    const lastAssistant = [...items].reverse().find((m) => m.role === 'assistant');
    const lastUser = [...items].reverse().find((m) => m.role === 'user');
    if (!lastAssistant || !lastUser) return;
    const remaining = items.filter((m) => m.id !== lastAssistant.id);
    if (!String(lastAssistant.id).startsWith('tmp-')) {
      await base44.entities.AiMessage.delete(lastAssistant.id).catch(() => {});
    }
    setItems(remaining);
    // نستبعد رسالة المستخدم الأخيرة من السياق لأنها تُرسل كنص الأمر، وإلا تكرّرت وارتبكت الأوامر.
    const history = remaining
      .filter((m) => m.id !== lastUser.id)
      .map((m) => ({ role: m.role, content: m.content }));
    await ask(lastUser.content, false, history);
    setTools(false);
  };

  const newChat = async () => {
    if (busy || !items.length) return;
    if (!window.confirm(L('سيتم مسح هذه المحادثة. متابعة؟', 'This conversation will be cleared. Continue?'))) return;
    setItems([]);
    setStatus('');
    setTools(false);
    if (settings.save_ai_history) {
      await base44.entities.AiMessage.deleteMany({ owner_id: user.id, agent: 'mypuki' }).catch(() => {});
    }
  };

  return (
    <div className="mk">
      <header className="mk-top">
        <div className="mk-mark">✨</div>
        <b>My Book</b>
        <button type="button" className="mk-icon" onClick={() => setTools(true)} title={L('الأدوات', 'Tools')}>⚙</button>
      </header>

      <div className={items.length ? 'mk-thread' : 'mk-thread center'}>
        {!items.length ? (
          <div className="mk-empty">
            <div className="mk-orb">✨</div>
            <p>{L('اسأل My Book أي شيء بالكتابة أو بالصوت، وسيجيبك مباشرة.', 'Ask My Book anything by typing or speaking, and it answers right away.')}</p>
            <Suggestions onPick={(prompt) => ask(prompt)} />
          </div>
        ) : null}

        {items.map((message) => (
          <ChatMessage
            key={message.id}
            message={message}
            mine={message.role === 'user'}
            onSpeak={() => speak(speechText(message))}
          />
        ))}

        {thinking ? <div className="ty"><i /><i /><i /> {L('يكتب…', 'Typing…')}</div> : null}
        <div ref={endRef} />
      </div>

      <LiveTranslateBox
        enabled={liveTranslate}
        onToggle={setLiveTranslate}
        source={translateFrom}
        onSource={setTranslateFrom}
        target={translateTo}
        onTarget={setTranslateTo}
        onStatus={setStatus}
      />

      <BukiComposer busy={busy} onSend={(value) => ask(value)} onStatus={setStatus} />

      {status ? <div className="mk-status">{status}</div> : null}

      <BukiTools
        open={tools}
        onClose={() => setTools(false)}
        reminders={reminders}
        onChanged={load}
        onRegenerate={regenerate}
        onNewChat={newChat}
      />
    </div>
  );
}