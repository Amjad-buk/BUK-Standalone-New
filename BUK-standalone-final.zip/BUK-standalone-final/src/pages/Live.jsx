import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { roomApi } from '@/lib/meeting';
import { usePrefs } from '@/lib/prefs';
import { followerCounts, followingChannels, notifyFollowers } from '@/lib/live';
import { Image } from '@/components/ui/image';
import ChannelForm from '@/components/live/ChannelForm';

const TABS = [
  { id: 'live', ar: 'مباشر الآن', en: 'Live now' },
  { id: 'mine', ar: 'قناتي', en: 'My channel' },
  { id: 'follows', ar: 'متابعاتي', en: 'Following' }
];

/** BUK مباشر: قنوات ومتابعون وبثوث مباشرة وأرشيف بثوث سابقة. */
export default function Live() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [tab, setTab] = useState('live');
  const [rooms, setRooms] = useState([]);
  const [channels, setChannels] = useState([]);
  const [archives, setArchives] = useState([]);
  const [follows, setFollows] = useState([]);
  const [counts, setCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [streamTitle, setStreamTitle] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const [roomData, channelPage, archivePage, followRows, countMap] = await Promise.all([
      roomApi('live').catch(() => ({ rooms: [] })),
      base44.entities.LiveChannel.list({ sort: '-created_date', limit: 50 }).catch(() => ({ items: [] })),
      base44.entities.LiveArchive.list({ sort: '-ended_at', limit: 20 }).catch(() => ({ items: [] })),
      user ? followingChannels(user.id) : [],
      followerCounts().catch(() => ({}))
    ]);
    setRooms(roomData.rooms || []);
    setChannels(channelPage.items || []);
    setArchives(archivePage.items || []);
    setFollows(followRows || []);
    setCounts(countMap || {});
    setLoading(false);
  };

  useEffect(() => {
    load();
    const timer = setInterval(load, 10000);
    return () => clearInterval(timer);
  }, [user]);

  const myCh = user ? channels.find((channel) => channel.owner_id === user.id) : null;
  const followedIds = follows.map((row) => row.channel_id);
  const followedChannels = channels.filter((channel) => followedIds.includes(channel.id));
  const channelName = (id) => (channels.find((channel) => channel.id === id) || {}).name || '';

  const goLive = async () => {
    if (!user || busy) return;
    if (!myCh) {
      setTab('mine');
      setStatus(L('أنشئ قناتك أولًا ثم ابدأ البث.', 'Create your channel first, then start streaming.'));
      return;
    }
    setBusy(true);
    const title = streamTitle.trim() || L('بث مباشر', 'Live stream');
    setStatus(L('جارٍ إنشاء غرفة البث على الخادم…', 'Creating the live room on the server…'));
    const data = await roomApi('create', { title, kind: 'live', channel_id: myCh.id }).catch(() => ({}));
    if (!data.meeting || !data.meeting.code) {
      setBusy(false);
      setStatus(L('تعذر بدء البث — تحقق من الاتصال وحاول مجددًا.', 'Could not start the stream — check the connection and retry.'));
      return;
    }
    await notifyFollowers(myCh, { code: data.meeting.code, title }, user.id).catch(() => 0);
    setBusy(false);
    setStatus('');
    navigate(`/live/${data.meeting.code}`);
  };

  const roomRow = (room) => (
    <Link key={room.id} to={`/live/${room.code}`} className="buk-row" style={{ textDecoration: 'none', color: 'inherit' }}>
      <div className="buk-avatar">🔴</div>
      <div className="buk-grow">
        <b>{room.title}</b>
        <div className="buk-small">
          {room.host_name}
          {room.channel_id ? ` · ${channelName(room.channel_id)}` : ''} · {L('يشاهد الآن', 'watching')}: {room.viewers}
        </div>
      </div>
      <span className="buk-badge">{L('مباشر', 'LIVE')}</span>
    </Link>
  );

  return (
    <section>
      <h2 className="buk-title">🔴 {L('BUK مباشر', 'BUK Live')}</h2>
      <p className="buk-muted">
        {L('قنوات ومتابعون وبثوث محفوظة — أنشئ قناتك، ابدأ البث، ووصل إشعار لكل متابعيك.',
          'Channels, followers and saved streams — create your channel, go live, and notify every follower.')}
      </p>

      <div className="buk-tabs-inline">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`buk-btn ${tab === item.id ? '' : 'secondary'}`}
            onClick={() => setTab(item.id)}
          >
            {L(item.ar, item.en)}
          </button>
        ))}
      </div>

      {tab === 'live' ? (
        <>
          <div className="buk-card">
            <b>{L('ابدأ بثًا الآن', 'Go live now')}</b>
            <input
              className="buk-field"
              style={{ marginTop: 10 }}
              maxLength={100}
              value={streamTitle}
              onChange={(e) => setStreamTitle(e.target.value)}
              placeholder={L('عنوان البث — مثلاً: جلسة أسئلة وأجوبة', 'Stream title — e.g. Q&A session')}
            />
            <button type="button" className="buk-btn wide" style={{ marginTop: 10 }} onClick={goLive} disabled={busy}>
              🔴 {busy ? L('جارٍ البدء…', 'Starting…') : L('بدء البث', 'Start streaming')}
            </button>
            {status ? <p className="buk-small">{status}</p> : null}
          </div>

          <div className="buk-card">
            <b>{L('يُبثّ الآن', 'Live now')}</b>
            {loading ? <p className="buk-muted">{L('جارٍ التحميل…', 'Loading…')}</p> : null}
            {!loading && !rooms.length ? (
              <p className="buk-muted">{L('لا يوجد بث جارٍ حاليًا.', 'No stream is running right now.')}</p>
            ) : null}
            {rooms.map(roomRow)}
          </div>

          <div className="buk-card">
            <b>{L('آخر البثوث المحفوظة', 'Latest saved streams')}</b>
            {!archives.length ? <p className="buk-muted">{L('لا يوجد أرشيف بعد.', 'No archive yet.')}</p> : null}
            {archives.map((item) => (
              <div key={item.id} className="buk-row">
                <div className="buk-avatar">🎬</div>
                <div className="buk-grow">
                  <b>{item.title}</b>
                  <div className="buk-small">
                    {channelName(item.channel_id) || item.host_name} · {L('المشاهدون', 'viewers')}: {item.viewers || 0}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : null}

      {tab === 'mine' ? (
        <div className="buk-card">
          {myCh ? (
            <>
              <div className="buk-row">
                <div className="buk-avatar round">
                  {myCh.avatar_url ? <Image src={myCh.avatar_url} alt="" fittingType="fill" className="w-full h-full" /> : '📺'}
                </div>
                <div className="buk-grow">
                  <b>{myCh.name}</b>
                  <div className="buk-small">{myCh.handle} · {counts[myCh.id] || 0} {L('متابع', 'followers')}</div>
                </div>
                <Link className="buk-btn" to={`/live/channel/${myCh.id}`}>{L('فتح', 'Open')}</Link>
              </div>
              <ChannelForm channel={myCh} onSaved={load} />
            </>
          ) : (
            <>
              <b>{L('أنشئ قناتك', 'Create your channel')}</b>
              <p className="buk-small">{L('القناة اسمك على BUK مباشر: يجمع متابعيك وبثوثك السابقة.', 'Your channel is your identity on BUK Live: it gathers your followers and saved streams.')}</p>
              <ChannelForm onSaved={load} />
            </>
          )}
        </div>
      ) : null}

      {tab === 'follows' ? (
        <div className="buk-card">
          {!followedChannels.length ? (
            <p className="buk-muted">{L('لم تتابع أي قناة بعد. افتح قناة واضغط متابعة.', 'You do not follow any channel yet. Open a channel and tap Follow.')}</p>
          ) : null}
          {followedChannels.map((channel) => (
            <Link key={channel.id} to={`/live/channel/${channel.id}`} className="buk-row" style={{ textDecoration: 'none', color: 'inherit' }}>
              <div className="buk-avatar round">
                {channel.avatar_url ? <Image src={channel.avatar_url} alt="" fittingType="fill" className="w-full h-full" /> : '📺'}
              </div>
              <div className="buk-grow">
                <b>{channel.name}</b>
                <div className="buk-small">{counts[channel.id] || 0} {L('متابع', 'followers')}</div>
              </div>
            </Link>
          ))}
        </div>
      ) : null}

      <div className="buk-note">
        {L('القنوات والمتابعات وأرشيف البثوث محفوظة على الخادم، وإشعار البدء يصل لكل متابعيك في جرس الإشعارات.',
          'Channels, follows and the stream archive live on the server, and the go-live notice reaches every follower in the notifications bell.')}
      </div>
    </section>
  );
}