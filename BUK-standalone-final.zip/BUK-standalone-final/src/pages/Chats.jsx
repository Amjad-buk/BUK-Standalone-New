import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import ChatListItem from '@/components/chat/ChatListItem';

export default function Chats() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [term, setTerm] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  const loadUnread = async (list) => {
    const ids = list.map((conversation) => conversation.id);
    if (!user || !ids.length) { setUnread({}); return; }
    const { rows } = await base44.entities.Message.aggregate({
      query: {
        conversation_id: { $in: ids },
        read_by: { $ne: user.id },
        sender_id: { $ne: user.id }
      },
      groupBy: 'conversation_id'
    });
    setUnread(Object.fromEntries((rows || []).map((row) => [row.conversation_id, row.count])));
  };

  const load = async (search) => {
    if (!user) return;
    const value = (search || '').trim();
    const query = value.length >= 2
      ? { member_ids: user.id, title: { $regex: value } }
      : { member_ids: user.id };
    try {
      const page = await base44.entities.Conversation.filter(query, { sort: '-last_message_at', limit: 50 });
      const list = page.items || [];
      setItems(list);
      setError('');
      await loadUnread(list);
    } catch (e) {
      setError(e.message || 'تعذر تحميل المحادثات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) return undefined;
    let alive = true;
    const run = () => { if (alive) load(term); };
    const delay = setTimeout(run, term ? 350 : 0);
    const unsubscribe = base44.entities.Conversation.subscribe(run);
    return () => { alive = false; clearTimeout(delay); unsubscribe(); };
  }, [user, term]);

  return (
    <section className="wa-wrap">
      <header className="wa-header">
        <div className="wa-titlebar">
          <div className="wa-title">{L('المحادثات', 'Chats')}</div>
          <button type="button" className="wa-icon" onClick={() => setMenuOpen((open) => !open)}
            aria-label={L('القائمة', 'Menu')}>⋮</button>
        </div>

        <div className="wa-search">
          <span className="wa-search-icon">⌕</span>
          <input value={term} onChange={(e) => setTerm(e.target.value)}
            placeholder={L('ابحث في المحادثات', 'Search chats')} />
          {term ? (
            <button type="button" className="wa-clear" onClick={() => setTerm('')}
              aria-label={L('مسح البحث', 'Clear search')}>✕</button>
          ) : null}
        </div>

        {menuOpen ? (
          <div className="wa-menu">
            <button type="button" onClick={() => { setMenuOpen(false); navigate('/friends'); }}>
              ✎ {L('محادثة جديدة', 'New chat')}
            </button>
            <button type="button" onClick={() => { setMenuOpen(false); navigate('/groups'); }}>
              👥 {L('مجموعة جديدة', 'New group')}
            </button>
            <button type="button" onClick={() => { setMenuOpen(false); navigate('/settings'); }}>
              ⚙ {L('الإعدادات', 'Settings')}
            </button>
            <button type="button" onClick={() => { setMenuOpen(false); if (user) navigator.clipboard.writeText(user.id); }}>
              ⧉ {L('نسخ معرّف حسابي', 'Copy my account ID')}
            </button>
          </div>
        ) : null}
      </header>

      {loading ? <div className="wa-loading">{L('جارٍ التحميل…', 'Loading…')}</div> : null}
      {error ? <div className="wa-loading">{error}</div> : null}

      {!loading && !items.length ? (
        <div className="wa-empty">
          {term
            ? L('لا محادثات مطابقة للبحث.', 'No chats match your search.')
            : L('لا توجد محادثات بعد. ابدأ محادثة جديدة من الزر أدناه.', 'No chats yet. Start a new chat with the button below.')}
        </div>
      ) : null}

      <div className="wa-list">
        {items.map((conversation) => (
          <ChatListItem
            key={conversation.id}
            conversation={conversation}
            myId={user && user.id}
            unread={unread[conversation.id] || 0}
            onOpen={() => navigate(`/chat/${conversation.id}`)}
          />
        ))}
      </div>

      <button type="button" className="wa-fab" onClick={() => navigate('/friends')}
        aria-label={L('محادثة جديدة', 'New chat')}>💬</button>
    </section>
  );
}