import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { joinLink, roomApi } from '@/lib/meeting';
import InviteSheet from '@/components/meeting/InviteSheet';

/** BUK Meeting Room: إنشاء اجتماع، إرسال دعوة، ودخول الغرفة. */
export default function Meeting() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [hosted, setHosted] = useState([]);
  const [created, setCreated] = useState(null);
  const [inviteFor, setInviteFor] = useState(null);
  const [code, setCode] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  const loadHosted = async () => {
    if (!user) return;
    const page = await base44.entities.Meeting.filter({ host_id: user.id }, { sort: '-created_date', limit: 20 });
    setHosted(page.items || []);
  };

  useEffect(() => {
    loadHosted();
  }, [user]);

  const create = async () => {
    if (!user || busy) return;
    setBusy(true);
    setStatus('');
    const data = await roomApi('create', { title }).catch(() => ({}));
    setBusy(false);
    if (!data.meeting) {
      setStatus('تعذر إنشاء الاجتماع. جرّب مرة أخرى.');
      return;
    }
    setCreated(data.meeting);
    setInviteFor(data.meeting);
    setTitle('');
    loadHosted();
  };

  const extractCode = (value) => {
    const raw = String(value || '').trim();
    const tail = raw.split('/').filter(Boolean).pop() || raw;
    return tail.toUpperCase();
  };

  const enterRoom = () => {
    const value = extractCode(code);
    if (!value) {
      setStatus('أدخل رمز الاجتماع أو رابط الدعوة.');
      return;
    }
    navigate(`/meeting/room/${value}`);
  };

  const endMeeting = async (meeting) => {
    await roomApi('host', { code: meeting.code, mode: 'end' }).catch(() => {});
    loadHosted();
  };

  const copyLink = async (meeting) => {
    try {
      await navigator.clipboard.writeText(joinLink(meeting.code));
      setStatus('تم نسخ رابط الدعوة.');
    } catch {
      setStatus('تعذر النسخ، انسخ الرابط يدويًا.');
    }
  };

  return (
    <section>
      <h2 className="buk-title">🎥 {L('BUK Meeting Room', 'BUK Meeting Room')}</h2>
      <p className="buk-muted">
        {L('أنشئ اجتماعًا، أرسل الدعوة بواتساب أو إيميل أو SMS، ويدخل الضيف من الرابط بلا حساب.',
          'Create a meeting, invite by WhatsApp, email or SMS — guests join from the link without an account.')}
      </p>
      <p className="buk-small">
        {L('يتسع الاجتماع لـ ١٢ مشاركًا في وقت واحد — خمسة أشخاص وأكثر يدخلون بالرابط نفسه.',
          'A meeting holds 12 people at once — five or more join with the same link.')}
      </p>

      <div className="buk-card">
        <h3 className="buk-title" style={{ fontSize: '1.05rem', marginTop: 0 }}>{L('إنشاء اجتماع جديد', 'Create a new meeting')}</h3>
        <input
          className="buk-field"
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder={L('اسم الاجتماع (اختياري)', 'Meeting name (optional)')}
        />
        <button type="button" className="buk-btn wide" onClick={create} disabled={busy}>
          ＋ {busy ? L('جارٍ الإنشاء…', 'Creating…') : L('إنشاء اجتماع', 'Create meeting')}
        </button>

        {created ? (
          <div className="buk-note">
            <div>{L('رمز الاجتماع', 'Meeting code')}: <b dir="ltr">{created.code}</b></div>
            <input className="buk-field" readOnly value={joinLink(created.code)} dir="ltr" />
            <div className="buk-tiles">
              <button type="button" className="buk-btn" onClick={() => navigate(`/meeting/room/${created.code}`)}>
                {L('بدء الاجتماع', 'Start meeting')}
              </button>
              <button type="button" className="buk-btn secondary" onClick={() => setInviteFor(created)}>
                {L('إرسال دعوة', 'Send invite')}
              </button>
            </div>
          </div>
        ) : (
          <div className="buk-note">
            {L('بعد الإنشاء تُفتح الدعوة: واتساب، إيميل، أو رسالة SMS — والرابط يعمل لأي ضيف.',
              'After creating, invite by WhatsApp, email or SMS — the link works for any guest.')}
          </div>
        )}
      </div>

      <div className="buk-card">
        <h3 className="buk-title" style={{ fontSize: '1.05rem', marginTop: 0 }}>{L('الانضمام إلى اجتماع', 'Join a meeting')}</h3>
        <input
          className="buk-field"
          value={code}
          onChange={(event) => setCode(event.target.value)}
          placeholder={L('رمز الاجتماع أو رابط الدعوة', 'Meeting code or invite link')}
        />
        <button type="button" className="buk-btn wide" onClick={enterRoom}>{L('دخول الغرفة', 'Enter room')}</button>
      </div>

      {status ? <div className="buk-note">{status}</div> : null}

      <h3 className="buk-title" style={{ fontSize: '1.1rem' }}>{L('اجتماعاتي', 'My meetings')}</h3>
      <div className="buk-card">
        {!hosted.length ? <p className="buk-muted">{L('لا اجتماعات بعد.', 'No meetings yet.')}</p> : null}
        {hosted.map((meeting) => (
          <div key={meeting.id} className="buk-row">
            <div className="buk-avatar">🎥</div>
            <div className="buk-grow">
              <b>{meeting.title}</b>
              <div className="buk-small">
                {L('الرمز', 'Code')}: <span dir="ltr">{meeting.code}</span> · {L('المشاركون', 'Participants')}: {(meeting.participants || []).length}
              </div>
            </div>
            <span className="buk-badge">
              {meeting.status === 'ended' ? L('منتهٍ', 'Ended') : meeting.status === 'live' ? L('جارٍ', 'Live') : L('مفتوح', 'Open')}
            </span>
            {meeting.status !== 'ended' ? (
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                <button type="button" className="buk-btn" onClick={() => navigate(`/meeting/room/${meeting.code}`)}>{L('دخول', 'Enter')}</button>
                <button type="button" className="buk-btn secondary" onClick={() => setInviteFor(meeting)}>{L('دعوة', 'Invite')}</button>
                <button type="button" className="buk-btn secondary" onClick={() => copyLink(meeting)}>{L('نسخ الرابط', 'Copy link')}</button>
                <button type="button" className="buk-btn danger" onClick={() => endMeeting(meeting)}>{L('إنهاء', 'End')}</button>
              </div>
            ) : null}
          </div>
        ))}
      </div>

      {inviteFor ? <InviteSheet meeting={inviteFor} onClose={() => setInviteFor(null)} /> : null}
    </section>
  );
}