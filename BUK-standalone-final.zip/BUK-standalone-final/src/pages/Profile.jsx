import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { ensureProfile } from '@/lib/chat';
import { phoneKey } from '@/lib/phone';
import { Image } from '@/components/ui/image';

export default function Profile() {
  const { user, settings, update, L } = usePrefs();
  const [profile, setProfile] = useState(null);
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [phone, setPhone] = useState('');
  const [searchable, setSearchable] = useState(true);
  const [status, setStatus] = useState('');

  useEffect(() => {
    if (!user) return;
    (async () => {
      const row = await ensureProfile(user);
      setProfile(row);
      setName(row.display_name || user.full_name || '');
      setBio(row.bio || '');
      setPhone(row.phone || '');
      setSearchable(row.is_searchable !== false);
    })();
  }, [user]);

  const saveProfile = async () => {
    if (!profile) return;
    await base44.entities.BukProfile.update(profile.id, {
      display_name: name, bio, phone, phone_key: phoneKey(phone), is_searchable: searchable, last_seen: new Date().toISOString()
    });
    await update({ display_name: name, bio });
    setStatus('تم حفظ الملف الشخصي');
  };

  const uploadAvatar = async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = '';
    if (!file) return;
    setStatus('جارٍ رفع الصورة…');
    const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
    if (profile) await base44.entities.BukProfile.update(profile.id, { avatar_url: file_url });
    await update({ avatar_url: file_url });
    setStatus('تم تحديث الصورة');
  };

  return (
    <section>
      <h2 className="buk-title">{L('الملف الشخصي', 'Profile')}</h2>

      <div className="buk-card buk-hero">
        <div className="buk-avatar round" style={{ width: 96, height: 96, flex: 'none', margin: '0 auto' }}>
          {settings.avatar_url ? <Image src={settings.avatar_url} alt="" fittingType="fill" className="w-full h-full" /> : '👤'}
        </div>
        <label className="buk-btn secondary" style={{ display: 'inline-block', marginTop: 12, cursor: 'pointer' }}>
          {L('تغيير الصورة', 'Change photo')}
          <input type="file" accept="image/*" hidden onChange={uploadAvatar} />
        </label>
        <p className="buk-small">{L('الصور تُخزَّن بشكل عام — يمكن لأي شخص يملك الرابط فتحها.', 'Images are stored publicly — anyone with the link can open them.')}</p>
      </div>

      <div className="buk-card">
        <label className="buk-muted">{L('الاسم الظاهر', 'Display name')}</label>
        <input className="buk-field" value={name} onChange={(e) => setName(e.target.value)} />
        <label className="buk-muted">{L('نبذة', 'Bio')}</label>
        <input className="buk-field" value={bio} onChange={(e) => setBio(e.target.value)} />
        <label className="buk-muted">{L('رقم الهاتف (اختياري)', 'Phone (optional)')}</label>
        <input className="buk-field" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <div className="buk-setting">
          <span>{L('الظهور في البحث', 'Show in search')}</span>
          <button type="button" className="buk-btn secondary" onClick={() => setSearchable((v) => !v)}>{searchable ? 'مُفعّل' : 'مُعطّل'}</button>
        </div>
        <button type="button" className="buk-btn wide" onClick={saveProfile}>{L('حفظ التغييرات', 'Save changes')}</button>
        {status ? <p className="buk-small">{status}</p> : null}
      </div>

      <div className="buk-note">{L('معرّف حسابك في BUK', 'Your BUK account id')}: {user && user.id}</div>
    </section>
  );
}