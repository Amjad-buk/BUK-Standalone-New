import React, { useState } from 'react';
import { usePrefs } from '@/lib/prefs';
import ChessGame from '@/components/games/ChessGame';
import TicTacToe from '@/components/games/TicTacToe';
import MemoryGame from '@/components/games/MemoryGame';
import Game2048 from '@/components/games/Game2048';
import SnakeGame from '@/components/games/SnakeGame';

const GAMES = [
  { id: 'chess', icon: '♟️', ar: 'شطرنج ضد الذكاء الاصطناعي', en: 'Chess vs AI', Game: ChessGame },
  { id: 'xox', icon: '⭕', ar: 'إكس أو ضد الذكاء الاصطناعي', en: 'Tic-tac-toe vs AI', Game: TicTacToe },
  { id: '2048', icon: '🔢', ar: 'لعبة 2048', en: '2048', Game: Game2048 },
  { id: 'memory', icon: '🧠', ar: 'لعبة الذاكرة', en: 'Memory match', Game: MemoryGame },
  { id: 'snake', icon: '🐍', ar: 'الثعبان', en: 'Snake', Game: SnakeGame }
];

/** ألعاب وترفيه: خمس ألعاب تعمل بالكامل داخل التطبيق. */
export default function Games() {
  const { L } = usePrefs();
  const [activeId, setActiveId] = useState('');
  const active = GAMES.find((game) => game.id === activeId);

  if (active) {
    const Game = active.Game;
    return (
      <section>
        <button type="button" className="buk-btn secondary" onClick={() => setActiveId('')}>
          ← {L('كل الألعاب', 'All games')}
        </button>
        <h2 className="buk-title">{active.icon} {L(active.ar, active.en)}</h2>
        <div className="buk-card">
          <Game />
        </div>
      </section>
    );
  }

  return (
    <section>
      <h2 className="buk-title">🎮 {L('ألعاب وترفيه', 'Games & fun')}</h2>
      <p className="buk-muted">
        {L('خمس ألعاب تعمل دون إنترنت خارجي — أولها شطرنج تلعبه ضد الذكاء الاصطناعي.',
          'Five games that run right here — starting with chess against the AI.')}
      </p>

      <div className="buk-tiles">
        {GAMES.map((game) => (
          <button key={game.id} type="button" className={`buk-tile${game.id === 'chess' ? ' hl' : ''}`} onClick={() => setActiveId(game.id)}>
            <span className="ico-glow">{game.icon}</span>
            <b>{L(game.ar, game.en)}</b>
          </button>
        ))}
      </div>

      <div className="buk-note">
        {L('كل لعبة تعمل داخل التطبيق وتُعاد من البداية بزر «لعبة جديدة». الشطرنج: أنت الأبيض في الأسفل، والترقية تلقائية إلى وزير.',
          'Every game runs inside the app and restarts with “New game”. In chess you play white from the bottom, and pawns promote to a queen automatically.')}
      </div>
    </section>
  );
}