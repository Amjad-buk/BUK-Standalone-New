import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { formatTime } from '@/lib/chat';
import { Image } from '@/components/ui/image';

const DAY = 24 * 60 * 60 * 1000;

export default function Stories() {
  const { user, settings, L } = usePrefs();
  const [items, setItems] = useState([]);
  const [text, setText] = useState('');
  const [status, setStatus] = useState('');
  const [openStory, setOpenStory] = useState(null);

  const load = async () => {
    if (!user) return;
    const page = await base44.entities.Story.filter({}, { sort: '-created_date', limit: 50 });
    const active = (page.items || []).filter((s) => new Date(s.expires_at).getTime() > Date.now());
    setItems(active);
  };

  useEffect(() => { load(); }, [user]);

  const publish = async (kind, mediaUrl) => {
    if (!user) return;
    const record = await base44.entities.Story.create({
      owner_id: user.id,
      owner_name: settings.display_name || user.full_name || user.email,
      kind,
      text: text || (kind === 'image' ? 'حالة مرئية' : 'حالة نصية جديدة'),
      media_url: mediaUrl || '',
      audience: settings.privacy_stories || 'friends',
      expires_at: new Date(Date.now() + DAY).toISOString()
    });
    setText('');
    setStatus(`تم نشر الحالة وتنتهي بعد 24 ساعة (${formatTime(record.expires_at)})`);
    await load();
  };

  const uploadImage = async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = '';
    if (!file) return;
    setStatus('جارٍ رفع الصورة…');
    const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
    await publish('image', file_url);
  };

  const mine = items.filter((s) => s.owner_id === (user && user.id));
  const others = items.filter((s) => s.owner_id !== (user && user.id));

  return (
    <section>
      <h2 className="buk-title">{L('الحالات', 'Stories')}</h2>
      <p className="buk-muted">{L('انشر حالة نصية أو مرئية تظهر 24 ساعة.', 'Post a text or media story that lasts 24 hours.')}</p>

      <div className="buk-card">
        <p className="buk-muted">{L('حالاتك', 'Your stories')}</p>
        {!mine.length ? <p className="buk-muted">{L('لم تنشر حالة بعد.', 'You have not posted a story yet.')}</p> : null}
        {mine.map((story) => (
          <button key={story.id} type="button" className="buk-row" style={{ background: 'none', border: 0, width: '100%', textAlign: 'start', color: 'inherit', cursor: 'pointer' }} onClick={() => setOpenStory(story)}>
            <div className="buk-avatar">{story.kind === 'image' ? '📷' : '✍️'}</div>
            <div className="buk-grow"><b>{story.text}</b><div className="buk-small">{L('تنتهي', 'Ends')} {formatTime(story.expires_at)}</div></div>
          </button>
        ))}
      </div>

      <div className="buk-card">
        <label className="buk-muted">{L('حالة نصية جديدة', 'New text story')}</label>
        <input className="buk-field" value={text} onChange={(e) => setText(e.target.value)} placeholder={L('اكتب حالتك', 'Write your story')} />
        <div className="buk-tiles" style={{ marginTop: 10 }}>
          <button type="button" className="buk-btn" onClick={() => publish('text')}>✍️ {L('نشر حالة نصية', 'Post text story')}</button>
          <label className="buk-btn secondary" style={{ textAlign: 'center', cursor: 'pointer' }}>
            📷 {L('نشر حالة مرئية', 'Post image story')}
            <input type="file" accept="image/*" hidden onChange={uploadImage} />
          </label>
        </div>
        {status ? <p className="buk-small">{status}</p> : null}
        <p className="buk-small">{L('الصور المخزّنة عامة — يمكن لأي شخص يملك الرابط فتحها.', 'Images are stored publicly — anyone with the link can open them.')}</p>
      </div>

      <h3 className="buk-title" style={{ fontSize: '1.1rem' }}>{L('حالات الآخرين', 'Stories from others')}</h3>
      <div className="buk-card">
        {!others.length ? <p className="buk-muted">{L('لا حالات نشطة الآن.', 'No active stories right now.')}</p> : null}
        <div className="flex flex-wrap gap-3">
          {others.map((story) => (
            <div key={story.id} className="text-center">
              <button type="button" className="buk-story-ring" onClick={() => setOpenStory(story)} aria-label={story.owner_name}>
                <div>{story.kind === 'image' && story.media_url ? '📷' : '✍️'}</div>
              </button>
              <div className="buk-small">{story.owner_name}</div>
            </div>
          ))}
        </div>
      </div>

      {openStory ? (
        <div className="buk-card" style={{ borderColor: 'var(--buk-cyan)' }}>
          <div className="buk-row">
            <div className="buk-grow"><b>{openStory.owner_name}</b><div className="buk-small">{formatTime(openStory.created_date)}</div></div>
            <button type="button" className="buk-btn secondary" onClick={() => setOpenStory(null)}>إغلاق</button>
          </div>
          {openStory.kind === 'image' && openStory.media_url ? (
            <Image src={openStory.media_url} alt="" className="rounded-2xl w-full max-h-96 object-cover" fittingType="fill" />
          ) : null}
          <p className="buk-title" style={{ fontSize: '1.1rem' }}>{openStory.text}</p>
        </div>
      ) : null}
    </section>
  );
}