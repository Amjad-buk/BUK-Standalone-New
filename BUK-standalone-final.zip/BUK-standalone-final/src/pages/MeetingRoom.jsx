import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { usePrefs } from '@/lib/prefs';
import MeetingExperience from '@/components/meeting/MeetingExperience';

/** غرفة الاجتماع للمستخدم المسجل: يدخلها المنشئ أو أي عضو لديه الرابط. */
export default function MeetingRoom() {
  const { code } = useParams();
  const { user } = usePrefs();
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <MeetingExperience
      code={String(code || '').toUpperCase()}
      identity={{ id: user.id, name: user.full_name || user.email || 'مشارك' }}
      onExit={() => navigate('/meeting')}
      exitLabel="عودة إلى الاجتماعات"
    />
  );
}