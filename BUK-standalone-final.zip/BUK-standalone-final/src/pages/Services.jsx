import React from 'react';
import { useNavigate } from 'react-router-dom';
import { usePrefs } from '@/lib/prefs';

const SERVICES = [
  { to: '/groups', icon: '👥', ar: 'المجموعات', en: 'Groups' },
  { to: '/games', icon: '🎮', ar: 'ألعاب وترفيه', en: 'Games & fun' },
  { to: '/stories', icon: '⭕', ar: 'الحالات', en: 'Stories' },
  { to: '/gift', icon: '🎁', ar: 'BUK Gift', en: 'BUK Gift' }
];

const EXTRA = [
  { to: '/translate', icon: '🌐', ar: 'الترجمة الفورية', en: 'Live translation' },
  { to: '/ai', icon: '🤖', ar: 'BUK AI', en: 'BUK AI' },
  { to: '/mypuki', icon: '✨', ar: 'My BUKI', en: 'My BUKI' },
  { to: '/live', icon: '🔴', ar: 'BUK مباشر', en: 'BUK Live' },
  { to: '/communities', icon: '🏙️', ar: 'المجتمعات', en: 'Communities' },
  { to: '/notes', icon: '📝', ar: 'BUK Note', en: 'BUK Note' },
  { to: '/profile', icon: '👤', ar: 'الملف الشخصي', en: 'Profile' },
  { to: '/search', icon: '⌕', ar: 'البحث', en: 'Search' }
];

/** شاشة «خدمات BUK» — بوابة بقية شاشات التطبيق. */
export default function Services() {
  const navigate = useNavigate();
  const { L } = usePrefs();

  const Tiles = ({ items }) => (
    <div className="buk-tiles">
      {items.map((tile) => (
        <button key={tile.to} type="button" className="buk-tile" onClick={() => navigate(tile.to)}>
          <span className="ico-glow">{tile.icon}</span>
          <b>{L(tile.ar, tile.en)}</b>
        </button>
      ))}
    </div>
  );

  return (
    <section>
      <div className="buk-row">
        <button type="button" className="buk-btn secondary" onClick={() => navigate('/')}>‹ {L('الرئيسية', 'Home')}</button>
      </div>

      <h2 className="buk-title">{L('خدمات BUK', 'BUK services')}</h2>
      <Tiles items={SERVICES} />

      <h2 className="buk-title mt-5">{L('المزيد من ميزات BUK', 'More BUK features')}</h2>
      <Tiles items={EXTRA} />
    </section>
  );
}