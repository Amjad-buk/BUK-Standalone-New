import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Loader2, Phone } from "lucide-react";
import PasswordInput from "@/components/auth/PasswordInput";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import { safeReturnTo } from "@/lib/authReturnTo";
import { isPhoneLike, phoneKey } from "@/lib/phone";

export default function Register() {
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirmPassword) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    if (!isPhoneLike(phone)) {
      setError("أدخل رقم هاتف صحيحًا");
      return;
    }
    setLoading(true);
    try {
      const displayName = email.split('@')[0].replace(/[._-]+/g, ' ').trim() || 'مستخدم BUK';
      const result = await base44.auth.register({ email, password, phone, name: displayName });
      if (!result?.access_token) throw new Error('لم يكتمل إنشاء الحساب.');
      await savePhoneToProfile();
      window.location.href = safeReturnTo();
    } catch (err) {
      setError(err.message || "تعذر إنشاء الحساب");
    } finally {
      setLoading(false);
    }
  };

  /** يحفظ رقم الهاتف في الملف الشخصي حتى يعمل الدخول بالهاتف. */
  const savePhoneToProfile = async () => {
    try {
      const me = await base44.auth.me();
      const key = phoneKey(phone);
      const rows = await base44.entities.BukProfile.filter({ user_id: me.id });
      if (rows && rows[0]) {
        await base44.entities.BukProfile.update(rows[0].id, { phone, phone_key: key });
      } else {
        await base44.entities.BukProfile.create({
          user_id: me.id,
          email: me.email,
          display_name: me.full_name || "",
          phone,
          phone_key: key
        });
      }
    } catch {
      /* لا نمنع الدخول إذا تعذر حفظ الرقم */
    }
  };

  const handleGoogle = () => {
    setError("تسجيل الدخول عبر Google يحتاج إعداد OAuth خاصًا بالخادم المستقل.");
  };

  return (
    <AuthLayout
      title="إنشاء حساب جديد"
      subtitle="سجّل رقم هاتفك وبريدك وكلمة المرور لإنشاء حساب BUK."
      footer={
        <>
          لديك حساب بالفعل؟{" "}
          <Link
            to={"/login" + (safeReturnTo() !== "/" ? "?returnTo=" + encodeURIComponent(safeReturnTo()) : "")}
            className="text-primary font-medium hover:underline"
          >
            تسجيل الدخول
          </Link>
        </>
      }
    >
      <Button
        variant="outline"
        className="w-full h-12 text-sm font-medium mb-6"
        onClick={handleGoogle}
      >
        <GoogleIcon className="w-5 h-5 me-2" />
        المتابعة بحساب Google
      </Button>

      <div className="relative mb-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs">
          <span className="bg-card px-3 text-muted-foreground">أو</span>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="phone">رقم الهاتف</Label>
          <div className="relative">
            <Phone className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              dir="ltr"
              autoFocus
              placeholder="+962 79 000 0000"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="ps-10 h-12"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">البريد الإلكتروني</Label>
          <div className="relative">
            <Mail className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              autoFocus
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="ps-10 h-12"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">كلمة المرور</Label>
          <PasswordInput
            id="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm">تأكيد كلمة المرور</Label>
          <PasswordInput
            id="confirm"
            autoComplete="new-password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 me-2 animate-spin" />
              جارٍ إنشاء الحساب…
            </>
          ) : (
            "إنشاء الحساب"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}