import React, { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';

export default function AiAssistant() {
  const { user, settings, L } = usePrefs();
  const [items, setItems] = useState([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const endRef = useRef(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const page = await base44.entities.AiMessage.filter({ owner_id: user.id, agent: 'ai' }, { sort: 'created_date', limit: 60 });
      setItems(page.items || []);
    })();
  }, [user]);

  useEffect(() => { if (endRef.current) endRef.current.scrollIntoView({ block: 'end' }); }, [items.length]);

  const send = async (event) => {
    event.preventDefault();
    const value = text.trim();
    if (!value || busy) return;
    setBusy(true);
    setError('');
    const history = items.map((m) => ({ role: m.role, content: m.content }));
    setItems((prev) => [...prev, { id: `local-${Date.now()}`, role: 'user', content: value }]);
    setText('');
    try {
      const response = await base44.functions.invoke('bukAssistant', { action: 'chat', agent: 'ai', text: value, history });
      const reply = response && response.data && response.data.reply;
      if (!reply) { setError('لم يصل رد من مزود الذكاء الاصطناعي.'); return; }
      setItems((prev) => [...prev, { id: `local-${Date.now()}-a`, role: 'assistant', content: reply }]);
      if (settings.save_ai_history) {
        await base44.entities.AiMessage.bulkCreate([
          { owner_id: user.id, agent: 'ai', role: 'user', content: value },
          { owner_id: user.id, agent: 'ai', role: 'assistant', content: reply }
        ]);
      }
    } catch (e) {
      setError('تعذر الاتصال بمزود الذكاء الاصطناعي. تحقق من الاتصال ثم أعد المحاولة.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <section>
      <div className="buk-card buk-hero">
        <div className="buk-orb">🤖</div>
        <h2 className="buk-title">BUK AI</h2>
        <p className="buk-muted">{L('مساعدك الذكي داخل BUK', 'Your smart assistant inside BUK')}</p>
      </div>

      <div className="buk-card" style={{ minHeight: 160 }}>
        {!items.length ? <p className="buk-muted">{L('اسأل عن أي شيء، أو اطلب تلخيصًا أو كتابة أو ترجمة.', 'Ask anything, or request a summary, writing or translation.')}</p> : null}
        {items.map((item) => (
          <div key={item.id} className={`buk-bubble ${item.role === 'user' ? 'mine' : 'theirs'}`}>
            <span className="buk-safe-scroll">{item.content}</span>
          </div>
        ))}
        {busy ? <p className="buk-muted">…</p> : null}
        <div ref={endRef} />
      </div>

      {error ? <div className="buk-note">{error}</div> : null}

      <form className="buk-search" onSubmit={send}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder={L('اكتب سؤالك هنا', 'Type your question here')} />
        <button className="buk-btn" disabled={busy}>{L('إرسال', 'Send')}</button>
      </form>

      <div className="buk-tiles">
        <button type="button" className="buk-btn secondary" onClick={() => { if (settings.save_ai_history) base44.entities.AiMessage.filter({ owner_id: user.id, agent: 'ai' }).then((rows) => (rows || []).forEach((r) => base44.entities.AiMessage.delete(r.id))); setItems([]); }}>
          {L('مسح السجل', 'Clear history')}
        </button>
        <span className="buk-small" style={{ alignSelf: 'center' }}>
          {settings.save_ai_history ? L('حفظ السجل مُفعّل', 'History saving on') : L('حفظ السجل مُعطّل', 'History saving off')}
        </span>
      </div>
    </section>
  );
}