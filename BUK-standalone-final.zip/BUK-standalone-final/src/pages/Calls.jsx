import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { Image } from '@/components/ui/image';

const MODES = [
  { id: 'video', icon: '📹', ar: 'مكالمة فيديو', en: 'Video call' },
  { id: 'audio', icon: '☎️', ar: 'مكالمة صوتية', en: 'Voice call' }
];

export default function Calls() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [mode, setMode] = useState('');
  const [term, setTerm] = useState('');
  const [results, setResults] = useState([]);
  const [status, setStatus] = useState('');

  const search = async () => {
    const value = term.trim();
    if (value.length < 2) { setStatus(L('اكتب حرفين على الأقل من اسم الصديق.', 'Type at least two characters of the friend name.')); return; }
    const page = await base44.entities.BukProfile.filter({ display_name: { $regex: value } }, { limit: 20 });
    setResults((page.items || []).filter((r) => r.user_id !== user.id));
    setStatus('');
  };

  const startCall = async (profile) => {
    const modeLabel = mode === 'video' ? 'فيديو' : 'صوتية';
    setStatus(L(`جارٍ بدء مكالمة ${modeLabel} مع ${profile.display_name}…`, `Starting the ${modeLabel} call with ${profile.display_name}…`));
    const record = await base44.entities.Call.create({
      caller_id: user.id,
      caller_name: user.full_name || user.email,
      callee_id: profile.user_id,
      callee_name: profile.display_name || '',
      mode,
      status: 'ringing',
      caller_ice: [],
      callee_ice: []
    });
    await base44.entities.Notification.create({
      user_id: profile.user_id,
      kind: 'call',
      title: `مكالمة ${modeLabel} واردة من BUK`,
      body: `${user.full_name || user.email} يطلب مكالمة ${modeLabel}`,
      link: `/call/${record.id}`
    }).catch(() => {});
    navigate(`/call/${record.id}`);
  };

  return (
    <section>
      <h2 className="buk-title">{L('المكالمات', 'Calls')}</h2>
      <p className="buk-muted">{L('اختر نوع المكالمة أولًا، ثم ابحث عن الصديق الذي تريد الاتصال به.', 'Pick the call type first, then search for the friend you want to call.')}</p>

      <div className="buk-tiles">
        {MODES.map((item) => (
          <button key={item.id} type="button" className={`buk-tile ${mode === item.id ? 'active' : ''}`} onClick={() => setMode(item.id)}>
            <span className="ico-glow">{item.icon}</span>
            <b>{L(item.ar, item.en)}</b>
          </button>
        ))}
      </div>

      <div className="buk-card">
        <b>{mode ? (mode === 'video' ? L('مكالمة فيديو', 'Video call') : L('مكالمة صوتية', 'Voice call')) : L('اختر فيديو أو صوت', 'Choose video or voice')}</b>
        <p className="buk-small">{L('للمكالمات الجماعية أنشئ اجتماعًا من BUK Meeting.', 'For group calls, create a meeting from BUK Meeting.')}</p>

        {mode ? (
          <>
            <div className="buk-search">
              <input value={term} onChange={(e) => setTerm(e.target.value)} placeholder={L('اكتب اسم الصديق المسجّل', "Type the friend's registered name")} />
              <button type="button" className="buk-btn" onClick={search}>{L('بحث', 'Search')}</button>
            </div>
            <div className="buk-card">
              {!results.length ? <p className="buk-muted">{L('لا نتائج بعد.', 'No results yet.')}</p> : null}
              {results.map((profile) => (
                <div key={profile.id} className="buk-row">
                  <div className="buk-avatar round">
                    {profile.avatar_url ? <Image src={profile.avatar_url} alt="" fittingType="fill" className="w-full h-full" /> : '👤'}
                  </div>
                  <div className="buk-grow"><b>{profile.display_name}</b><div className="buk-small">{L('حساب BUK', 'BUK account')}</div></div>
                  <button type="button" className="buk-btn" onClick={() => startCall(profile)}>{L('اتصال', 'Call')}</button>
                </div>
              ))}
            </div>
          </>
        ) : null}
      </div>

      {status ? <div className="buk-note">{status}</div> : null}
      <div className="buk-note">
        {L('المكالمة تُربط مباشرة بين الجهازين ويرنّ الهاتف الآخر بشاشة قبول أو رفض. اسمح بالوصول إلى الميكروفون والكاميرا عند أول مكالمة.',
          'The call connects the two devices directly and rings the other phone with accept or decline. Allow microphone and camera access on the first call.')}
      </div>
    </section>
  );
}