import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';

const THEMES = [
  { id: 'navy', cls: 'swatch-navy', ar: 'كحلي', en: 'Navy' },
  { id: 'light', cls: 'swatch-white', ar: 'أبيض', en: 'White' },
  { id: 'amber', cls: 'swatch-amber', ar: 'أصفر', en: 'Yellow' },
  { id: 'lime', cls: 'swatch-lime', ar: 'أخضر', en: 'Green' },
  { id: 'pink', cls: 'swatch-pink', ar: 'زهري', en: 'Pink' }
];

function Toggle({ value, onChange }) {
  return (
    <button type="button" className="buk-btn secondary" onClick={() => onChange(!value)}>
      {value ? 'مُفعّل' : 'مُعطّل'}
    </button>
  );
}

export default function Settings() {
  const { user, settings, update, L } = usePrefs();
  const navigate = useNavigate();
  const [saved, setSaved] = useState('');
  const [openPanel, setOpenPanel] = useState('');

  const change = async (patch, label) => {
    await update(patch);
    setSaved(label || 'تم الحفظ');
    setTimeout(() => setSaved(''), 2000);
  };

  return (
    <section>
      <h2 className="buk-title">{L('الإعدادات', 'Settings')}</h2>

      <div className="buk-card">
        <div className="buk-row">
          <div className="buk-avatar round">👤</div>
          <div className="buk-grow">
            <b>{settings.display_name || (user && (user.full_name || user.email))}</b>
            <div className="buk-small">{user ? user.email : ''}</div>
          </div>
          <button type="button" className="buk-btn secondary" onClick={() => navigate('/profile')}>{L('الملف', 'Profile')}</button>
        </div>
        <div className="buk-setting">
          <span>🚪 {L('تسجيل الخروج', 'Sign out')}</span>
          <button type="button" className="buk-btn secondary" onClick={() => base44.auth.logout()}>{L('خروج', 'Sign out')}</button>
        </div>
      </div>

      <div className="buk-card">
        <div className="buk-setting">
          <span>🎨 {L('المظهر والألوان', 'Theme & colors')}</span>
          <div className="buk-theme-palette">
            {THEMES.map((theme) => (
              <button
                key={theme.id}
                type="button"
                className={`buk-swatch ${theme.cls} ${settings.theme === theme.id ? 'active' : ''}`}
                onClick={() => change({ theme: theme.id }, `تم تطبيق سمة ${theme.ar}`)}
              >
                {L(theme.ar, theme.en)}
              </button>
            ))}
          </div>
        </div>

        <div className="buk-setting">
          <span>🔠 {L('حجم الخط', 'Font size')}</span>
          <select className="buk-select" value={settings.font_size} onChange={(e) => change({ font_size: Number(e.target.value) })}>
            <option value={14}>صغير</option>
            <option value={16}>متوسط</option>
            <option value={18}>كبير</option>
            <option value={20}>كبير جدًا</option>
            <option value={22}>ضخم</option>
          </select>
        </div>

        <div className="buk-setting">
          <span>✒️ {L('نوع الخط', 'Font family')}</span>
          <select className="buk-select" value={settings.font_family} onChange={(e) => change({ font_family: e.target.value })}>
            <option value="system">افتراضي</option>
            <option value="arial">Arial</option>
            <option value="tahoma">Tahoma</option>
            <option value="trebuchet">Trebuchet MS</option>
            <option value="georgia">Georgia</option>
          </select>
        </div>

        <div className="buk-setting">
          <span>🌐 {L('اللغة', 'Language')}</span>
          <select className="buk-select" value={settings.language} onChange={(e) => change({ language: e.target.value })}>
            <option value="ar">العربية</option>
            <option value="en">English</option>
          </select>
        </div>
        {saved ? <div className="buk-small" role="status">{saved}</div> : null}
      </div>

      <button type="button" className="buk-setting buk-card" style={{ width: '100%' }} onClick={() => setOpenPanel(openPanel === 'notif' ? '' : 'notif')}>
        <span>🔔 {L('الإشعارات', 'Notifications')}</span>
        <span>›</span>
      </button>
      {openPanel === 'notif' ? (
        <div className="buk-card">
          {[
            ['notif_messages', 'إشعارات الرسائل', 'Message notifications'],
            ['notif_calls', 'إشعارات المكالمات', 'Call notifications'],
            ['notif_meetings', 'طلبات الانضمام إلى الاجتماعات', 'Meeting join requests'],
            ['notif_reminders', 'إشعارات التذكيرات', 'Reminder notifications'],
            ['notif_sound', 'صوت التنبيه', 'Alert sound']
          ].map(([key, ar, en]) => (
            <div key={key} className="buk-setting">
              <span>{L(ar, en)}</span>
              <Toggle value={!!settings[key]} onChange={(v) => change({ [key]: v })} />
            </div>
          ))}
        </div>
      ) : null}

      <button type="button" className="buk-setting buk-card" style={{ width: '100%' }} onClick={() => setOpenPanel(openPanel === 'privacy' ? '' : 'privacy')}>
        <span>🔒 {L('الخصوصية', 'Privacy')}</span>
        <span>›</span>
      </button>
      {openPanel === 'privacy' ? (
        <div className="buk-card">
          <div className="buk-setting">
            <span>{L('ظهور آخر ظهور', 'Last seen')}</span>
            <select className="buk-select" value={settings.privacy_last_seen} onChange={(e) => change({ privacy_last_seen: e.target.value })}>
              <option value="everyone">الجميع</option>
              <option value="friends">أصدقائي</option>
              <option value="nobody">لا أحد</option>
            </select>
          </div>
          <div className="buk-setting">
            <span>{L('من يرى صورتي', 'Profile photo visibility')}</span>
            <select className="buk-select" value={settings.privacy_photo} onChange={(e) => change({ privacy_photo: e.target.value })}>
              <option value="everyone">الجميع</option>
              <option value="friends">أصدقائي</option>
              <option value="nobody">لا أحد</option>
            </select>
          </div>
          <div className="buk-setting">
            <span>{L('جمهور حالاتي', 'Stories audience')}</span>
            <select className="buk-select" value={settings.privacy_stories} onChange={(e) => change({ privacy_stories: e.target.value })}>
              <option value="public">عامة</option>
              <option value="friends">أصدقائي</option>
              <option value="only_me">أنا فقط</option>
            </select>
          </div>
          <div className="buk-setting">
            <span>{L('مؤشرات القراءة', 'Read receipts')}</span>
            <Toggle value={!!settings.read_receipts} onChange={(v) => change({ read_receipts: v })} />
          </div>
        </div>
      ) : null}

      <button type="button" className="buk-setting buk-card" style={{ width: '100%' }} onClick={() => setOpenPanel(openPanel === 'data' ? '' : 'data')}>
        <span>💾 {L('البيانات والتخزين', 'Data & storage')}</span>
        <span>›</span>
      </button>
      {openPanel === 'data' ? (
        <div className="buk-card">
          <div className="buk-setting">
            <span>{L('ذاكرة الإعدادات المحلية', 'Local settings cache')}</span>
            <button
              type="button"
              className="buk-btn secondary"
              onClick={() => {
                try { localStorage.removeItem('buk.prefs'); } catch { /* تجاهل */ }
                setSaved('تم مسح الذاكرة المحلية');
              }}
            >
              مسح
            </button>
          </div>
          <p className="buk-muted">{L('محادثاتك ورسائلك وتذكيراتك محفوظة في قاعدة بيانات BUK، لا في هذا الجهاز فقط.',
            'Your chats, messages and reminders are stored in the BUK database, not only on this device.')}</p>
        </div>
      ) : null}

      <button type="button" className="buk-setting buk-card" style={{ width: '100%' }} onClick={() => setOpenPanel(openPanel === 'about' ? '' : 'about')}>
        <span>ℹ️ {L('حول BUK', 'About BUK')}</span>
        <span>›</span>
      </button>
      {openPanel === 'about' ? (
        <div className="buk-card">
          <p className="buk-muted">
            BUK — {L('تواصل بلا حدود', 'Connect without limits')}<br />
            {L('الإطلاق المستهدف: 1 يناير 2027', 'Target launch: 1 January 2027')}<br />
            {L('اللغات المدعومة في الواجهة: العربية والإنجليزية', 'Interface languages: Arabic and English')}
          </p>
        </div>
      ) : null}

      <div className="buk-note">{L('تُحفظ الإعدادات في حسابك، وتعود كما هي عند إعادة فتح التطبيق أو الدخول من جهاز آخر.',
        'Settings are saved to your account and restored when you reopen the app or sign in from another device.')}</div>
    </section>
  );
}