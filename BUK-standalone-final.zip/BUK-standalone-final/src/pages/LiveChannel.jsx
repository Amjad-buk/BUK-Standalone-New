import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { roomApi } from '@/lib/meeting';
import { usePrefs } from '@/lib/prefs';
import { archivesFor, dateLabel, followerCounts, notifyFollowers, toggleFollow } from '@/lib/live';
import { Image } from '@/components/ui/image';
import ChannelForm from '@/components/live/ChannelForm';

/** صفحة القناة: بياناتها ومتابعوها وبثها الحالي وأرشيف بثوثها. */
export default function LiveChannel() {
  const { id } = useParams();
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [channel, setChannel] = useState(null);
  const [missing, setMissing] = useState(false);
  const [counts, setCounts] = useState({});
  const [following, setFollowing] = useState(false);
  const [archives, setArchives] = useState([]);
  const [room, setRoom] = useState(null);
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const record = await base44.entities.LiveChannel.get(id).catch(() => null);
    if (!record) {
      setMissing(true);
      return;
    }
    setChannel(record);
    const [countMap, archiveRows, liveData, followRows] = await Promise.all([
      followerCounts().catch(() => ({})),
      archivesFor(id),
      roomApi('live').catch(() => ({ rooms: [] })),
      user
        ? base44.entities.LiveFollow.filter({ channel_id: id, user_id: user.id }, { limit: 1 }).catch(() => ({ items: [] }))
        : { items: [] }
    ]);
    setCounts(countMap);
    setArchives(archiveRows);
    setFollowing((followRows.items || []).length > 0);
    setRoom((liveData.rooms || []).find((item) => item.channel_id === id) || null);
  };

  useEffect(() => {
    load();
  }, [id, user]);

  const isOwner = !!channel && !!user && channel.owner_id === user.id;

  const follow = async () => {
    if (!user || !channel) return;
    await toggleFollow(channel.id, user);
    load();
  };

  const goLive = async () => {
    if (!channel || busy) return;
    setBusy(true);
    const streamTitle = title.trim() || L('بث مباشر', 'Live stream');
    setStatus(L('جارٍ إنشاء غرفة البث على الخادم…', 'Creating the live room on the server…'));
    const data = await roomApi('create', { title: streamTitle, kind: 'live', channel_id: channel.id }).catch(() => ({}));
    if (!data.meeting || !data.meeting.code) {
      setBusy(false);
      setStatus(L('تعذر بدء البث — حاول مجددًا.', 'Could not start the stream — try again.'));
      return;
    }
    await notifyFollowers(channel, { code: data.meeting.code, title: streamTitle }, user.id).catch(() => 0);
    setBusy(false);
    navigate(`/live/${data.meeting.code}`);
  };

  if (missing) {
    return (
      <section>
        <h2 className="buk-title">{L('القناة غير موجودة', 'Channel not found')}</h2>
        <Link className="buk-btn" to="/live">{L('عودة إلى BUK مباشر', 'Back to BUK Live')}</Link>
      </section>
    );
  }

  if (!channel) return <p className="buk-muted">{L('جارٍ تحميل القناة…', 'Loading channel…')}</p>;

  return (
    <section>
      <header className="buk-card">
        <div className="buk-row" style={{ borderBottom: 'none' }}>
          <div className="buk-avatar round" style={{ width: 64, height: 64, flex: '0 0 64px' }}>
            {channel.avatar_url ? <Image src={channel.avatar_url} alt="" fittingType="fill" className="w-full h-full" /> : '📺'}
          </div>
          <div className="buk-grow">
            <b>{channel.name}</b>
            <div className="buk-small">{channel.handle}</div>
            <div className="buk-small">{counts[channel.id] || 0} {L('متابع', 'followers')}</div>
          </div>
        </div>
        {channel.description ? <p className="buk-muted">{channel.description}</p> : null}
        {!isOwner ? (
          <button type="button" className={`buk-btn wide ${following ? 'secondary' : ''}`} onClick={follow}>
            {following ? L('إلغاء المتابعة', 'Unfollow') : L('متابعة', 'Follow')}
          </button>
        ) : null}
      </header>

      {room ? (
        <div className="buk-card">
          <b>🔴 {L('يبث الآن', 'Live now')}</b>
          <div className="buk-row">
            <div className="buk-grow">
              <b>{room.title}</b>
              <div className="buk-small">{L('يشاهد الآن', 'watching')}: {room.viewers}</div>
            </div>
            <Link className="buk-btn" to={`/live/${room.code}`}>{L('مشاهدة', 'Watch')}</Link>
          </div>
        </div>
      ) : null}

      {isOwner ? (
        <div className="buk-card">
          <b>{L('بدء بث على هذه القناة', 'Go live on this channel')}</b>
          <input
            className="buk-field"
            style={{ marginTop: 10 }}
            maxLength={100}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={L('عنوان البث', 'Stream title')}
          />
          <button type="button" className="buk-btn wide" style={{ marginTop: 10 }} onClick={goLive} disabled={busy}>
            🔴 {busy ? L('جارٍ البدء…', 'Starting…') : L('بدء البث', 'Start streaming')}
          </button>
          {status ? <p className="buk-small">{status}</p> : null}
          <div style={{ marginTop: 12 }}>
            <ChannelForm channel={channel} onSaved={load} />
          </div>
        </div>
      ) : null}

      <div className="buk-card">
        <b>{L('البثوث المحفوظة', 'Saved streams')}</b>
        {!archives.length ? <p className="buk-muted">{L('لا يوجد أرشيف لهذه القناة بعد.', 'This channel has no archive yet.')}</p> : null}
        {archives.map((item) => (
          <div key={item.id} className="buk-row">
            <div className="buk-avatar">🎬</div>
            <div className="buk-grow">
              <b>{item.title}</b>
              <div className="buk-small">
                {dateLabel(item.ended_at)} · {L('المشاهدون', 'viewers')}: {item.viewers || 0}
              </div>
            </div>
          </div>
        ))}
      </div>

      <Link className="buk-btn secondary wide" to="/live" style={{ display: 'block', textAlign: 'center' }}>
        {L('عودة إلى BUK مباشر', 'Back to BUK Live')}
      </Link>
    </section>
  );
}