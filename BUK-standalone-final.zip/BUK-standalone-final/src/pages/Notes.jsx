import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { formatTime } from '@/lib/chat';

export default function Notes() {
  const { user, L } = usePrefs();
  const [params, setParams] = useSearchParams();
  const kind = params.get('tab') === 'word' ? 'word' : 'note';
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [editing, setEditing] = useState(null);
  const [status, setStatus] = useState('');

  const load = async () => {
    if (!user) return;
    const page = await base44.entities.Note.filter({ owner_id: user.id, kind }, { sort: '-created_date', limit: 100 });
    setItems(page.items || []);
  };

  useEffect(() => { load(); }, [user, kind]);

  const save = async (event) => {
    event.preventDefault();
    if (!title.trim() && !body.trim()) return;
    if (editing) {
      await base44.entities.Note.update(editing.id, { title, body });
      setStatus('تم تحديث المحتوى');
    } else {
      await base44.entities.Note.create({ owner_id: user.id, kind, title, body });
      setStatus('تم الحفظ');
    }
    setTitle('');
    setBody('');
    setEditing(null);
    await load();
  };

  const startEdit = (item) => {
    setEditing(item);
    setTitle(item.title || '');
    setBody(item.body || '');
  };

  return (
    <section>
      <h2 className="buk-title">{kind === 'word' ? 'BUK Word' : 'BUK Note'}</h2>
      <div className="buk-tiles">
        <button type="button" className={`buk-btn ${kind === 'note' ? '' : 'secondary'}`} onClick={() => setParams({ tab: 'note' })}>BUK Note</button>
        <button type="button" className={`buk-btn ${kind === 'word' ? '' : 'secondary'}`} onClick={() => setParams({ tab: 'word' })}>BUK Word</button>
      </div>

      <form className="buk-card" onSubmit={save}>
        <label className="buk-muted">{editing ? L('تعديل', 'Edit') : L('جديد', 'New')}</label>
        <input className="buk-field" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={L('العنوان', 'Title')} />
        <textarea className="buk-field" rows={5} value={body} onChange={(e) => setBody(e.target.value)} placeholder={L('النص', 'Content')} />
        <div className="buk-tiles" style={{ marginTop: 10 }}>
          <button className="buk-btn" type="submit">{editing ? L('تحديث', 'Update') : L('حفظ', 'Save')}</button>
          {editing ? (
            <button type="button" className="buk-btn secondary" onClick={() => { setEditing(null); setTitle(''); setBody(''); }}>
              {L('إلغاء', 'Cancel')}
            </button>
          ) : null}
        </div>
        {status ? <p className="buk-small">{status}</p> : null}
      </form>

      <div className="buk-card">
        {!items.length ? <p className="buk-muted">{L('لا يوجد محتوى محفوظ بعد.', 'Nothing saved yet.')}</p> : null}
        {items.map((item) => (
          <div key={item.id} className="buk-row">
            <div className="buk-avatar">{item.pinned ? '📌' : kind === 'word' ? '📄' : '📝'}</div>
            <div className="buk-grow">
              <b>{item.title || L('بدون عنوان', 'Untitled')}</b>
              <div className="buk-small buk-safe-scroll">{(item.body || '').slice(0, 120)}</div>
              <div className="buk-small">{formatTime(item.created_date)}</div>
            </div>
            <button
              type="button"
              className="buk-btn secondary"
              onClick={async () => { await base44.entities.Note.update(item.id, { pinned: !item.pinned }); load(); }}
            >
              {item.pinned ? L('إلغاء التثبيت', 'Unpin') : L('تثبيت', 'Pin')}
            </button>
            <button type="button" className="buk-btn secondary" onClick={() => startEdit(item)}>{L('تعديل', 'Edit')}</button>
            <button
              type="button"
              className="buk-btn danger"
              onClick={async () => { await base44.entities.Note.delete(item.id); load(); }}
            >
              {L('حذف', 'Delete')}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}