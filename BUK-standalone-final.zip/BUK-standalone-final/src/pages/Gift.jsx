import React, { useState } from 'react';
import { usePrefs } from '@/lib/prefs';

const GIFTS = [
  { id: 'star', icon: '⭐', name: 'نجمة' },
  { id: 'rose', icon: '🌹', name: 'وردة' },
  { id: 'heart', icon: '💙', name: 'قلب أزرق' },
  { id: 'crown', icon: '👑', name: 'تاج' }
];

export default function Gift() {
  const { L } = usePrefs();
  const [picked, setPicked] = useState(null);

  return (
    <section>
      <div className="buk-card buk-hero">
        <div className="buk-orb">🎁</div>
        <h2 className="buk-title">BUK Gift</h2>
        <p className="buk-muted">{L('اختيار هدية رقمية.', 'Pick a digital gift.')}</p>
        <div className="buk-tiles">
          {GIFTS.map((gift) => (
            <button key={gift.id} type="button" className="buk-tile" onClick={() => setPicked(gift)}>
              <span className="ico-glow">{gift.icon}</span>
              <b>{gift.name}</b>
            </button>
          ))}
        </div>
        <div className="buk-note">
          {picked
            ? `${picked.icon} ${L('اخترت', 'You picked')}: ${picked.name}`
            : L('اختر هدية لمعاينتها.', 'Pick a gift to preview it.')}
        </div>
        <p className="buk-muted">{L('الهدايا لا تُرسل إلى مستخدمين آخرين في هذه النسخة.', 'Gifts are not sent to other users in this version.')}</p>
      </div>
    </section>
  );
}