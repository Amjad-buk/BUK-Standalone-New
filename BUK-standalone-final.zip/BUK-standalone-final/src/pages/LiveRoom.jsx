import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { roomApi } from '@/lib/meeting';
import { usePrefs } from '@/lib/prefs';
import MeetingExperience from '@/components/meeting/MeetingExperience';

/** غرفة BUK مباشر: نفس محرك الغرفة على الخادم، وبنهايتها يُحفظ البث في أرشيف القناة. */
export default function LiveRoom() {
  const { code } = useParams();
  const { user } = usePrefs();
  const navigate = useNavigate();
  const [info, setInfo] = useState(null);
  const roomCode = String(code || '').toUpperCase();

  useEffect(() => {
    roomApi('info', { code: roomCode }).then((data) => setInfo(data.info || null)).catch(() => {});
  }, [roomCode]);

  if (!user) return null;

  const leave = async () => {
    const latest = await roomApi('info', { code: roomCode }).catch(() => ({}));
    const meta = latest.info || info;
    if (meta && meta.host_id === user.id && meta.channel_id) {
      await base44.entities.LiveArchive.create({
        channel_id: meta.channel_id,
        title: meta.title || 'بث مباشر',
        host_id: user.id,
        host_name: meta.host_name || '',
        code: roomCode,
        viewers: meta.viewers || 0,
        started_at: meta.started_at,
        ended_at: new Date().toISOString()
      }).catch(() => {});
    }
    navigate('/live');
  };

  return (
    <MeetingExperience
      code={roomCode}
      identity={{ id: user.id, name: user.full_name || user.email || 'مشاهد BUK' }}
      onExit={leave}
      exitLabel="عودة إلى BUK مباشر"
    />
  );
}