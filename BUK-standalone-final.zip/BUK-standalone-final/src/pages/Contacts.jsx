import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { findOrCreateDirect } from '@/lib/chat';
import { canReadContacts, matchWithBuk, pickDeviceContacts, sendInvite, uniqueRows } from '@/lib/contacts';
import { phoneKey } from '@/lib/phone';
import ContactRow from '@/components/contacts/ContactRow';
import ManualInvite from '@/components/contacts/ManualInvite';

/** مزامنة جهات اتصال الجهاز: من على BUK تفتح معه محادثة، ومن ليس عليه تصلُه دعوة SMS باسم BUK. */
export default function Contacts() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [rows, setRows] = useState([]);
  const [invites, setInvites] = useState([]);
  const [syncing, setSyncing] = useState(false);
  const [busyKey, setBusyKey] = useState('');
  const [bulk, setBulk] = useState(false);
  const [status, setStatus] = useState('');

  const loadInvites = async () => {
    if (!user) return;
    const page = await base44.entities.ContactInvite.filter(
      { owner_id: user.id },
      { sort: '-created_date', limit: 30 }
    );
    setInvites(page.items || []);
  };

  useEffect(() => {
    loadInvites().catch(() => {});
  }, [user]);

  const sync = async () => {
    setStatus('');
    if (!canReadContacts()) {
      setStatus(L('هذا المتصفح لا يسمح بقراءة جهات الاتصال — استخدم الإضافة اليدوية بالأسفل.',
        'This browser cannot read contacts — use the manual option below.'));
      return;
    }
    setSyncing(true);
    try {
      const picked = await pickDeviceContacts();
      if (!picked.ok) {
        setStatus(L('لم تُمنح صلاحية قراءة جهات الاتصال.', 'Contacts permission was not granted.'));
        return;
      }
      if (!picked.rows.length) {
        setStatus(L('لم يُختَر أي رقم.', 'No number was selected.'));
        return;
      }
      const matched = await matchWithBuk(picked.rows);
      setRows(matched);
      const onBuk = matched.filter((row) => row.on_buk).length;
      setStatus(`تمت المزامنة: ${matched.length} رقمًا، منهم ${onBuk} على BUK.`);
    } catch {
      setStatus(L('تعذر إكمال المزامنة — أعد المحاولة.', 'Sync could not be completed — try again.'));
    } finally {
      setSyncing(false);
    }
  };

  const inviteRow = async (row) => {
    setBusyKey(row.key);
    setStatus('');
    try {
      const data = await sendInvite(row.phone, row.name);
      if (data.error === 'not_configured') {
        setStatus('خدمة إرسال الدعوات تحتاج مفاتيحها في الإعدادات قبل أن تعمل.');
        return;
      }
      if (data.error === 'daily_limit') {
        setStatus('بلغت الحد اليومي للدعوات — أكمل غدًا.');
        return;
      }
      if (data.error) {
        setStatus(data.detail || 'تعذر إرسال الدعوة لهذا الرقم.');
        return;
      }
      setRows((prev) => prev.map((item) => (item.key === row.key ? { ...item, invited: true } : item)));
      await loadInvites();
      setStatus(data.duplicate ? 'سبق أن أرسلت لهذا الرقم دعوة خلال الأسبوع.' : 'أُرسلت الدعوة باسم BUK.');
    } finally {
      setBusyKey('');
    }
  };

  const inviteAll = async () => {
    const pending = rows.filter((row) => !row.on_buk && !row.invited);
    if (!pending.length) {
      setStatus(L('لا أرقام متبقية تحتاج دعوة.', 'No numbers left to invite.'));
      return;
    }
    setBulk(true);
    setStatus('');
    let sent = 0;
    for (const row of pending) {
      const data = await sendInvite(row.phone, row.name);
      if (data.ok) {
        sent += 1;
        setRows((prev) => prev.map((item) => (item.key === row.key ? { ...item, invited: true } : item)));
      }
    }
    await loadInvites();
    setBulk(false);
    setStatus(`أُرسلت ${sent} دعوة باسم BUK من أصل ${pending.length}.`);
  };

  const manualInvite = async (name, phone) => {
    const row = { key: phoneKey(phone), name, phone };
    setRows((prev) => uniqueRows([...prev, row]));
    await inviteRow(row);
  };

  const openChat = async (row) => {
    if (!user) return;
    const conversation = await findOrCreateDirect(user, { user_id: row.user_id, display_name: row.display_name });
    navigate(`/chat/${conversation.id}`);
  };

  const pendingCount = rows.filter((row) => !row.on_buk && !row.invited).length;

  return (
    <section>
      <h2 className="buk-title">{L('مزامنة جهات الاتصال', 'Sync contacts')}</h2>
      <p className="buk-muted">
        {L('نطابق أرقام جهات اتصالك مع BUK، ومن ليس لديه حساب تصلُه دعوة SMS مرسلها BUK لا رقمك.',
          'We match your contacts with BUK; anyone without an account gets an SMS invite sent by BUK, not your number.')}
      </p>

      <button type="button" className="buk-btn wide" onClick={sync} disabled={syncing}>
        {syncing ? '…' : L('مزامنة جهات الاتصال الآن', 'Sync contacts now')}
      </button>
      {status ? <div className="buk-note">{status}</div> : null}

      {rows.length ? (
        <div className="buk-card">
          {pendingCount ? (
            <button type="button" className="buk-btn secondary wide" onClick={inviteAll} disabled={bulk}>
              {bulk ? '…' : `دعوة كل من ليس على BUK (${pendingCount})`}
            </button>
          ) : null}
          {rows.map((row) => (
            <ContactRow
              key={row.key}
              row={row}
              L={L}
              busy={busyKey === row.key || bulk}
              onInvite={inviteRow}
              onChat={openChat}
            />
          ))}
        </div>
      ) : null}

      <ManualInvite L={L} busy={Boolean(busyKey) || bulk} onSend={manualInvite} />

      {invites.length ? (
        <div className="buk-card">
          <b>{L('الدعوات المرسلة', 'Sent invites')}</b>
          {invites.map((invite) => (
            <div key={invite.id} className="buk-row">
              <div className="buk-avatar round">{invite.status === 'sent' ? '✅' : '⚠️'}</div>
              <div className="buk-grow">
                <b>{invite.name || invite.phone}</b>
                <div className="buk-small">
                  {invite.phone} · {invite.status === 'sent' ? 'أُرسلت باسم BUK' : 'فشل الإرسال'}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </section>
  );
}