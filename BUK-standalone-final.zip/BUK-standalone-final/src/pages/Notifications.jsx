import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { formatTime } from '@/lib/chat';

const ICONS = { message: '💬', call: '☎️', meeting: '🎥', friend: '👥', reminder: '⏰', system: '🔔' };

export default function Notifications() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) return;
    const page = await base44.entities.Notification.filter({ user_id: user.id }, { sort: '-created_date', limit: 50 });
    setItems(page.items || []);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const unsubscribe = base44.entities.Notification.subscribe(() => load());
    return unsubscribe;
  }, [user]);

  const markAll = async () => {
    await base44.entities.Notification.updateMany({ user_id: user.id, read: false }, { $set: { read: true } });
    load();
  };

  return (
    <section>
      <h2 className="buk-title">{L('الإشعارات', 'Notifications')}</h2>
      <div className="buk-row">
        <p className="buk-muted buk-grow">{L('إشعارات الرسائل والمكالمات والاجتماعات والتذكيرات.', 'Message, call, meeting and reminder notifications.')}</p>
        <button type="button" className="buk-btn secondary" onClick={markAll}>{L('تعليم الكل كمقروء', 'Mark all read')}</button>
      </div>

      {loading ? <p className="buk-muted">{L('جارٍ التحميل…', 'Loading…')}</p> : null}
      <div className="buk-card">
        {!items.length && !loading ? <p className="buk-muted">{L('لا إشعارات بعد.', 'No notifications yet.')}</p> : null}
        {items.map((item) => (
          <button
            key={item.id}
            type="button"
            className="buk-row"
            style={{ background: 'none', border: 0, width: '100%', textAlign: 'start', cursor: 'pointer', color: 'inherit' }}
            onClick={async () => {
              if (!item.read) await base44.entities.Notification.update(item.id, { read: true });
              if (item.link) navigate(item.link);
              else load();
            }}
          >
            <div className="buk-avatar">{ICONS[item.kind] || '🔔'}</div>
            <div className="buk-grow">
              <b>{item.title}</b>
              <div className="buk-small">{item.body}</div>
            </div>
            <span className="buk-small">{formatTime(item.created_date)}</span>
            {!item.read ? <span className="buk-dot read" /> : null}
          </button>
        ))}
      </div>
    </section>
  );
}