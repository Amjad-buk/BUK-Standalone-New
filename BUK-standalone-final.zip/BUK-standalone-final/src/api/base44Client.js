const API_BASE = String(import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const TOKEN_KEY = 'buk_access_token';

function getToken() {
  if (typeof window === 'undefined') return '';
  return window.localStorage.getItem(TOKEN_KEY) || '';
}
function setToken(token) {
  if (typeof window !== 'undefined') {
    if (token) window.localStorage.setItem(TOKEN_KEY, token);
    else window.localStorage.removeItem(TOKEN_KEY);
  }
}
function apiUrl(path) { return `${API_BASE}/api${path}`; }

async function request(path, { method = 'GET', body, headers = {}, auth = true } = {}) {
  const h = { ...headers };
  if (body instanceof FormData) {
    // The browser must add the multipart boundary itself.
  } else if (body !== undefined) h['Content-Type'] = 'application/json';
  if (auth && getToken()) h.Authorization = `Bearer ${getToken()}`;
  const response = await fetch(apiUrl(path), {
    method,
    headers: h,
    body: body === undefined ? undefined : (body instanceof FormData ? body : JSON.stringify(body)),
    credentials: 'same-origin'
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || data.message || `HTTP ${response.status}`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

function decoratePage(data) {
  const items = Array.isArray(data?.items) ? data.items : [];
  const page = { ...(data || {}), items, length: items.length };
  items.forEach((item, index) => { page[index] = item; });
  page.forEach = (...args) => items.forEach(...args);
  page.map = (...args) => items.map(...args);
  page.filterArray = (...args) => items.filter(...args);
  page.find = (...args) => items.find(...args);
  page[Symbol.iterator] = function* iterator() { yield* items; };
  return page;
}

function createEntity(name) {
  const endpoint = `/entities/${encodeURIComponent(name)}`;
  return {
    filter: async (query = {}, options = {}) => decoratePage(await request(`${endpoint}/filter`, { method: 'POST', body: { query, ...options } })),
    list: async (options = {}) => decoratePage(await request(`${endpoint}/list`, { method: 'POST', body: options })),
    get: (id) => request(`${endpoint}/${encodeURIComponent(id)}`),
    create: (data) => request(endpoint, { method: 'POST', body: data }),
    update: (id, data) => request(`${endpoint}/${encodeURIComponent(id)}`, { method: 'PATCH', body: data }),
    delete: (id) => request(`${endpoint}/${encodeURIComponent(id)}`, { method: 'DELETE' }),
    bulkCreate: async (items) => (await request(`${endpoint}/bulk-create`, { method: 'POST', body: { items } })).items || [],
    bulkUpdate: (items) => request(`${endpoint}/bulk-update`, { method: 'POST', body: { items } }),
    updateMany: (query, update) => request(`${endpoint}/update-many`, { method: 'POST', body: { query, update } }),
    deleteMany: (query) => request(`${endpoint}/delete-many`, { method: 'POST', body: { query } }),
    count: async (query = {}) => (await request(`${endpoint}/count`, { method: 'POST', body: { query } })).count,
    aggregate: (config = {}) => request(`${endpoint}/aggregate`, { method: 'POST', body: config }),
    subscribe: (callback, interval = 3500) => {
      let stopped = false;
      let timer;
      let lastSignature = '';
      const poll = async () => {
        try {
          const page = await request(`${endpoint}/filter`, { method: 'POST', body: { query: {}, limit: 100 } });
          const signature = JSON.stringify((page.items || []).map(row => [row.id, row.updated_date, row.updated_at]));
          if (lastSignature && signature !== lastSignature) callback({ type: 'change', entity: name });
          lastSignature = signature;
        } catch {
          // Temporary connectivity loss is handled by the component's next fetch.
        } finally {
          if (!stopped) timer = window.setTimeout(poll, interval);
        }
      };
      if (typeof window !== 'undefined') timer = window.setTimeout(poll, 250);
      return () => { stopped = true; if (timer) window.clearTimeout(timer); };
    }
  };
}

const entities = new Proxy({}, { get: (_target, key) => createEntity(String(key)) });

const auth = {
  me: async () => {
    const data = await request('/auth/me');
    return data.user;
  },
  isAuthenticated: () => Boolean(getToken()),
  setToken,
  loginViaEmailPassword: async (email, password) => {
    const data = await request('/auth/login', { method: 'POST', auth: false, body: { method: 'email', identity: email, password } });
    setToken(data.access_token);
    return data;
  },
  register: async ({ email, password, phone, name }) => {
    const data = await request('/auth/register', { method: 'POST', auth: false, body: { email, password, phone, name } });
    setToken(data.access_token);
    return data;
  },
  verifyOtp: async () => { throw new Error('لم يعد تسجيل الحساب المستقل يستخدم رمز تحقق Base44.'); },
  resendOtp: async () => { throw new Error('إعادة إرسال OTP غير مفعّلة في النسخة المستقلة.'); },
  loginWithProvider: () => { throw new Error('تسجيل الدخول عبر Google يحتاج إعداد OAuth في الخادم المستقل.'); },
  resetPasswordRequest: (email) => request('/auth/forgot-password', { method: 'POST', auth: false, body: { email } }),
  resetPassword: ({ resetToken, newPassword }) => request('/auth/reset-password', { method: 'POST', auth: false, body: { token: resetToken, password: newPassword } }),
  logout: (returnTo) => { setToken(''); if (returnTo) window.location.href = '/login'; },
  redirectToLogin: (returnTo) => { const safe = returnTo && String(returnTo).startsWith('/') && !String(returnTo).startsWith('//') ? returnTo : '/'; window.location.href = `/login?returnTo=${encodeURIComponent(safe)}`; }
};

const integrations = {
  UploadPrivateFile: async ({ file }) => request('/files/upload', { method: 'POST', body: (() => { const fd = new FormData(); fd.append('file', file); fd.append('public', 'false'); return fd; })() }),
  UploadPublicFile: async ({ file }) => {
    const result = await request('/files/upload', { method: 'POST', body: (() => { const fd = new FormData(); fd.append('file', file); fd.append('public', 'true'); return fd; })() });
    return { ...result, file_url: new URL(result.file_url, window.location.origin).toString() };
  },
  CreateFileSignedUrl: async ({ file_uri, expires_in }) => {
    const result = await request('/files/signed-url', { method: 'POST', body: { file_uri, expires_in } });
    return { ...result, signed_url: new URL(result.signed_url, window.location.origin).toString() };
  }
};

export const base44 = {
  auth,
  entities,
  app: { getPublicSettings: () => request('/app/public-settings', { auth: false }) },
  functions: { invoke: async (name, body = {}) => {
    if (name === 'phoneLogin') {
      const data = await request('/auth/login', { method: 'POST', auth: false, body: { method: 'phone', identity: body.phone, password: body.password } });
      setToken(data.access_token);
      return { data: { access_token: data.access_token } };
    }
    return { data: await request(`/functions/${encodeURIComponent(name)}`, { method: 'POST', body }) };
  } },
  integrations: { Core: integrations }
};
