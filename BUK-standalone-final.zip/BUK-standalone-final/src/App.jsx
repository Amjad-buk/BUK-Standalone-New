import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import AppShell from '@/components/AppShell';
import SplashGate from '@/components/SplashGate';
import { PrefsProvider } from '@/lib/prefs';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Home from '@/pages/Home';
import Chats from '@/pages/Chats';
import ChatRoom from '@/pages/ChatRoom';
import Friends from '@/pages/Friends';
import Calls from '@/pages/Calls';
import Meeting from '@/pages/Meeting';
import MeetingRoom from '@/pages/MeetingRoom';
import JoinMeeting from '@/pages/JoinMeeting';
import TranslatePage from '@/pages/Translate';
import AiAssistant from '@/pages/AiAssistant';
import Spaces from '@/pages/Spaces';
import Stories from '@/pages/Stories';
import Notes from '@/pages/Notes';
import MyBuki from '@/pages/MyBuki';
import Gift from '@/pages/Gift';
import Live from '@/pages/Live';
import LiveRoom from '@/pages/LiveRoom';
import LiveChannel from '@/pages/LiveChannel';
import Games from '@/pages/Games';
import Settings from '@/pages/Settings';
import Profile from '@/pages/Profile';
import Notifications from '@/pages/Notifications';
import Search from '@/pages/Search';
import Contacts from '@/pages/Contacts';
import Services from '@/pages/Services';
import CallRoom from '@/pages/CallRoom';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required' && !window.location.pathname.startsWith('/join/')) {
      // Redirect to login automatically — رابط دعوة الاجتماع يبقى متاحًا للضيوف بلا حساب
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/join/:code" element={<JoinMeeting />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<AppShell />}>
          <Route path="/" element={<Home />} />
          <Route path="/chats" element={<Chats />} />
          <Route path="/chat/:id" element={<ChatRoom />} />
          <Route path="/friends" element={<Friends />} />
          <Route path="/contacts" element={<Contacts />} />
          <Route path="/calls" element={<Calls />} />
          <Route path="/call/:id" element={<CallRoom />} />
          <Route path="/meeting" element={<Meeting />} />
          <Route path="/meeting/room/:code" element={<MeetingRoom />} />
          <Route path="/translate" element={<TranslatePage />} />
          <Route path="/ai" element={<AiAssistant />} />
          <Route path="/groups" element={<Spaces kind="groups" />} />
          <Route path="/games" element={<Games />} />
          <Route path="/communities" element={<Spaces kind="communities" />} />
          <Route path="/stories" element={<Stories />} />
          <Route path="/notes" element={<Notes />} />
          <Route path="/mypuki" element={<MyBuki />} />
          <Route path="/gift" element={<Gift />} />
          <Route path="/live" element={<Live />} />
          <Route path="/live/channel/:id" element={<LiveChannel />} />
          <Route path="/live/:code" element={<LiveRoom />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/search" element={<Search />} />
          <Route path="/more" element={<Services />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <PrefsProvider>
          <Router>
            <ScrollToTop />
            <SplashGate>
              <AuthenticatedApp />
            </SplashGate>
          </Router>
          <Toaster />
        </PrefsProvider>
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App