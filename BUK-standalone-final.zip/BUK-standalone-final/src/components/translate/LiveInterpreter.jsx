import React, { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { speakAloud } from '@/lib/speech';

const LANGS = [
  ['ar', 'العربية'], ['en', 'الإنجليزية'], ['fr', 'الفرنسية'], ['es', 'الإسبانية'], ['de', 'الألمانية'],
  ['it', 'الإيطالية'], ['pt', 'البرتغالية'], ['ru', 'الروسية'], ['tr', 'التركية'], ['zh-CN', 'الصينية'],
  ['ja', 'اليابانية'], ['ko', 'الكورية'], ['hi', 'الهندية'], ['ur', 'الأوردية'], ['fa', 'الفارسية'],
  ['id', 'الإندونيسية'], ['ms', 'الملايوية'], ['bn', 'البنغالية'], ['sw', 'السواحيلية'], ['nl', 'الهولندية'],
  ['pl', 'البولندية'], ['uk', 'الأوكرانية']
];

const label = (code) => (LANGS.find(([c]) => c === code) || ['', code])[1];

const extension = (type = '') => {
  if (type.includes('mp4')) return 'mp4';
  if (type.includes('ogg')) return 'ogg';
  if (type.includes('wav')) return 'wav';
  if (type.includes('mpeg')) return 'mp3';
  return 'webm';
};

/** مترجم فوري ناطق: كل جهة تحكي بلغتها وتسمع ترجمة كلامها منطوقة بلغة الطرف الآخر. */
export default function LiveInterpreter() {
  const { settings, L } = usePrefs();
  const [source, setSource] = useState('ar');
  const [target, setTarget] = useState('en');
  const [turns, setTurns] = useState([]);
  const [active, setActive] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const recRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    if (window.speechSynthesis) window.speechSynthesis.getVoices();
  }, []);

  useEffect(() => () => {
    if (recRef.current && recRef.current.state === 'recording') recRef.current.stop();
    if (streamRef.current) streamRef.current.getTracks().forEach((track) => track.stop());
  }, []);

  const run = async (side, blob) => {
    const from = side === 'mine' ? source : target;
    const to = side === 'mine' ? target : source;
    setBusy(true);
    setStatus(L('جارٍ فهم الكلام وترجمته…', 'Understanding and translating…'));
    try {
      const file = new File([blob], `buk-live-${Date.now()}.${extension(blob.type)}`, { type: blob.type });
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri });
      const heard = await base44.functions.invoke('bukAssistant', { action: 'transcribe', audio_url: signed_url });
      const text = String((heard && heard.data && heard.data.transcript) || '').trim();
      if (!text) {
        setStatus(L('لم أسمع كلامًا واضحًا، أعد المحاولة.', 'I did not catch clear speech. Try again.'));
        return;
      }
      const translated = await base44.functions.invoke('bukAssistant', { action: 'translate', text, source: from, target: to });
      const out = String((translated && translated.data && translated.data.translation) || '').trim();
      if (!out) {
        setStatus(L('تعذرت الترجمة الآن، أعد المحاولة.', 'Translation failed. Try again.'));
        return;
      }
      setTurns((prev) => [...prev, { id: Date.now(), side, from, to, text, out }]);
      setStatus('');
      const spoken = await speakAloud(out, to, settings.assistant_voice, settings.voice_gender);
      if (!spoken) setStatus(L('ظهرت الترجمة مكتوبة، لكن تعذر تشغيل الصوت على هذا الجهاز.', 'Translation shown, but audio did not play on this device.'));
    } catch {
      setStatus(L('تعذر إتمام الترجمة الصوتية الآن.', 'Could not complete voice translation right now.'));
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (side) => {
    if (active === side) {
      if (recRef.current) recRef.current.stop();
      return;
    }
    if (active || busy) return;
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      setStatus(L('التسجيل غير مدعوم على هذا الجهاز.', 'Recording is not supported on this device.'));
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const recorder = new MediaRecorder(stream);
      const chunks = [];
      recorder.ondataavailable = (event) => { if (event.data && event.data.size) chunks.push(event.data); };
      recorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
        setActive('');
        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if (blob.size) run(side, blob);
        else setStatus(L('لم يتم تسجيل صوت، أعد المحاولة.', 'Nothing was recorded. Try again.'));
      };
      recRef.current = recorder;
      recorder.start();
      setActive(side);
      setStatus('');
    } catch {
      setStatus(L('تعذر الوصول إلى الميكروفون.', 'Could not open the microphone.'));
    }
  };

  const last = turns[turns.length - 1];
  const nextHint = busy || !last
    ? L('اضغط ميكروفونك، احكِ، ثم اضغط الإنهاء — وستسمع الترجمة منطوقة.', 'Tap your mic, speak, then tap to finish — the translation is spoken aloud.')
    : last.side === 'mine'
      ? L('دور الطرف الآخر الآن.', 'The other side is up now.')
      : L('دورك الآن.', 'Your turn now.');

  const micButton = (side, title, toLang) => (
    <button
      type="button"
      className={`buk-btn wide ${active === side ? 'danger' : 'secondary'}`}
      onClick={() => toggle(side)}
      disabled={busy && active !== side}
    >
      <span style={{ display: 'block', fontSize: '0.95rem' }}>{active === side ? '⏹' : '🎙️'} {active === side ? L('إنهاء الكلام', 'Finish speaking') : title}</span>
      <span className="buk-small" style={{ color: 'inherit' }}>→ {label(toLang)}</span>
    </button>
  );

  return (
    <div>
      <div className="buk-card">
        <label className="buk-muted">{L('لغتي أنا', 'My language')}</label>
        <select className="buk-field" value={source} onChange={(event) => setSource(event.target.value)}>
          {LANGS.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
        </select>
        <label className="buk-muted">{L('لغة الشخص الآخر', "The other person's language")}</label>
        <select className="buk-field" value={target} onChange={(event) => setTarget(event.target.value)}>
          {LANGS.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
        </select>
        <button type="button" className="buk-btn secondary wide" style={{ marginTop: 10 }}
          onClick={() => { setSource(target); setTarget(source); }}>
          ⇄ {L('تبديل اللغتين', 'Swap languages')}
        </button>
      </div>

      <div className="buk-card">
        <div className="buk-grid-2">
          {micButton('mine', L('أنا أتحدث', 'I am speaking'), target)}
          {micButton('theirs', L('الطرف الآخر يتحدث', 'The other person speaks'), source)}
        </div>
        <div className="buk-small">{nextHint}</div>
        {status ? <div className="buk-note">{status}</div> : null}
      </div>

      <div className="buk-card">
        <h3 className="buk-title" style={{ fontSize: '1.05rem' }}>📜 {L('سجل المحادثة', 'Conversation log')}</h3>
        {!turns.length ? <p className="buk-muted">{L('كل جملة تُقال تظهر هنا مع ترجمتها المنطوقة.', 'Every spoken sentence appears here with its spoken translation.')}</p> : null}
        {turns.map((turn) => (
          <div key={turn.id} className="buk-note" style={{ borderColor: turn.side === 'mine' ? 'var(--buk-blue)' : 'var(--buk-green)' }}>
            <div className="buk-small">{turn.side === 'mine' ? L('أنا', 'Me') : L('الطرف الآخر', 'Other')} · {label(turn.from)} → {label(turn.to)}</div>
            <div>{turn.text}</div>
            <div style={{ color: 'var(--buk-cyan)' }}>{turn.out}</div>
            <button type="button" className="buk-btn secondary" style={{ marginTop: 8 }}
              onClick={async () => { const ok = await speakAloud(turn.out, turn.to, settings.assistant_voice, settings.voice_gender); if (!ok) setStatus(L('تعذر تشغيل الصوت.', 'Audio could not play.')); }}>
              🔊 {L('اسمع الترجمة', 'Play translation')}
            </button>
          </div>
        ))}
        {turns.length ? (
          <button type="button" className="buk-btn secondary wide" style={{ marginTop: 8 }} onClick={() => setTurns([])}>
            {L('مسح سجل المحادثة', 'Clear conversation log')}
          </button>
        ) : null}
      </div>
    </div>
  );
}