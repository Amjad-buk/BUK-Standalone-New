import React from 'react';
import { Image } from '@/components/ui/image';

export const BUK_LOGO_URL =
  '/buk-logo.svg';

/** شعار BUK الرسمي داخل إطار دائري مضيء. */
export default function BukLogo({ size = 44, className = 'buk-logo-mark', rounded = '14px' }) {
  return (
    <div className={className} style={{ width: size, height: size, borderRadius: rounded }}>
      <Image src={BUK_LOGO_URL} alt="BUK" fittingType="fit" className="w-full h-full" />
    </div>
  );
}