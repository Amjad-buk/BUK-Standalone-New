import React from 'react';
import { formatTime } from '@/lib/chat';
import { usePrefs } from '@/lib/prefs';
import { unlockAudio } from '@/lib/tone';

/** نافذة الرنين: تغطي الشاشة كاملة حتى لا يُفوَّت التذكير على أي صفحة. */
export default function ReminderOverlay({ reminder, onDone, onSnooze, onReplay }) {
  const { L } = usePrefs();
  return (
    <div className="rm-overlay" role="alertdialog" aria-label={reminder.title} onClick={unlockAudio}>
      <div className="rm-card" onClick={(event) => event.stopPropagation()}>
        <div className="rm-ring">⏰</div>
        <h2 className="rm-title">{reminder.title}</h2>
        <p className="rm-time">{formatTime(reminder.at)} · {L('حان الموعد الآن', 'Due now')}</p>
        <div className="rm-actions">
          <button type="button" className="buk-btn wide" onClick={onDone}>
            {L('تم — إيقاف الرنين', 'Done — stop ringing')}
          </button>
          <button type="button" className="buk-btn secondary wide" onClick={onSnooze}>
            {L('ذكّرني بعد ٥ دقائق', 'Remind me in 5 minutes')}
          </button>
          <button type="button" className="buk-btn secondary wide" onClick={onReplay}>
            🔊 {L('إعادة النطق', 'Speak again')}
          </button>
        </div>
        <p className="rm-hint">
          {L(
            'إن لم تسمع الصوت اضغط «إعادة النطق» — قد يكون الجهاز على الوضع الصامت.',
            'If you hear nothing, tap “Speak again” — the device may be on silent.'
          )}
        </p>
      </div>
    </div>
  );
}