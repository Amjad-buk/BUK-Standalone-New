import React, { useEffect, useMemo, useState } from 'react';
import { allMoves, applyMove, bestMove, initialBoard, isInCheck, pieceColor, statusOf } from '@/lib/chess';
import { usePrefs } from '@/lib/prefs';
import ChessBoard from '@/components/games/chess/ChessBoard';
import ChessPlayer from '@/components/games/chess/ChessPlayer';

const START_COUNTS = { p: 8, n: 2, b: 2, r: 2, q: 1 };
const TYPE_GLYPH = { p: '♟', n: '♞', b: '♝', r: '♜', q: '♛' };
const FILES = 'abcdefgh';

const missingPieces = (board, color) => {
  const counts = {};
  board.forEach((piece) => {
    if (!piece || pieceColor(piece) !== color) return;
    const type = piece.toLowerCase();
    counts[type] = (counts[type] || 0) + 1;
  });
  const out = [];
  Object.entries(START_COUNTS).forEach(([type, total]) => {
    const missing = total - (counts[type] || 0);
    for (let i = 0; i < missing; i++) out.push(TYPE_GLYPH[type]);
  });
  return out;
};

const notation = (board, move) => {
  const to = `${FILES[move.to % 8]}${8 - Math.floor(move.to / 8)}`;
  const type = move.piece.toLowerCase();
  return `${type === 'p' ? '' : TYPE_GLYPH[type]}${board[move.to] ? '×' : ''}${to}`;
};

/** شطرنج ضد الذكاء الاصطناعي بواجهة احترافية: أنت الأبيض في الأسفل. */
export default function ChessGame() {
  const { L } = usePrefs();
  const [board, setBoard] = useState(initialBoard);
  const [turn, setTurn] = useState('w');
  const [selected, setSelected] = useState(-1);
  const [moves, setMoves] = useState([]);
  const [lastMove, setLastMove] = useState(null);
  const [note, setNote] = useState('');
  const [result, setResult] = useState('');
  const [thinking, setThinking] = useState(false);

  const checkSquare = useMemo(() => {
    if (!isInCheck(board, turn)) return -1;
    return board.indexOf(turn === 'w' ? 'K' : 'k');
  }, [board, turn]);

  useEffect(() => {
    if (turn !== 'b' || result) return undefined;
    setThinking(true);
    const timer = setTimeout(() => {
      const move = bestMove(board, 'b', { depth: 4, timeMs: 800 });
      if (!move) {
        setThinking(false);
        return;
      }
      const next = applyMove(board, move);
      setBoard(next);
      setLastMove(move);
      setNote(notation(board, move));
      setSelected(-1);
      setMoves([]);
      const status = statusOf(next, 'w');
      if (status === 'checkmate') setResult('lose');
      else if (status === 'stalemate') setResult('draw');
      else setTurn('w');
      setThinking(false);
    }, 90);
    return () => clearTimeout(timer);
  }, [turn, board, result]);

  const click = (index) => {
    if (turn !== 'w' || result || thinking) return;
    const piece = board[index];

    if (selected >= 0) {
      const move = moves.find((candidate) => candidate.to === index);
      if (move) {
        const next = applyMove(board, move);
        setBoard(next);
        setLastMove(move);
        setNote(notation(board, move));
        setSelected(-1);
        setMoves([]);
        const status = statusOf(next, 'b');
        if (status === 'checkmate') {
          setResult('win');
          return;
        }
        if (status === 'stalemate') {
          setResult('draw');
          return;
        }
        setTurn('b');
        return;
      }
    }

    if (piece && pieceColor(piece) === 'w') {
      setSelected(index);
      setMoves(allMoves(board, 'w').filter((move) => move.from === index));
      return;
    }
    setSelected(-1);
    setMoves([]);
  };

  const reset = () => {
    setBoard(initialBoard());
    setTurn('w');
    setSelected(-1);
    setMoves([]);
    setLastMove(null);
    setNote('');
    setResult('');
    setThinking(false);
  };

  return (
    <div className="ch-suite">
      <ChessPlayer
        name="BUK AI"
        side="b"
        active={turn === 'b' && !result}
        captured={missingPieces(board, 'w')}
        thinking={thinking}
      />

      <div className="ch-board-wrap">
        <ChessBoard
          board={board}
          selected={selected}
          moves={moves}
          lastMove={lastMove}
          checkSquare={checkSquare}
          onSquare={click}
        />
        {result ? (
          <div className="ch-overlay">
            <span className="ch-overlay-icon">{result === 'win' ? '🏆' : result === 'draw' ? '🤝' : '🤖'}</span>
            <b>
              {result === 'win'
                ? L('فزت باللعبة!', 'You won!')
                : result === 'draw'
                  ? L('تعادل', 'Draw')
                  : L('فاز الحاسوب', 'AI wins')}
            </b>
            <button type="button" className="buk-btn" onClick={reset}>{L('لعبة جديدة', 'Play again')}</button>
          </div>
        ) : null}
      </div>

      <div className="ch-note">
        <span>
          {thinking
            ? L('الحاسوب يفكر…', 'AI is thinking…')
            : L('دورك — أنت الأبيض', 'Your turn — you play white')}
        </span>
        {note ? <span className="ch-note-move">{L('آخر نقلة', 'Last move')}: {note}</span> : null}
      </div>

      <ChessPlayer
        name={L('أنت', 'You')}
        side="w"
        active={turn === 'w' && !result}
        captured={missingPieces(board, 'b')}
      />

      {!result ? (
        <button type="button" className="buk-btn secondary wide" onClick={reset}>
          {L('لعبة جديدة', 'New game')}
        </button>
      ) : null}
    </div>
  );
}