import React, { useEffect, useState } from 'react';
import { usePrefs } from '@/lib/prefs';

const SIZE = 14;
const START = [{ x: 7, y: 7 }, { x: 6, y: 7 }, { x: 5, y: 7 }];

export default function SnakeGame() {
  const { L } = usePrefs();
  const [snake, setSnake] = useState(START);
  const [food, setFood] = useState({ x: 10, y: 7 });
  const [dir, setDir] = useState({ x: 1, y: 0 });
  const [over, setOver] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (over) return undefined;
    const timer = setInterval(() => {
      setSnake((prev) => {
        const head = { x: prev[0].x + dir.x, y: prev[0].y + dir.y };
        if (head.x < 0 || head.x >= SIZE || head.y < 0 || head.y >= SIZE) {
          setOver(true);
          return prev;
        }
        if (prev.some((cell) => cell.x === head.x && cell.y === head.y)) {
          setOver(true);
          return prev;
        }
        const eats = head.x === food.x && head.y === food.y;
        const next = [head, ...prev.slice(0, eats ? prev.length : prev.length - 1)];
        if (eats) {
          setScore((value) => value + 1);
          let spot = food;
          while (next.some((cell) => cell.x === spot.x && cell.y === spot.y)) {
            spot = { x: Math.floor(Math.random() * SIZE), y: Math.floor(Math.random() * SIZE) };
          }
          setFood(spot);
        }
        return next;
      });
    }, 220);
    return () => clearInterval(timer);
  }, [dir, food, over]);

  const turn = (x, y) => setDir((current) => (current.x === -x && current.y === -y ? current : { x, y }));

  const reset = () => {
    setSnake(START);
    setDir({ x: 1, y: 0 });
    setFood({ x: 10, y: 7 });
    setScore(0);
    setOver(false);
  };

  const cells = [];
  for (let row = 0; row < SIZE; row++) {
    for (let col = 0; col < SIZE; col++) {
      const head = snake[0];
      const isHead = head.x === col && head.y === row;
      const isBody = snake.some((cell) => cell.x === col && cell.y === row);
      const isFood = food.x === col && food.y === row;
      cells.push(
        <div
          key={`${row}-${col}`}
          className={`snake-cell${isBody ? ' body' : ''}${isHead ? ' head' : ''}${isFood ? ' food' : ''}`}
        />
      );
    }
  }

  return (
    <div>
      <div className="gm-status">
        <b>{over ? L('انتهت اللعبة', 'Game over') : L('جمع النقاط دون أن تصطدم بجسمك', 'Eat without hitting yourself')}</b>
        <span className="gm-check">{L('النقاط', 'Score')}: {score}</span>
      </div>

      <div className="snake-grid" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)` }}>
        {cells}
      </div>

      <div className="g2048-pad">
        <button type="button" className="g2048-key" onClick={() => turn(0, -1)} aria-label="up">▲</button>
        <div>
          <button type="button" className="g2048-key" onClick={() => turn(-1, 0)} aria-label="left">◀</button>
          <button type="button" className="g2048-key" onClick={() => turn(0, 1)} aria-label="down">▼</button>
          <button type="button" className="g2048-key" onClick={() => turn(1, 0)} aria-label="right">▶</button>
        </div>
      </div>

      <button type="button" className="buk-btn wide" style={{ marginTop: 12 }} onClick={reset}>
        {L('لعبة جديدة', 'New game')}
      </button>
    </div>
  );
}