import React, { useState } from 'react';
import { usePrefs } from '@/lib/prefs';

const TILE_COLORS = {
  0: '#0b2b54', 2: '#1f6fb2', 4: '#2b8fd8', 8: '#3aa9a0', 16: '#49c07a',
  32: '#8ac24a', 64: '#d6b23c', 128: '#e08a3c', 256: '#e06a3c', 512: '#e04f4f',
  1024: '#c33f7f', 2048: '#8a4fd8'
};

const spawn = (grid) => {
  const empty = grid.map((value, index) => (value ? null : index)).filter((index) => index !== null);
  if (!empty.length) return grid;
  const spot = empty[Math.floor(Math.random() * empty.length)];
  const next = grid.slice();
  next[spot] = Math.random() < 0.9 ? 2 : 4;
  return next;
};

const slideRow = (values) => {
  const items = values.filter(Boolean);
  const out = [];
  let gained = 0;
  for (let i = 0; i < items.length; i++) {
    if (items[i] === items[i + 1]) {
      out.push(items[i] * 2);
      gained += items[i] * 2;
      i++;
    } else {
      out.push(items[i]);
    }
  }
  while (out.length < 4) out.push(0);
  return { out, gained };
};

const canMove = (grid) => {
  if (grid.includes(0)) return true;
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      const value = grid[r * 4 + c];
      if (c < 3 && value === grid[r * 4 + c + 1]) return true;
      if (r < 3 && value === grid[(r + 1) * 4 + c]) return true;
    }
  }
  return false;
};

const freshGrid = () => spawn(spawn(Array(16).fill(0)));

export default function Game2048() {
  const { L } = usePrefs();
  const [grid, setGrid] = useState(freshGrid);
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);

  const move = (dir) => {
    if (over) return;
    const next = grid.slice();
    let gained = 0;
    let changed = false;

    for (let line = 0; line < 4; line++) {
      const cells = [0, 1, 2, 3].map((step) =>
        dir === 'left' || dir === 'right' ? grid[line * 4 + step] : grid[step * 4 + line]
      );
      const reversed = dir === 'right' || dir === 'down';
      const ordered = reversed ? cells.slice().reverse() : cells;
      const { out, gained: lineGain } = slideRow(ordered);
      const final = reversed ? out.slice().reverse() : out;
      gained += lineGain;
      final.forEach((value, step) => {
        const index = dir === 'left' || dir === 'right' ? line * 4 + step : step * 4 + line;
        if (next[index] !== value) changed = true;
        next[index] = value;
      });
    }

    if (!changed) return;
    const withNew = spawn(next);
    setGrid(withNew);
    setScore((value) => value + gained);
    if (!canMove(withNew)) setOver(true);
  };

  const reset = () => {
    setGrid(freshGrid());
    setScore(0);
    setOver(false);
  };

  return (
    <div>
      <div className="gm-status">
        <b>{over ? L('انتهت اللعبة — جرّب مرة أخرى', 'Game over — try again') : L('اجمع البلاطات للوصول إلى 2048', 'Merge tiles to reach 2048')}</b>
        <span className="gm-check">{L('النقاط', 'Score')}: {score}</span>
      </div>

      <div className="g2048-grid">
        {grid.map((value, index) => (
          <div
            key={index}
            className={`g2048-tile v-${value > 2048 ? 'big' : value}`}
            style={{ background: TILE_COLORS[value] || TILE_COLORS[2048], color: value > 4 ? '#fff' : '#eaf6ff' }}
          >
            {value || ''}
          </div>
        ))}
      </div>

      <div className="g2048-pad">
        <button type="button" className="g2048-key" onClick={() => move('up')} aria-label="up">▲</button>
        <div>
          <button type="button" className="g2048-key" onClick={() => move('left')} aria-label="left">◀</button>
          <button type="button" className="g2048-key" onClick={() => move('down')} aria-label="down">▼</button>
          <button type="button" className="g2048-key" onClick={() => move('right')} aria-label="right">▶</button>
        </div>
      </div>

      <button type="button" className="buk-btn wide" style={{ marginTop: 12 }} onClick={reset}>
        {L('لعبة جديدة', 'New game')}
      </button>
    </div>
  );
}