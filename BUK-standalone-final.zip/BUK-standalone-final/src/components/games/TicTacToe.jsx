import React, { useState } from 'react';
import { usePrefs } from '@/lib/prefs';

const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];

const winnerOf = (cells) => {
  for (const [a, b, c] of LINES) {
    if (cells[a] && cells[a] === cells[b] && cells[a] === cells[c]) return cells[a];
  }
  return cells.includes(null) ? null : 'draw';
};

const bestFor = (cells, player) => {
  const result = winnerOf(cells);
  if (result === 'O') return { score: 1 };
  if (result === 'X') return { score: -1 };
  if (result === 'draw') return { score: 0 };

  let best = { score: player === 'O' ? -2 : 2 };
  cells.forEach((cell, index) => {
    if (cell) return;
    const next = cells.slice();
    next[index] = player;
    const { score } = bestFor(next, player === 'O' ? 'X' : 'O');
    if (player === 'O' ? score > best.score : score < best.score) best = { score, index };
  });
  return best;
};

export default function TicTacToe() {
  const { L } = usePrefs();
  const [cells, setCells] = useState(Array(9).fill(null));
  const [status, setStatus] = useState('');

  const result = winnerOf(cells);

  const play = (index) => {
    if (cells[index] || result) return;
    const next = cells.slice();
    next[index] = 'X';
    setCells(next);
    if (winnerOf(next)) return;
    const ai = bestFor(next, 'O');
    const after = next.slice();
    after[ai.index] = 'O';
    setTimeout(() => setCells(after), 260);
  };

  const reset = () => {
    setCells(Array(9).fill(null));
    setStatus('');
  };

  const label = result === 'X'
    ? L('فزت! 🎉', 'You win! 🎉')
    : result === 'O'
      ? L('فاز الحاسوب.', 'Computer wins.')
      : result === 'draw'
        ? L('تعادل.', 'Draw.')
        : L('دورك — أنت X', 'Your turn — you are X');

  return (
    <div>
      <div className="gm-status"><b>{label}</b>{status ? <span className="gm-check">{status}</span> : null}</div>
      <div className="ttt-grid">
        {cells.map((cell, index) => (
          <button key={index} type="button" className={`ttt-cell ${cell ? 'taken' : ''}`} onClick={() => play(index)}>
            {cell || ''}
          </button>
        ))}
      </div>
      <button type="button" className="buk-btn wide" style={{ marginTop: 12 }} onClick={reset}>
        {L('لعبة جديدة', 'New game')}
      </button>
    </div>
  );
}