import React, { useState } from 'react';
import { usePrefs } from '@/lib/prefs';

const ICONS = ['🍎', '🚀', '🐱', '⚽', '🎧', '🌙', '🍩', '🐳'];

const makeDeck = () =>
  [...ICONS, ...ICONS]
    .map((icon, index) => ({ id: index, icon }))
    .sort(() => Math.random() - 0.5);

export default function MemoryGame() {
  const { L } = usePrefs();
  const [deck, setDeck] = useState(makeDeck);
  const [open, setOpen] = useState([]);
  const [done, setDone] = useState([]);
  const [tries, setTries] = useState(0);

  const finished = done.length === deck.length;

  const flip = (index) => {
    if (open.length === 2 || open.includes(index) || done.includes(index)) return;
    const next = [...open, index];
    setOpen(next);
    if (next.length < 2) return;
    setTries((value) => value + 1);
    const [a, b] = next;
    if (deck[a].icon === deck[b].icon) {
      setTimeout(() => {
        setDone((prev) => [...prev, ...next]);
        setOpen([]);
      }, 380);
    } else {
      setTimeout(() => setOpen([]), 760);
    }
  };

  const reset = () => {
    setDeck(makeDeck());
    setOpen([]);
    setDone([]);
    setTries(0);
  };

  return (
    <div>
      <div className="gm-status">
        <b>
          {finished
            ? L(`أكملت اللعبة في ${tries} محاولة 🎉`, `Solved in ${tries} tries 🎉`)
            : L('اعثر على كل الأزواج المتشابهة', 'Match every pair')}
        </b>
        <span className="gm-check">{L('المحاولات', 'Tries')}: {tries}</span>
      </div>

      <div className="mem-grid">
        {deck.map((card, index) => {
          const shown = open.includes(index) || done.includes(index);
          return (
            <button
              key={card.id}
              type="button"
              className={`mem-card${shown ? ' shown' : ''}${done.includes(index) ? ' done' : ''}`}
              onClick={() => flip(index)}
            >
              {shown ? card.icon : ''}
            </button>
          );
        })}
      </div>

      <button type="button" className="buk-btn wide" style={{ marginTop: 12 }} onClick={reset}>
        {L('لعبة جديدة', 'New game')}
      </button>
    </div>
  );
}