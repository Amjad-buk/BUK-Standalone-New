import React from 'react';
import { pieceColor, pieceGlyph } from '@/lib/chess';

const FILES = 'abcdefgh';

/** رقعة الشطرنج: إحداثيات، تظليل النقلة الأخيرة، الكش، والنقلات المتاحة. */
export default function ChessBoard({ board, selected, moves, lastMove, checkSquare, onSquare }) {
  return (
    <div className="ch-frame">
      <div className="ch-grid">
        {board.map((piece, index) => {
          const row = Math.floor(index / 8);
          const col = index % 8;
          const classes = ['ch-sq', (row + col) % 2 === 0 ? 'light' : 'dark'];
          if (selected === index) classes.push('sel');
          if (lastMove && (lastMove.from === index || lastMove.to === index)) classes.push('last');
          if (checkSquare === index) classes.push('check');
          const isTarget = moves.some((move) => move.to === index);
          return (
            <button
              key={index}
              type="button"
              className={classes.join(' ')}
              onClick={() => onSquare(index)}
              aria-label={`${FILES[col]}${8 - row}`}
            >
              {row === 7 ? <i className="ch-file">{FILES[col]}</i> : null}
              {col === 0 ? <i className="ch-rank">{8 - row}</i> : null}
              {piece ? (
                <span className={`ch-pc ${pieceColor(piece) === 'w' ? 'w' : 'b'}`}>{pieceGlyph[piece]}</span>
              ) : null}
              {isTarget ? <i className={piece ? 'ch-cap' : 'ch-dot'} /> : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}