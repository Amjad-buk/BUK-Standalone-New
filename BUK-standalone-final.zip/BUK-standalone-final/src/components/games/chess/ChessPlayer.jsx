import React from 'react';
import { usePrefs } from '@/lib/prefs';

/** بطاقة لاعب: الطرف، القطع المأسورة، ودور اللعب أو مؤشر تفكير الحاسوب. */
export default function ChessPlayer({ name, side, active, captured, thinking }) {
  const { L } = usePrefs();
  return (
    <div className={`ch-player${active ? ' active' : ''}`}>
      <div className={`ch-token ${side}`}>{side === 'w' ? '♔' : '♚'}</div>
      <div className="ch-player-text">
        <b>{name}</b>
        <span>{captured.length ? captured.join(' ') : L('لا قطع مأسورة', 'No captures')}</span>
      </div>
      {thinking ? (
        <span className="ch-thinking"><i /><i /><i /></span>
      ) : active ? (
        <span className="ch-turn">{L('دور', 'Turn')}</span>
      ) : null}
    </div>
  );
}