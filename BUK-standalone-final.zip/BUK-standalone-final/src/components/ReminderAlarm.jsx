import React from 'react';
import useReminderAlerts from '@/hooks/useReminderAlerts';
import ReminderOverlay from '@/components/ReminderOverlay';

/** يرنّ التذكيرات المستحقة في كل صفحات التطبيق. */
export default function ReminderAlarm() {
  const { due, snooze, complete, replay } = useReminderAlerts();
  if (!due) return null;
  return <ReminderOverlay reminder={due} onDone={complete} onSnooze={snooze} onReplay={replay} />;
}