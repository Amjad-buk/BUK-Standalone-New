import React, { useState } from 'react';
import MediaAttachment from '@/components/chat/MediaAttachment';
import { STATUS, formatTime, statusOf } from '@/lib/chat';

const EMOJI = ['👍', '❤️', '😂', '🎉', '🔥', '🙏', '😍', '😮'];

export default function MessageBubble({ message, myId, onReply, onCopy, onDeleteForMe, onDeleteForAll }) {
  const [open, setOpen] = useState(false);
  const [emoji, setEmoji] = useState([]);
  const mine = message.sender_id === myId;
  const status = statusOf(message, myId);
  const canDeleteAll = Date.now() - new Date(message.created_date).getTime() < 20000;

  const body = () => {
    if (message.deleted_for_all) return <i className="buk-muted">تم حذف هذه الرسالة</i>;
    if (message.kind !== 'text') return <MediaAttachment message={message} />;
    return <span className="buk-safe-scroll">{message.text}</span>;
  };

  return (
    <div className={`buk-bubble ${mine ? 'mine' : 'theirs'}`}>
      {message.reply_preview ? (
        <div className="buk-small mb-1" style={{ opacity: 0.85 }}>
          ↩︎ {message.reply_preview}
        </div>
      ) : null}
      {body()}
      {emoji.length ? <div style={{ fontSize: '1.1rem' }}>{emoji.join(' ')}</div> : null}
      <div className="flex items-center gap-2 mt-1" style={{ fontSize: '0.68rem', opacity: 0.85 }}>
        <span>{formatTime(message.created_date)}</span>
        {status ? <span className={`buk-dot ${STATUS[status].cls}`} title={STATUS[status].label} /> : null}
        {!message.deleted_for_all ? (
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label="أدوات الرسالة"
            style={{ background: 'none', border: 0, color: 'inherit', cursor: 'pointer', marginInlineStart: 'auto' }}
          >
            ⋯
          </button>
        ) : null}
      </div>

      {open ? (
        <div className="buk-note" style={{ marginBottom: 0 }}>
          <div className="flex flex-wrap gap-3" style={{ fontSize: '0.75rem' }}>
            <button type="button" className="buk-btn secondary" onClick={() => { onReply(message); setOpen(false); }}>رد</button>
            <button type="button" className="buk-btn secondary" onClick={() => { onCopy(message); setOpen(false); }}>نسخ</button>
            <button type="button" className="buk-btn secondary" onClick={() => { onDeleteForMe(message); setOpen(false); }}>حذف لدي</button>
            {mine && canDeleteAll ? (
              <button type="button" className="buk-btn danger" onClick={() => { onDeleteForAll(message); setOpen(false); }}>
                حذف للجميع
              </button>
            ) : null}
          </div>
          <div className="flex flex-wrap gap-1 mt-2">
            {EMOJI.map((e) => (
              <button
                key={e}
                type="button"
                onClick={() => { setEmoji((p) => [...p, e]); setOpen(false); }}
                style={{ background: 'none', border: 0, fontSize: '1.1rem', cursor: 'pointer' }}
              >
                {e}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}