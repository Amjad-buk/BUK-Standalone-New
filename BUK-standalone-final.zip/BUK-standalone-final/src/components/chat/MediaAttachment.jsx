import React, { useEffect, useState } from 'react';
import { Image } from '@/components/ui/image';
import { isPrivateMedia, resolveMediaUrl } from '@/lib/chat';

/** يعرض مرفق الرسالة، ويحوّل المرفقات الخاصة إلى روابط موقّتة قبل العرض. */
export default function MediaAttachment({ message }) {
  const raw = message.media_url || '';
  const [url, setUrl] = useState(() => (isPrivateMedia(raw) ? '' : raw));

  useEffect(() => {
    if (!isPrivateMedia(raw)) {
      setUrl(raw);
      return undefined;
    }
    let alive = true;
    setUrl('');
    resolveMediaUrl(raw)
      .then((value) => { if (alive) setUrl(value); })
      .catch(() => {});
    return () => { alive = false; };
  }, [raw]);

  if (!url) return <span className="buk-muted">…</span>;
  if (message.kind === 'image') {
    return <Image src={url} alt="" className="rounded-xl max-h-72 w-full object-cover" fittingType="fill" />;
  }
  if (message.kind === 'video') return <video src={url} controls className="rounded-xl max-h-72 w-full" />;
  if (message.kind === 'voice') return <audio src={url} controls className="w-full" />;
  return (
    <a href={url} target="_blank" rel="noreferrer" className="underline">
      📎 {message.media_name || 'ملف مرفق'}
    </a>
  );
}