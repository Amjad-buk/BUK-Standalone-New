import React from 'react';
import { conversationIcon, conversationTitle, formatTime } from '@/lib/chat';
import { Image } from '@/components/ui/image';

/** صف محادثة بشكل واتساب: صورة دائرية، الاسم، آخر رسالة، الوقت وشارة غير المقروء. */
export default function ChatListItem({ conversation, myId, unread, onOpen }) {
  const muted = (conversation.muted_ids || []).includes(myId);

  return (
    <button type="button" className="wa-row" onClick={onOpen}>
      <div className="wa-avatar">
        {conversation.photo_url
          ? <Image src={conversation.photo_url} alt="" fittingType="fill" className="w-full h-full" />
          : conversationIcon(conversation)}
      </div>

      <div className="wa-body">
        <div className="wa-name">{conversationTitle(conversation, myId)}</div>
        <div className="wa-preview">{conversation.last_message_text || 'لا رسائل بعد'}</div>
      </div>

      <div className="wa-meta">
        <span className={unread ? 'wa-time unread' : 'wa-time'}>{formatTime(conversation.last_message_at)}</span>
        {unread ? <span className="wa-badge">{unread > 99 ? '99+' : unread}</span> : null}
        {!unread && muted ? <span className="wa-mute">🔇</span> : null}
      </div>
    </button>
  );
}