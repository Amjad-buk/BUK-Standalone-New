import React, { useRef, useState } from 'react';
import { previewOf, sendMessage, uploadChatFile } from '@/lib/chat';

const EMOJI = ['😀', '😂', '❤️', '👍', '🙏', '🔥', '🎉', '😍', '😢', '🤝', '✅', '⏰'];

export default function Composer({ conversation, me, replyTo, onClearReply, onSent }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  const [recording, setRecording] = useState(false);
  const fileRef = useRef(null);
  const recRef = useRef(null);

  const submit = async (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value || busy) return;
    setBusy(true);
    try {
      const sent = await sendMessage({ conversation, me, kind: 'text', text: value, replyTo });
      setText('');
      onClearReply();
      onSent(sent);
    } finally {
      setBusy(false);
    }
  };

  const onPickFile = async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = '';
    if (!file) return;
    setBusy(true);
    try {
      const url = await uploadChatFile(file);
      const kind = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'file';
      const sent = await sendMessage({ conversation, me, kind, text: '', mediaUrl: url, mediaName: file.name, replyTo });
      onClearReply();
      onSent(sent);
    } finally {
      setBusy(false);
    }
  };

  const toggleRecording = async () => {
    if (recording) {
      recRef.current && recRef.current.stop();
      return;
    }
    if (!navigator.mediaDevices || !window.MediaRecorder) return;
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    const chunks = [];
    const startedAt = Date.now();
    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      setRecording(false);
      const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
      setBusy(true);
      try {
        const file = new File([blob], `buk-voice-${Date.now()}.webm`, { type: blob.type });
        const url = await uploadChatFile(file);
        const sent = await sendMessage({
          conversation, me, kind: 'voice', text: '',
          mediaUrl: url, mediaName: file.name,
          duration: Math.max(1, Math.round((Date.now() - startedAt) / 1000)), replyTo
        });
        onClearReply();
        onSent(sent);
      } finally {
        setBusy(false);
      }
    };
    recRef.current = recorder;
    recorder.start();
    setRecording(true);
  };

  return (
    <div>
      {replyTo ? (
        <div className="buk-note flex items-center justify-between gap-2">
          <span className="buk-muted">↩︎ {previewOf(replyTo).slice(0, 80)}</span>
          <button type="button" className="buk-btn secondary" onClick={onClearReply}>إلغاء</button>
        </div>
      ) : null}
      {showEmoji ? (
        <div className="buk-note flex flex-wrap gap-2">
          {EMOJI.map((e) => (
            <button key={e} type="button" onClick={() => setText((t) => t + e)} style={{ background: 'none', border: 0, fontSize: '1.2rem', cursor: 'pointer' }}>
              {e}
            </button>
          ))}
        </div>
      ) : null}
      <form className="buk-composer" onSubmit={submit}>
        <button type="button" className="buk-btn secondary" onClick={() => fileRef.current && fileRef.current.click()} aria-label="إرفاق">📎</button>
        <button type="button" className="buk-btn secondary" onClick={() => setShowEmoji((v) => !v)} aria-label="رموز تعبيرية">😊</button>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={recording ? 'جارٍ التسجيل… اضغط الميكروفون للإيقاف' : 'اكتب رسالة...'}
          autoComplete="off"
        />
        <button type="button" className={`buk-btn ${recording ? 'danger' : 'secondary'}`} onClick={toggleRecording} aria-label="رسالة صوتية">
          {recording ? '⏹' : '🎙️'}
        </button>
        <button className="buk-btn" disabled={busy}>{busy ? '…' : 'إرسال'}</button>
      </form>
      <input ref={fileRef} type="file" accept="image/*,video/*,.pdf,.doc,.docx,.txt" hidden onChange={onPickFile} />
      <p className="buk-small">
        المرفقات (للصور والفيديو والملفات والرسائل الصوتية) تُرفع بشكل خاص (stored privately) وتُعرض عبر روابط موقّتة داخل المحادثة.
      </p>
    </div>
  );
}