import React from "react";
import { Image } from "@/components/ui/image";
import { BUK_LOGO_URL } from "@/components/BukLogo";

/** إطار شاشات الدخول بتصميم BUK: الشعار الرسمي ثم العنوان ثم المحتوى. */
export default function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div
      className="min-h-screen flex items-center justify-center p-3"
      style={{ background: "var(--buk-page-bg)", backgroundAttachment: "fixed" }}
    >
      <div
        className="w-full max-w-[440px] buk-card text-center"
        style={{ padding: "25px 22px", borderRadius: 28, margin: 0 }}
      >
        <div
          className="buk-logo-mark"
          style={{
            width: 180,
            height: 76,
            borderRadius: 12,
            margin: "4px auto 18px",
            background: "transparent",
            boxShadow: "none",
          }}
        >
          <Image src={BUK_LOGO_URL} alt="شعار BUK الرسمي" fittingType="fit" className="w-full h-full" />
        </div>

        <h1 style={{ fontSize: "1.75rem", margin: "8px 0" }}>{title}</h1>
        {subtitle ? <p className="buk-muted" style={{ margin: "8px 0 20px" }}>{subtitle}</p> : null}

        <div className="text-start">{children}</div>

        {footer ? <p className="buk-muted" style={{ marginTop: 18 }}>{footer}</p> : null}
      </div>
    </div>
  );
}