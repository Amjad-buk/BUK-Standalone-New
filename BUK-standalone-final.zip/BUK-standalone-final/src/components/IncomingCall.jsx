import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';

/** شاشة الرنين الواردة: تظهر فوق التطبيق كله عند وصول مكالمة جديدة. */
export default function IncomingCall() {
  const { user, L } = usePrefs();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [call, setCall] = useState(null);

  useEffect(() => {
    if (!user) return undefined;
    let alive = true;

    const check = async () => {
      const page = await base44.entities.Call
        .filter({ callee_id: user.id, status: 'ringing' }, { sort: '-created_date', limit: 1 })
        .catch(() => null);
      if (!alive) return;
      const record = page && page.items && page.items[0];
      if (!record) { setCall(null); return; }
      const age = Date.now() - new Date(record.created_date).getTime();
      setCall(age < 120000 ? record : null);
    };

    check();
    const unsubscribe = base44.entities.Call.subscribe(() => check());
    const poller = setInterval(check, 5000);
    return () => { alive = false; unsubscribe(); clearInterval(poller); };
  }, [user]);

  if (!call || pathname.startsWith('/call/')) return null;

  const accept = async () => {
    await base44.entities.Call.update(call.id, { status: 'accepted' }).catch(() => {});
    navigate(`/call/${call.id}`);
  };

  const decline = async () => {
    await base44.entities.Call.update(call.id, { status: 'declined' }).catch(() => {});
    setCall(null);
  };

  return (
    <div className="buk-incoming">
      <div className="buk-avatar round">📞</div>
      <div className="buk-grow">
        <b>{call.caller_name || 'BUK'}</b>
        <div className="buk-small">
          {call.mode === 'video' ? L('مكالمة فيديو واردة', 'Incoming video call') : L('مكالمة صوتية واردة', 'Incoming voice call')}
        </div>
      </div>
      <button type="button" className="buk-btn" onClick={accept}>{L('قبول', 'Accept')}</button>
      <button type="button" className="buk-btn danger" onClick={decline}>{L('رفض', 'Decline')}</button>
    </div>
  );
}