import React from 'react';

/** صف جهة اتصال: من على BUK يُفتح معه محادثة، ومن ليس عليه تُرسل له دعوة SMS. */
export default function ContactRow({ row, L, busy, onInvite, onChat }) {
  const label = row.name || row.display_name || row.phone;
  return (
    <div className="buk-row">
      <div className="buk-avatar round">{row.on_buk ? '💬' : '📇'}</div>
      <div className="buk-grow">
        <b>{label}</b>
        <div className="buk-small">
          {row.on_buk ? `على BUK · ${row.display_name || ''}` : row.invited ? 'أُرسلت له دعوة' : 'ليس على BUK'}
        </div>
      </div>
      {row.on_buk ? (
        <button type="button" className="buk-btn" onClick={() => onChat(row)}>{L('محادثة', 'Chat')}</button>
      ) : (
        <button
          type="button"
          className="buk-btn"
          disabled={busy || row.invited}
          onClick={() => onInvite(row)}
        >
          {row.invited ? L('أُرسلت', 'Sent') : busy ? '…' : L('دعوة SMS', 'SMS invite')}
        </button>
      )}
    </div>
  );
}