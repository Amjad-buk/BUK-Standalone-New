import React, { useState } from 'react';

/** إضافة رقم يدويًا لمن لا يستطيع الجهاز مشاركة دليل جهات الاتصال. */
export default function ManualInvite({ L, busy, onSend }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const submit = () => {
    if (!phone.trim()) return;
    onSend(name.trim(), phone.trim());
    setName('');
    setPhone('');
  };

  return (
    <div className="buk-card">
      <b>{L('إضافة رقم يدويًا', 'Add a number manually')}</b>
      <p className="buk-muted">{L('اكتب رقم من تريد دعوته إن لم يظهر في جهات الاتصال.', 'Type a number to invite if it is not in your contacts.')}</p>
      <div style={{ display: 'grid', gap: 8, marginTop: 10 }}>
        <input className="buk-field" value={name} onChange={(e) => setName(e.target.value)}
          placeholder={L('الاسم (اختياري)', 'Name (optional)')} />
        <input className="buk-field" value={phone} onChange={(e) => setPhone(e.target.value)}
          placeholder="+962 79 000 0000" inputMode="tel" />
        <button type="button" className="buk-btn wide" disabled={busy || !phone.trim()} onClick={submit}>
          {busy ? '…' : L('إرسال دعوة SMS باسم BUK', 'Send SMS invite as BUK')}
        </button>
      </div>
    </div>
  );
}