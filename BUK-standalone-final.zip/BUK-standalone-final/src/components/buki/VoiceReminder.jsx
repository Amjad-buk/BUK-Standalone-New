import React, { useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { formatTime } from '@/lib/chat';
import { announce } from '@/lib/speech';

/** تذكير بالنطق: تتكلم فيُفهم تذكيرك ويُسجَّل في وقته. */
export default function VoiceReminder({ onCreated }) {
  const { user, settings, L } = usePrefs();
  const [recording, setRecording] = useState(false);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState('');
  const [heard, setHeard] = useState('');
  const recRef = useRef(null);

  const toggle = async () => {
    if (recording) {
      if (recRef.current) recRef.current.stop();
      return;
    }
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      setNote(L('التسجيل غير مدعوم على هذا الجهاز.', 'Recording is not supported on this device.'));
      return;
    }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    const chunks = [];
    recorder.ondataavailable = (event) => chunks.push(event.data);
    recorder.onstop = async () => {
      stream.getTracks().forEach((track) => track.stop());
      setRecording(false);
      setBusy(true);
      setHeard('');
      setNote(L('جارٍ فهم تذكيرك…', 'Understanding your reminder…'));
      try {
        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        const file = new File([blob], `buk-reminder-${Date.now()}.webm`, { type: blob.type });
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri });
        const heardResponse = await base44.functions.invoke('bukAssistant', { action: 'transcribe', audio_url: signed_url });
        const transcript = String((heardResponse && heardResponse.data && heardResponse.data.transcript) || '').trim();
        if (!transcript) {
          setNote(L('لم أسمع تذكيرًا واضحًا، أعد المحاولة.', 'I did not catch a clear reminder. Try again.'));
          return;
        }
        setHeard(transcript);

        const response = await base44.functions.invoke('bukAssistant', {
          action: 'assistant',
          agent: 'mypuki',
          text: `طلب تذكير منطوق: «${transcript}»`,
          local_now: new Date().toLocaleString('sv-SE').slice(0, 16),
          tz_name: Intl.DateTimeFormat().resolvedOptions().timeZone,
          offset_minutes: new Date().getTimezoneOffset()
        });
        const blocks = (response && response.data && response.data.blocks) || [];
        const reminder = blocks.find((block) => block.type === 'reminder');
        if (!reminder) {
          setNote(L('لم أتبيّن الوقت. قل مثلًا: ذكرني بأخذ الدواء الساعة ٩ مساءً.', 'I could not work out the time. Try: remind me to take my medicine at 9 pm.'));
          return;
        }
        setNote(`${L('تم ضبط التذكير', 'Reminder set')}: ${reminder.title} — ${formatTime(reminder.at)}`);
        announce(`${L('تم ضبط تذكيرك', 'Reminder set')}: ${reminder.title}. ${formatTime(reminder.at)}`, settings.assistant_voice, settings.voice_gender);
        if (onCreated) onCreated();
      } catch {
        setNote(L('تعذر تسجيل التذكير بالصوت الآن.', 'Could not record the reminder by voice right now.'));
      } finally {
        setBusy(false);
      }
    };
    recRef.current = recorder;
    recorder.start();
    setRecording(true);
  };

  return (
    <div className="mk-row">
      <span>🎙️ {L('تذكير بالنطق', 'Reminder by voice')}</span>
      <button type="button" className={recording ? 'mk-btn danger' : 'mk-btn soft'} onClick={toggle} disabled={busy}>
        {recording ? L('إيقاف', 'Stop') : busy ? '…' : L('انطق تذكيرك', 'Speak it')}
      </button>
      <p className="mk-hint">
        {L('قل مثلًا: ذكرني بالاجتماع الساعة ٦ مساءً، أو ذكرني بأخذ الدواء الساعة ٩ صباحًا.',
          'Say for example: remind me about the meeting at 6 pm, or remind me to take my medicine at 9 am.')}
      </p>
      {heard ? <p className="mk-hint">{L('سمعت', 'Heard')}: {heard}</p> : null}
      {note ? <p className="mk-hint">{note}</p> : null}
    </div>
  );
}