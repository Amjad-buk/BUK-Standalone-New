import React from 'react';
import { usePrefs } from '@/lib/prefs';
import { SUGGESTIONS } from '@/lib/buki';

/** اقتراحات سريعة تظهر قبل بدء المحادثة. */
export default function Suggestions({ onPick }) {
  const { isAr } = usePrefs();
  return (
    <div className="mk-sg">
      {SUGGESTIONS.map((item) => (
        <button key={item.en} type="button" onClick={() => onPick(isAr ? item.ar : item.en)}>
          {isAr ? item.ar : item.en}
        </button>
      ))}
    </div>
  );
}