import React, { useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { audioExtension } from '@/lib/speech';
import { dictationSupported, startDictation } from '@/lib/dictation';

/** صندوق الكتابة: اكتب أو اضغط المايك وتكلم، وماي بوكي يجيب. */
export default function BukiComposer({ busy, onSend, onStatus }) {
  const { L } = usePrefs();
  const [text, setText] = useState('');
  const [recording, setRecording] = useState(false);
  const areaRef = useRef(null);
  const recRef = useRef(null);
  const stopRef = useRef(null);

  const submit = (event) => {
    if (event) event.preventDefault();
    const value = text.trim();
    if (!value || busy) return;
    setText('');
    if (areaRef.current) areaRef.current.style.height = 'auto';
    onSend(value);
  };

  const grow = (element) => {
    element.style.height = 'auto';
    element.style.height = `${Math.min(element.scrollHeight, 120)}px`;
  };

  const onKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      submit(event);
    }
  };

  /** المسار الاحتياطي: تسجيل صوتي ثم تحويله إلى نص في الخادم (stored privately). */
  const recordAndTranscribe = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
      onStatus(L('هذا المتصفح لا يدعم المايكروفون، اكتب سؤالك.', 'This browser does not support the microphone — type your question.'));
      return;
    }

    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (error) {
      const denied = error && (error.name === 'NotAllowedError' || error.name === 'SecurityError');
      onStatus(denied
        ? L('اسمح للتطبيق باستخدام المايكروفون ثم اضغط المايك مرة أخرى.', 'Allow microphone access, then tap the mic again.')
        : L('تعذر تشغيل المايكروفون على هذا الجهاز.', 'Could not start the microphone on this device.'));
      return;
    }

    const recorder = new MediaRecorder(stream);
    const chunks = [];
    recorder.ondataavailable = (event) => {
      if (event.data && event.data.size) chunks.push(event.data);
    };
    recorder.onstop = async () => {
      stream.getTracks().forEach((track) => track.stop());
      setRecording(false);
      const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
      if (blob.size < 1200) {
        onStatus(L('التسجيل قصير جدًا، اضغط المايك وتكلّم ثم أوقف.', 'Recording too short — tap the mic, speak, then stop.'));
        return;
      }
      onStatus(L('جارٍ تحويل كلامك إلى نص…', 'Transcribing…'));
      try {
        const file = new File([blob], `buk-question-${Date.now()}.${audioExtension(blob.type)}`, { type: blob.type || 'audio/webm' });
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri });
        const response = await base44.functions.invoke('bukAssistant', { action: 'transcribe', audio_url: signed_url });
        const transcript = String((response && response.data && response.data.transcript) || '').trim();
        if (!transcript) {
          onStatus(L('لم أسمع سؤالك، جرّب مرة أخرى.', 'I did not catch that. Try again.'));
          return;
        }
        onStatus('');
        onSend(transcript);
      } catch {
        onStatus(L('تعذر تحويل الكلام إلى نص.', 'Could not transcribe.'));
      }
    };
    recRef.current = recorder;
    recorder.start(250);
    setRecording(true);
    onStatus(L('أتحدث إليك… اضغط ⏹ عند الانتهاء.', 'Listening… tap ⏹ when done.'));
  };

  /** تحويل الكلام إلى نص مباشرة داخل المتصفح: الكلام يظهر في الصندوق ثم يُرسل. */
  const dictate = async () => {
    if (recording) {
      if (stopRef.current) {
        stopRef.current();
        stopRef.current = null;
        setRecording(false);
        return;
      }
      if (recRef.current && recRef.current.state !== 'inactive') recRef.current.stop();
      return;
    }

    if (!dictationSupported()) {
      await recordAndTranscribe();
      return;
    }

    setRecording(true);
    onStatus(L('تكلّم الآن… سأكتب كلامك هنا.', 'Speak now — your words appear here.'));
    stopRef.current = startDictation({
      lang: 'ar-SA',
      onPartial: (value) => setText(value),
      onFinal: (value) => {
        stopRef.current = null;
        setRecording(false);
        const clean = String(value || '').trim();
        if (!clean) {
          onStatus(L('لم أسمع صوتًا واضحًا، اضغط المايك وتكلّم مرة أخرى.', 'I did not hear anything clear — tap the mic and speak again.'));
          return;
        }
        if (busy) {
          onStatus(L('انتظر رد My Book ثم اضغط إرسال.', 'Wait for My Book to reply, then tap send.'));
          setText(clean);
          return;
        }
        onStatus('');
        setText('');
        if (areaRef.current) areaRef.current.style.height = 'auto';
        onSend(clean);
      },
      onError: (code) => {
        stopRef.current = null;
        setRecording(false);
        if (code === 'not-allowed' || code === 'service-not-allowed') {
          onStatus(L('اسمح للتطبيق باستخدام المايكروفون ثم اضغط المايك مرة أخرى.', 'Allow microphone access, then tap the mic again.'));
        } else if (code === 'no-speech') {
          onStatus(L('لم أسمع كلامًا، جرّب مرة أخرى.', 'I heard no speech — try again.'));
        } else if (code === 'network') {
          onStatus(L('تحتاج الأوامر الصوتية إلى إنترنت، تحقق من الاتصال.', 'Voice commands need internet — check your connection.'));
        } else {
          onStatus(L('تعذر الاستماع الآن، أعد المحاولة.', 'Could not listen right now — try again.'));
        }
      }
    });
  };

  return (
    <div className="mk-bar">
      <form className="mk-field" onSubmit={submit}>
        <button
          type="button"
          className={recording ? 'mk-round ghost rec' : 'mk-round ghost'}
          onClick={dictate}
          aria-label={L('تكلم وسؤالك يُرسل', 'Speak your question')}
        >
          {recording ? '⏹' : '🎙️'}
        </button>
        <textarea
          ref={areaRef}
          rows={1}
          value={text}
          disabled={busy}
          onChange={(event) => { setText(event.target.value); grow(event.target); }}
          onKeyDown={onKeyDown}
          placeholder={recording ? L('أتحدث إليك… اضغط ⏹ للإرسال', 'Listening… tap ⏹ to send') : L('اكتب أو تكلم، وMy Book يجيبك…', 'Type or speak, My Book answers…')}
        />
        <button type="submit" className="mk-round send" disabled={busy || !text.trim()} aria-label={L('إرسال', 'Send')}>↑</button>
      </form>
    </div>
  );
}