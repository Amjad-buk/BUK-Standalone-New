import React from 'react';
import { usePrefs } from '@/lib/prefs';

/** بطاقة موقع جغرافي مع خريطة مصغّرة ورابط لفتحه في الخرائط. */
export default function LocationCard({ data }) {
  const { L } = usePrefs();
  const lat = Number(data.lat || 0).toFixed(4);
  const lon = Number(data.lon || 0).toFixed(4);
  const pad = 0.02;
  const bbox = [Number(data.lon) - pad, Number(data.lat) - pad, Number(data.lon) + pad, Number(data.lat) + pad].join('%2C');
  const embed = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat}%2C${lon}`;
  const open = `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=15/${lat}/${lon}`;

  return (
    <div className="buki-card-mini">
      <b>📍 {data.label}</b>
      <div className="buk-small">{lat} , {lon}</div>
      <iframe title={data.label} className="buki-map" loading="lazy" src={embed} />
      <a className="buki-link" href={open} target="_blank" rel="noreferrer">{L('افتح في الخرائط', 'Open in maps')}</a>
    </div>
  );
}