import React from 'react';

/** بطاقة معلومات منظّمة (ملخص، قائمة، مقارنة). */
export default function InfoCard({ data }) {
  const lines = Array.isArray(data.lines) ? data.lines : [];
  return (
    <div className="buki-card-mini">
      {data.title ? <b>{data.title}</b> : null}
      {lines.length ? (
        <ul className="buki-lines">
          {lines.map((line, index) => <li key={index}>{line}</li>)}
        </ul>
      ) : null}
    </div>
  );
}