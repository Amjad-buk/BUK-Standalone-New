import React, { useState } from 'react';
import { usePrefs } from '@/lib/prefs';
import { speakAloud, voiceFor } from '@/lib/speech';

const OPTIONS = [
  { id: 'female', icon: '👩', ar: 'أنثى', en: 'Female' },
  { id: 'male', icon: '👨', ar: 'ذكر', en: 'Male' }
];

/** اختيار صوت ماي بوكي مع سماع نموذج فوري. */
export default function VoicePicker() {
  const { settings, update, L } = usePrefs();
  const [busy, setBusy] = useState(false);
  const current = settings.voice_gender === 'male' ? 'male' : 'female';

  const pick = async (id) => {
    await update({ voice_gender: id, assistant_voice: voiceFor(id) });
    setBusy(true);
    const sample = id === 'male'
      ? L('مرحبًا، أنا My Book بصوت ذكوري.', 'Hi, I am My Book, with a male voice.')
      : L('مرحبًا، أنا My Book بصوت أنثوي.', 'Hi, I am My Book, with a female voice.');
    await speakAloud(sample, 'ar', voiceFor(id), id);
    setBusy(false);
  };

  return (
    <div className="mk-row">
      <span>🗣 {L('صوت My Book', 'My Book voice')}</span>
      <div className="mk-seg">
        {OPTIONS.map((option) => (
          <button
            key={option.id}
            type="button"
            className={current === option.id ? 'on' : ''}
            onClick={() => pick(option.id)}
            disabled={busy}
          >
            {option.icon} {L(option.ar, option.en)}
          </button>
        ))}
      </div>
    </div>
  );
}