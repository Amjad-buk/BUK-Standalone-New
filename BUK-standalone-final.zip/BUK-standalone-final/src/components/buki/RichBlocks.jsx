import React from 'react';
import { usePrefs } from '@/lib/prefs';
import { LANG_LABELS } from '@/lib/buki';
import { formatTime } from '@/lib/chat';
import WeatherCard from '@/components/buki/WeatherCard';
import LocationCard from '@/components/buki/LocationCard';
import ImageCard from '@/components/buki/ImageCard';
import InfoCard from '@/components/buki/InfoCard';
import GreetingCard from '@/components/buki/GreetingCard';

/** يرسم الكتل الغنية التي يرسلها المساعد داخل المحادثة. */
export default function RichBlocks({ blocks }) {
  const { L } = usePrefs();
  if (!blocks || !blocks.length) return null;

  return (
    <div>
      {blocks.map((block, index) => {
        const key = `${block.type}-${index}`;
        if (block.type === 'weather') return <WeatherCard key={key} data={block} />;
        if (block.type === 'location') return <LocationCard key={key} data={block} />;
        if (block.type === 'image') return <ImageCard key={key} data={block} />;
        if (block.type === 'card') return <InfoCard key={key} data={block} />;
        if (block.type === 'greeting') return <GreetingCard key={key} data={block} />;
        if (block.type === 'reminder') {
          return (
            <div key={key} className="buki-chip">
              ⏰ {L('تم ضبط تذكير', 'Reminder set')}: <b>{block.title}</b> · {formatTime(block.at)}
            </div>
          );
        }
        if (block.type === 'translation') {
          return (
            <div key={key} className="buki-trans">
              <b>🌐 {L('ترجمة حية', 'Live translation')} — {LANG_LABELS[block.target] || block.target}</b>
              <p>{block.text}</p>
            </div>
          );
        }
        return null;
      })}
    </div>
  );
}