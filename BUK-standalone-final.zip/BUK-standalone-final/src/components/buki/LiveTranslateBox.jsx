import React, { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { speakAloud, audioExtension } from '@/lib/speech';
import { TRANSLATE_LANGS } from '@/lib/buki';

/** مربع الترجمة الحية: تتكلم بلغتك، وتسمع الترجمة منطوقة بصوت ماي بوكي. */
export default function LiveTranslateBox({ enabled, onToggle, source, onSource, target, onTarget, onStatus }) {
  const { settings, isAr, L } = usePrefs();
  const [session, setSession] = useState(null);
  const [recording, setRecording] = useState(false);
  const [busy, setBusy] = useState(false);
  const recRef = useRef(null);

  useEffect(() => () => {
    if (recRef.current && recRef.current.state === 'recording') recRef.current.stop();
  }, []);

  const nameOf = (code) => {
    const found = TRANSLATE_LANGS.find((lang) => lang.id === code);
    return found ? (isAr ? found.ar : found.en) : code;
  };

  const run = async (blob) => {
    setBusy(true);
    onStatus(L('جارٍ فهم الكلام وترجمته…', 'Understanding and translating…'));
    try {
      const file = new File([blob], `buk-live-${Date.now()}.${audioExtension(blob.type)}`, { type: blob.type });
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri });
      const heard = await base44.functions.invoke('bukAssistant', { action: 'transcribe', audio_url: signed_url });
      const heardText = String((heard && heard.data && heard.data.transcript) || '').trim();
      if (!heardText) {
        onStatus(L('لم أسمع كلامًا واضحًا، أعد المحاولة.', 'I did not catch clear speech. Try again.'));
        return;
      }
      const translated = await base44.functions.invoke('bukAssistant', { action: 'translate', text: heardText, source, target });
      const out = String((translated && translated.data && translated.data.translation) || '').trim();
      if (!out) {
        onStatus(L('تعذرت الترجمة الآن، أعد المحاولة.', 'Translation failed. Try again.'));
        return;
      }
      setSession({ heard: heardText, out });
      onStatus('');
      const spoken = await speakAloud(out, target, settings.assistant_voice, settings.voice_gender);
      if (!spoken) onStatus(L('ظهرت الترجمة مكتوبة، لكن تعذر تشغيل الصوت على هذا الجهاز.', 'Translation shown, but audio did not play on this device.'));
    } catch {
      onStatus(L('تعذر إتمام الترجمة الصوتية الآن.', 'Could not complete voice translation right now.'));
    } finally {
      setBusy(false);
    }
  };

  const toggle = async () => {
    if (recording) {
      if (recRef.current) recRef.current.stop();
      return;
    }
    if (busy) return;
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      onStatus(L('التسجيل غير مدعوم على هذا الجهاز.', 'Recording is not supported on this device.'));
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks = [];
      recorder.ondataavailable = (event) => { if (event.data && event.data.size) chunks.push(event.data); };
      recorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        setRecording(false);
        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if (blob.size) run(blob);
        else onStatus(L('لم يتم تسجيل صوت، أعد المحاولة.', 'Nothing was recorded. Try again.'));
      };
      recRef.current = recorder;
      recorder.start();
      setRecording(true);
      onStatus('');
    } catch {
      onStatus(L('تعذر الوصول إلى الميكروفون.', 'Could not open the microphone.'));
    }
  };

  return (
    <section className="mk-tr">
      <div className="mk-tr-head">
        <span>🌐 {L('الترجمة الحية', 'Live translation')}</span>
        <input className="mk-switch" type="checkbox" checked={enabled} onChange={(event) => onToggle(event.target.checked)} />
      </div>

      <p className="mk-tr-hint">
        {enabled
          ? L('اتكلم بلغتك واضغط «إنهاء الكلام»، وستسمع الترجمة منطوقة فورًا.', 'Speak your language and tap “finish speaking” — you hear the translation right away.')
          : L('الترجمة متوقفة. فعّلها من المفتاح بالأعلى.', 'Translation is off. Turn it on with the switch above.')}
      </p>

      {enabled ? (
        <>
          <div className="mk-tr-row">
            <select className="mk-select" value={source} onChange={(event) => onSource(event.target.value)}>
              {TRANSLATE_LANGS.map((lang) => (
                <option key={lang.id} value={lang.id}>{L(lang.ar, lang.en)}</option>
              ))}
            </select>
            <span>→</span>
            <select className="mk-select" value={target} onChange={(event) => onTarget(event.target.value)}>
              {TRANSLATE_LANGS.map((lang) => (
                <option key={lang.id} value={lang.id}>{L(lang.ar, lang.en)}</option>
              ))}
            </select>
          </div>

          <button type="button" className={recording ? 'mk-tr-mic rec' : 'mk-tr-mic'} onClick={toggle} disabled={busy}>
            {recording ? L('⏹ إنهاء الكلام', '⏹ Finish speaking') : busy ? '…' : L('🎙️ اتكلم لتُترجم', '🎙️ Speak to translate')}
          </button>

          {session ? (
            <div className="mk-tr-out">
              <b>{nameOf(target)}</b>
              <p>{session.out}</p>
              <span className="mk-tr-src">{nameOf(source)}: {session.heard}</span>
              <button
                type="button"
                className="mk-btn soft"
                onClick={() => speakAloud(session.out, target, settings.assistant_voice, settings.voice_gender)}
              >
                🔊 {L('اسمع الترجمة', 'Play translation')}
              </button>
            </div>
          ) : null}
        </>
      ) : null}
    </section>
  );
}