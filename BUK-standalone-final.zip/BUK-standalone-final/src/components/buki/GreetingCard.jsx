import React from 'react';
import { Image } from '@/components/ui/image';
import { usePrefs } from '@/lib/prefs';
import { speakAloud } from '@/lib/speech';

/** كرت معايدة يولّده My Buki: خلفية مزخرفة مع نص التهنئة والمناسبة. */
export default function GreetingCard({ data }) {
  const { settings, L } = usePrefs();
  const greeting = [data.title, data.message].filter(Boolean).join('. ');

  return (
    <div className="buki-greeting">
      {data.background ? <Image src={data.background} className="buki-greeting-bg" fittingType="fill" alt="" /> : null}
      <div className="buki-greeting-body">
        {data.occasion ? <span className="buki-greeting-tag">🎉 {data.occasion}</span> : null}
        {data.title ? <b>{data.title}</b> : null}
        {data.message ? <p>{data.message}</p> : null}
        <button
          type="button"
          className="buki-tool"
          onClick={() => speakAloud(greeting, 'ar', settings.assistant_voice, settings.voice_gender)}
        >
          🔊 {L('اسمع التهنئة', 'Play the greeting')}
        </button>
      </div>
    </div>
  );
}