import React from 'react';
import { Image } from '@/components/ui/image';
import { usePrefs } from '@/lib/prefs';

/** بطاقة صورة مولّدة بالذكاء الاصطناعي. */
export default function ImageCard({ data }) {
  const { L } = usePrefs();
  return (
    <div className="buki-card-mini">
      <Image src={data.url} alt={data.prompt || 'My Buki'} fittingType="fit" className="w-full rounded-xl" />
      <div className="buk-small">{L('صورة مولّدة بالذكاء الاصطناعي', 'AI-generated image')}</div>
      <a className="buki-link" href={data.url} target="_blank" rel="noreferrer">{L('فتح الصورة', 'Open image')}</a>
    </div>
  );
}