import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { playTone, REMINDER_TONES as TONES } from '@/lib/tone';

/** ضبط تذكير جديد: العنوان والوقت والتكرار والنغمة. */
export default function ReminderForm({ onCreated }) {
  const { user, settings, update, L } = usePrefs();
  const [title, setTitle] = useState('');
  const [at, setAt] = useState('');
  const [repeat, setRepeat] = useState('none');
  const [status, setStatus] = useState('');
  const [alertsOn, setAlertsOn] = useState(typeof Notification !== 'undefined' && Notification.permission === 'granted');

  const submit = async (event) => {
    event.preventDefault();
    const name = title.trim();
    if (!name || !at) { setStatus(L('اكتب عنوان التذكير ووقته.', 'Enter the reminder title and time.')); return; }
    await base44.entities.Reminder.create({
      owner_id: user.id,
      title: name,
      at: new Date(at).toISOString(),
      repeat,
      tone: settings.reminder_tone,
      status: 'scheduled',
      alerted: false
    });
    setTitle('');
    setAt('');
    setStatus(L('تم ضبط التذكير وسيرنّ في وقته.', 'Reminder set — it will ring on time.'));
    if (onCreated) onCreated();
  };

  const enableAlerts = async () => {
    if (typeof Notification === 'undefined') {
      setStatus(L('هذا المتصفح لا يدعم التنبيه خارج التطبيق.', 'This browser does not support out-of-app alerts.'));
      return;
    }
    const result = await Notification.requestPermission();
    setAlertsOn(result === 'granted');
    setStatus(result === 'granted'
      ? L('تم تفعيل التنبيه خارج التطبيق.', 'Out-of-app alerts enabled.')
      : L('لم يتم تفعيل الإشعارات.', 'Notifications were not enabled.'));
  };

  return (
    <form onSubmit={submit}>
      <div className="mk-row">
        <span>⏰ {L('تذكير جديد', 'New reminder')}</span>
      </div>
      <div className="mk-row">
        <input className="mk-input" value={title} onChange={(event) => setTitle(event.target.value)}
          placeholder={L('عنوان التذكير', 'Reminder title')} />
      </div>
      <div className="mk-row">
        <input className="mk-input" type="datetime-local" value={at} onChange={(event) => setAt(event.target.value)} />
      </div>
      <div className="mk-row">
        <span>{L('التكرار', 'Repeat')}</span>
        <select className="mk-select" value={repeat} onChange={(event) => setRepeat(event.target.value)}>
          <option value="none">مرة واحدة</option>
          <option value="daily">يوميًا</option>
          <option value="weekly">أسبوعيًا</option>
          <option value="monthly">شهريًا</option>
        </select>
      </div>
      <div className="mk-row">
        <span>{L('نغمة الرنين', 'Ring tone')}</span>
        <select className="mk-select" value={settings.reminder_tone}
          onChange={(event) => { update({ reminder_tone: event.target.value }); playTone(event.target.value); }}>
          {TONES.map((tone) => <option key={tone.id} value={tone.id}>{L(tone.ar, tone.en)}</option>)}
        </select>
      </div>
      <div className="mk-row">
        <span>{L('التنبيه خارج التطبيق', 'Out-of-app alert')}</span>
        <button type="button" className="mk-btn soft" onClick={enableAlerts}>
          {alertsOn ? L('مفعّل', 'Enabled') : L('تفعيل', 'Enable')}
        </button>
      </div>
      <button type="submit" className="mk-btn wide">{L('ضبط التذكير', 'Set reminder')}</button>
      {status ? <p className="mk-hint" style={{ marginTop: '8px' }}>{status}</p> : null}
    </form>
  );
}