import React from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { formatTime } from '@/lib/chat';
import { playTone } from '@/lib/tone';

const REPEATS = { none: 'مرة واحدة', daily: 'يوميًا', weekly: 'أسبوعيًا', monthly: 'شهريًا' };

/** التذكيرات القادمة مع الإكمال والحذف. */
export default function ReminderList({ reminders, onChanged }) {
  const { settings, L } = usePrefs();

  return (
    <div>
      <div className="mk-row">
        <span>📋 {L('التذكيرات القادمة', 'Upcoming reminders')}</span>
        {reminders.length ? null : (
          <button type="button" className="mk-btn soft" onClick={() => playTone(settings.reminder_tone)}>
            {L('تجربة النغمة', 'Test tone')}
          </button>
        )}
      </div>

      {reminders.length ? null : (
        <p className="mk-hint" style={{ margin: '0 2px 8px' }}>{L('لا تذكيرات مجدولة.', 'No scheduled reminders.')}</p>
      )}

      {reminders.map((reminder) => (
        <div key={reminder.id} className="mk-row">
          <div className="mk-grow">
            <b>{reminder.title}</b>
            <span>{formatTime(reminder.at)} · {REPEATS[reminder.repeat] || reminder.repeat}</span>
          </div>
          <button type="button" className="mk-btn soft"
            onClick={async () => { await base44.entities.Reminder.update(reminder.id, { status: 'done' }); onChanged(); }}>
            {L('تم', 'Done')}
          </button>
          <button type="button" className="mk-btn danger"
            onClick={async () => { await base44.entities.Reminder.delete(reminder.id); onChanged(); }}>
            {L('حذف', 'Delete')}
          </button>
        </div>
      ))}
    </div>
  );
}