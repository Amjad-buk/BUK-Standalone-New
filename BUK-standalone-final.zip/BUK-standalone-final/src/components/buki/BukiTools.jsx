import React from 'react';
import { usePrefs } from '@/lib/prefs';
import VoicePicker from '@/components/buki/VoicePicker';
import VoiceReminder from '@/components/buki/VoiceReminder';
import ReminderForm from '@/components/buki/ReminderForm';
import ReminderList from '@/components/buki/ReminderList';

/** لوحة أدوات ماي بوكي: الصوت، الترجمة الحية، والتذكيرات — بعيدًا عن شاشة المحادثة. */
export default function BukiTools({ open, onClose, reminders, onChanged, onRegenerate, onNewChat }) {
  const { L } = usePrefs();
  if (!open) return null;

  return (
    <div className="mk-sheet" onClick={onClose}>
      <div className="mk-panel" onClick={(event) => event.stopPropagation()}>
        <div className="mk-ph">
          <b>{L('أدوات My Book', 'My Book tools')}</b>
          <button type="button" className="mk-icon" onClick={onClose} title={L('إغلاق', 'Close')}>✕</button>
        </div>

        <VoicePicker />

        <VoiceReminder onCreated={onChanged} />
        <ReminderForm onCreated={onChanged} />
        <ReminderList reminders={reminders} onChanged={onChanged} />

        <div className="mk-row">
          <span>💬 {L('المحادثة', 'Conversation')}</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <button type="button" className="mk-btn soft wide" onClick={onRegenerate}>↻ {L('إعادة توليد آخر رد', 'Regenerate last reply')}</button>
          <button type="button" className="mk-btn soft wide" onClick={onNewChat}>＋ {L('محادثة جديدة', 'New chat')}</button>
        </div>

        <p className="mk-note">
          {L('التذكيرات محفوظة في حسابك، والرنين يعمل خارج شاشة التطبيق ما دام التطبيق مفتوحًا في الخلفية (مع نغمة BUK وإشعار النظام عند السماح به).',
            'Reminders are saved to your account, and ringing works outside the app screen while it runs in the background (BUK tone plus a system notification when allowed).')}
        </p>
      </div>
    </div>
  );
}