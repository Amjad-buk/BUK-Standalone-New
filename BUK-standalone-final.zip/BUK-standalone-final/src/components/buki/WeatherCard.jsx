import React from 'react';
import { usePrefs } from '@/lib/prefs';

/** بطاقة حالة الطقس التي يرسلها المساعد. */
export default function WeatherCard({ data }) {
  const { L } = usePrefs();
  return (
    <div className="buki-card-mini">
      <div className="buki-weather-top">
        <span style={{ fontSize: '2.2rem' }}>{data.icon}</span>
        <div>
          <b>{data.city}{data.country ? ` — ${data.country}` : ''}</b>
          <div className="buk-small">{data.desc}</div>
        </div>
        <div className="buki-weather-temp">{data.temp}°</div>
      </div>
      <div className="buki-weather-grid">
        <span>{L('الإحساس', 'Feels')}: {data.feels}°</span>
        <span>{L('الرطوبة', 'Humidity')}: {data.humidity}%</span>
        <span>{L('الرياح', 'Wind')}: {data.wind} {L('كم/س', 'km/h')}</span>
      </div>
      {Array.isArray(data.days) && data.days.length ? (
        <div className="buki-forecast">
          {data.days.map((day) => (
            <div key={day.date}>
              <div>{day.date.slice(5)}</div>
              <div style={{ fontSize: '1.2rem' }}>{day.icon}</div>
              <div>{day.max}° / {day.min}°</div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}