import React from 'react';
import ReactMarkdown from 'react-markdown';
import { usePrefs } from '@/lib/prefs';
import { parseData } from '@/lib/buki';
import RichBlocks from '@/components/buki/RichBlocks';

/** رسالة واحدة في محادثة ماي بوكي بأسلوب بسيط. */
export default function ChatMessage({ message, mine, onSpeak }) {
  const { L } = usePrefs();
  const blocks = mine ? [] : parseData(message.data);

  const copy = () => {
    if (navigator.clipboard) navigator.clipboard.writeText(message.content || '');
  };

  return (
    <div className={`m ${mine ? 'me' : 'as'}`}>
      <div className="bd">
        {message.content ? (
          mine
            ? <p className="bb">{message.content}</p>
            : <div className="bb"><ReactMarkdown>{message.content}</ReactMarkdown></div>
        ) : null}

        <RichBlocks blocks={blocks} />

        <div className="act">
          {!mine ? <button type="button" onClick={() => onSpeak && onSpeak()}>🔊 {L('استماع', 'Listen')}</button> : null}
          <button type="button" onClick={copy}>{L('نسخ', 'Copy')}</button>
        </div>
      </div>
    </div>
  );
}