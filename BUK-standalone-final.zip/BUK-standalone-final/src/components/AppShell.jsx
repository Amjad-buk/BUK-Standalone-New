import React, { useEffect } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { usePrefs } from '@/lib/prefs';
import { ensureProfile } from '@/lib/chat';
import { unlockAudio } from '@/lib/tone';
import { primeSpeech } from '@/lib/speech';
import { registerServiceWorker, ensureNotifyPermission } from '@/lib/notify';
import IncomingCall from '@/components/IncomingCall';
import ReminderAlarm from '@/components/ReminderAlarm';

const TABS = [
  { to: '/', icon: '⌂', ar: 'الرئيسية', en: 'Home' },
  { to: '/chats', icon: '💬', ar: 'المحادثات', en: 'Chats' },
  { to: '/friends', icon: '👥', ar: 'الأصدقاء', en: 'Friends' },
  { to: '/settings', icon: '⚙', ar: 'الإعدادات', en: 'Settings' }
];

/** إطار التطبيق بتصميم BUK: عمود بعرض 720 والشريط السفلي بأربع تبويبات. */
export default function AppShell() {
  const { user, L } = usePrefs();
  const { pathname } = useLocation();

  useEffect(() => {
    if (user) ensureProfile(user).catch(() => {});
  }, [user]);

  // مع أول لمسة: نفعّل الصوت والنطق ونطلب إذن الإشعارات — فلا يحتاج المستخدم لفعل أي شيء لاحقًا.
  useEffect(() => {
    registerServiceWorker();
    const events = ['pointerdown', 'touchstart', 'keydown'];
    const prime = () => {
      unlockAudio();
      primeSpeech();
      ensureNotifyPermission();
      events.forEach((name) => window.removeEventListener(name, prime));
    };
    events.forEach((name) => window.addEventListener(name, prime, { passive: true }));
    return () => events.forEach((name) => window.removeEventListener(name, prime));
  }, []);

  return (
    <div>
      <IncomingCall />
      <ReminderAlarm />
      <main className="buk-app">
        <Outlet />
      </main>

      <nav className="buk-tabs">
        {TABS.map((tab) => (
          <NavLink key={tab.to} to={tab.to} end={tab.to === '/'}>
            {({ isActive }) => (
              <button
                type="button"
                className={isActive || (tab.to !== '/' && pathname.startsWith(tab.to)) ? 'active' : ''}
              >
                <span>{tab.icon}</span>
                {L(tab.ar, tab.en)}
              </button>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}