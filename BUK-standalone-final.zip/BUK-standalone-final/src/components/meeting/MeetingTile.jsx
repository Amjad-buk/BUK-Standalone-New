import React, { useEffect, useRef, useState } from 'react';

/**
 * بلاطة مشارك في شاشة الاجتماع.
 * الصوت يبقى داخل عنصر الفيديو دائمًا حتى يُسمع المشارك ولو كانت كاميرته مغلقة،
 * ونعيد محاولة التشغيل مع كل لمسة لأن المتصفح يمنع الصوت قبل أول تفاعل في الصفحة
 * — وهذا سبب عدم سماع المضيف للضيوف عند دخوله من صفحة أخرى.
 */
export default function MeetingTile({ tile, pinned, compact, onPin }) {
  const videoRef = useRef(null);
  const [blocked, setBlocked] = useState(false);
  const videoTracks = tile.stream ? tile.stream.getVideoTracks() : [];
  // نعرض الصورة متى وصل مسار فيديو حقيقي، ولا نعتمد على إشارة الحالة وحدها
  // لأن تأخرها كان يُبقي المشارك صورة رمزية رغم وصول صورته.
  const showVideo = videoTracks.length > 0 && (tile.isMe ? tile.videoOn !== false : true);

  useEffect(() => {
    const element = videoRef.current;
    if (!element) return undefined;
    if (element.srcObject !== tile.stream) element.srcObject = tile.stream || null;
    if (!tile.stream) {
      setBlocked(false);
      return undefined;
    }

    let cancelled = false;
    const tryPlay = () => {
      const attempt = element.play();
      if (!attempt || !attempt.then) return;
      attempt
        .then(() => {
          if (!cancelled) setBlocked(false);
        })
        .catch(() => {
          if (!cancelled) setBlocked(true);
        });
    };

    tryPlay();
    const retry = () => tryPlay();
    document.addEventListener('pointerdown', retry);
    document.addEventListener('click', retry);
    document.addEventListener('touchstart', retry);

    return () => {
      cancelled = true;
      document.removeEventListener('pointerdown', retry);
      document.removeEventListener('click', retry);
      document.removeEventListener('touchstart', retry);
    };
  }, [tile.stream]);

  return (
    <div
      className={`mt-tile${pinned ? ' pinned' : ''}${compact ? ' compact' : ''}${tile.isMe && !tile.sharing ? ' mirror' : ''}`}
      onDoubleClick={() => onPin && onPin(tile.id)}
      title={onPin ? 'اضغط مرتين للتكبير أو التصغير' : undefined}
    >
      <video
        ref={videoRef}
        className={showVideo ? 'mt-video' : 'mt-video off'}
        autoPlay
        playsInline
        muted={!!tile.isMe}
      />
      {showVideo ? null : (
        <div className="mt-face">
          <span>{String(tile.name || '؟').slice(0, 1)}</span>
        </div>
      )}
      {blocked && !tile.isMe ? (
        <button
          type="button"
          className="mt-tap"
          onClick={() => {
            const element = videoRef.current;
            if (element) element.play().catch(() => {});
          }}
        >
          🔊 اضغط لتشغيل الصوت
        </button>
      ) : null}
      <div className="mt-tag">
        <span>{tile.mic ? '🎙️' : '🔇'}</span>
        <b>{tile.name}{tile.isMe ? ' (أنت)' : ''}</b>
        {tile.host ? <em>المضيف</em> : null}
        {tile.sharing ? <em>يشارك الشاشة</em> : null}
        {tile.mutedByHost ? <em className="warn">كتمه المضيف</em> : null}
        {tile.conn ? <em className="warn">{tile.conn === 'failed' ? 'انقطع الاتصال' : 'جارٍ الاتصال…'}</em> : null}
      </div>
    </div>
  );
}