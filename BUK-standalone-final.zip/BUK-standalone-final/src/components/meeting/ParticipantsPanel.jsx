import React from 'react';

/** لوحة المشاركين: المنشئ يكتم أو يحظر، ويمكنه رفع الحظر. */
export default function ParticipantsPanel({ participants, meId, isHost, blockedIds, onAction }) {
  return (
    <div className="mt-panel">
      <div className="mt-panel-head">
        <b>المشاركون ({participants.length})</b>
      </div>
      <div className="mt-panel-list">
        {participants.map((person) => {
          const isMe = person.id === meId;
          return (
            <div key={person.id} className="mt-person">
              <span className="mt-avatar">{String(person.name || '؟').slice(0, 1)}</span>
              <div className="mt-person-name">
                <b>{person.name}{isMe ? ' (أنت)' : ''}</b>
                <span>
                  {person.host ? 'المضيف · ' : ''}
                  {person.mic ? 'صوته مفتوح' : 'مكتوم'}
                  {person.sharing ? ' · يشارك الشاشة' : ''}
                </span>
              </div>
              {isHost && !isMe ? (
                <div className="mt-person-actions">
                  <button type="button" className="mt-mini" onClick={() => onAction(person.mic ? 'mute' : 'unmute', person.id)}>
                    {person.mic ? 'كتم الصوت' : 'إلغاء الكتم'}
                  </button>
                  <button type="button" className="mt-mini danger" onClick={() => onAction('block', person.id)}>
                    حظر وإخراج
                  </button>
                </div>
              ) : null}
            </div>
          );
        })}
        {!participants.length ? <p className="mt-empty">لا مشاركين بعد — أرسل الدعوة.</p> : null}
      </div>

      {isHost && blockedIds.length ? (
        <div className="mt-blocked">
          <b>المحظورون</b>
          {blockedIds.map((id) => (
            <div key={id} className="mt-person">
              <span className="mt-avatar">🚫</span>
              <div className="mt-person-name"><b>{id}</b><span>ممنوع من الدخول</span></div>
              <button type="button" className="mt-mini" onClick={() => onAction('unblock', id)}>رفع الحظر</button>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}