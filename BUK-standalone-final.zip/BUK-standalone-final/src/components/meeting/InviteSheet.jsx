import React from 'react';
import { inviteText, joinLink, mailUrl, smsUrl, whatsappUrl } from '@/lib/meeting';

/** دعوة الاجتماع: واتساب أو إيميل أو رسالة نصية SMS، ورابط يعمل لأي ضيف بلا حساب. */
export default function InviteSheet({ meeting, onClose }) {
  if (!meeting) return null;
  const text = inviteText(meeting);
  const link = joinLink(meeting.code);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(link);
    } catch {
      /* الحافظة غير متاحة */
    }
  };

  return (
    <div className="mt-sheet" onClick={onClose}>
      <div className="mt-sheet-card" onClick={(event) => event.stopPropagation()}>
        <div className="mt-sheet-head">
          <b>إرسال دعوة إلى «{meeting.title}»</b>
          <button type="button" className="mt-mini" onClick={onClose}>إغلاق</button>
        </div>

        <div className="mt-invite-grid">
          <a className="mt-invite wa" href={whatsappUrl(text)} target="_blank" rel="noreferrer">
            <span>🟢</span> واتساب
          </a>
          <a className="mt-invite mail" href={mailUrl(meeting, text)}>
            <span>✉️</span> إيميل
          </a>
          <a className="mt-invite sms" href={smsUrl(text)}>
            <span>💬</span> رسالة SMS
          </a>
        </div>

        <p className="mt-hint">
          الرابط يعمل خارج تطبيق BUK — يفتح الاجتماع لأي ضيف حتى لو لم يكن مسجلًا، بمجرد إدخال اسمه.
        </p>
        <div className="mt-link">
          <input readOnly value={link} dir="ltr" />
          <button type="button" className="mt-mini" onClick={copy}>نسخ</button>
        </div>
        <p className="mt-hint">رمز الاجتماع: <b dir="ltr">{meeting.code}</b></p>
      </div>
    </div>
  );
}