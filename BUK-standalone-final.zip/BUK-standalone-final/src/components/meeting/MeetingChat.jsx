import React, { useRef, useState } from 'react';
import { timeLabel } from '@/lib/meeting';

/** محادثة الاجتماع: نصوص، صور، ومستندات — والضغط مرتين على الصورة يكبّرها. */
export default function MeetingChat({ messages, meId, onSendText, onSendFile, onOpenImage }) {
  const [draft, setDraft] = useState('');
  const [error, setError] = useState('');
  const fileRef = useRef(null);

  const send = async (event) => {
    event.preventDefault();
    const value = draft.trim();
    if (!value) return;
    setDraft('');
    await onSendText(value);
  };

  const attach = async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = '';
    if (!file) return;
    setError('');
    const failed = await onSendFile(file);
    if (failed) setError('تعذر رفع الملف، جرّب ملفًا أصغر.');
  };

  return (
    <div className="mt-chat">
      <div className="mt-chat-list">
        {!messages.length ? <p className="mt-empty">أرسل صورة أو مستندًا أو رسالة لكل المشاركين.</p> : null}
        {messages.map((message) => (
          <div key={message.id} className={message.from === meId ? 'mt-msg mine' : 'mt-msg'}>
            <div className="mt-msg-head">
              <b>{message.from === meId ? 'أنت' : message.name}</b>
              <span>{timeLabel(message.at)}</span>
            </div>
            {message.kind === 'image' ? (
              <img
                src={message.media_url}
                alt={message.media_name || 'صورة'}
                onDoubleClick={() => onOpenImage(message.media_url)}
                title="اضغط مرتين للتكبير"
              />
            ) : null}
            {message.kind === 'file' ? (
              <a href={message.media_url} target="_blank" rel="noreferrer" className="mt-file">
                📄 {message.media_name || 'مستند'}
              </a>
            ) : null}
            {message.text ? <p>{message.text}</p> : null}
          </div>
        ))}
      </div>

      {error ? <p className="mt-error">{error}</p> : null}

      <form className="mt-chat-form" onSubmit={send}>
        <button type="button" className="mt-mini" onClick={() => fileRef.current && fileRef.current.click()}>
          📎
        </button>
        <input ref={fileRef} type="file" accept="image/*,.pdf,.doc,.docx,.txt,.xlsx,.pptx" hidden onChange={attach} />
        <input
          className="mt-chat-input"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder="اكتب رسالة…"
        />
        <button type="submit" className="mt-send">↑</button>
      </form>
    </div>
  );
}