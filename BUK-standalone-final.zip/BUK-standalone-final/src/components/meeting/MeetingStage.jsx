import React from 'react';
import MeetingTile from '@/components/meeting/MeetingTile';

/** توزيع الشاشات بنمط Messenger، مع تكبير أي مشارك بالضغط مرتين. */
export default function MeetingStage({ tiles, pinnedId, onPin }) {
  const pinned = tiles.find((tile) => tile.id === pinnedId);

  if (pinned) {
    const others = tiles.filter((tile) => tile.id !== pinnedId);
    return (
      <div className="mt-stage pinned">
        <MeetingTile tile={pinned} pinned onPin={() => onPin('')} />
        {others.length ? (
          <div className="mt-strip">
            {others.map((tile) => (
              <MeetingTile key={tile.id} tile={tile} compact onPin={() => onPin(tile.id)} />
            ))}
          </div>
        ) : null}
      </div>
    );
  }

  const count = tiles.length;
  const layout = count <= 1 ? 'mt-count-1' : count === 2 ? 'mt-count-2' : count <= 4 ? 'mt-count-4' : 'mt-count-many';

  return (
    <div className={`mt-stage ${layout}`}>
      {tiles.map((tile) => (
        <MeetingTile key={tile.id} tile={tile} onPin={onPin} />
      ))}
    </div>
  );
}