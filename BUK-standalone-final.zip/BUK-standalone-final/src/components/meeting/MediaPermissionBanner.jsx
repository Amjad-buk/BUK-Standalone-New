import React from 'react';

/** سبب دقيق بالعربية لكل خطأ من المتصفح عند طلب الكاميرا والميكروفون. */
const REASONS = {
  NotAllowedError:
    'المتصفح رفض إذن الكاميرا والميكروفون. اضغط «السماح الآن»؛ وإن لم تظهر نافذة الإذن فافتح أيقونة القفل بجانب العنوان واسمح للكاميرا والميكروفون.',
  SecurityError:
    'هذا المتصفح يمنع الكاميرا عند فتح الرابط من داخل تطبيق آخر (واتساب أو فيسبوك). افتح الرابط في Chrome أو Safari.',
  NotFoundError: 'لا توجد كاميرا أو ميكروفون متاح على هذا الجهاز.',
  NotReadableError: 'الكاميرا أو الميكروفون مستخدم من تطبيق آخر — أغلقه ثم أعد المحاولة.',
  OverconstrainedError: 'إعدادات الكاميرا غير مدعومة على هذا الجهاز — جرّب «تبديل الكاميرا».',
  UnsupportedError: 'هذا المتصفح لا يدعم المكالمات المرئية — استخدم Chrome أو Safari حديثًا.'
};

export default function MediaPermissionBanner({ mediaError, hasAudio, hasVideo, onRetry }) {
  const title =
    !hasAudio && !hasVideo
      ? 'لم يسمح المتصفح بالكاميرا والميكروفون'
      : !hasAudio
        ? 'ميكروفونك غير متاح'
        : 'كاميرتك مغلقة';

  return (
    <div className="mt-perm">
      <div>
        <b>{title}</b>
        <p>
          {REASONS[mediaError] || 'بقية المشاركين لن يسمعوك أو يروك قبل منح الإذن للكاميرا والميكروفون.'}
        </p>
      </div>
      <button type="button" className="buk-btn" onClick={onRetry}>السماح الآن</button>
    </div>
  );
}