import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { roomApi } from '@/lib/meeting';
import useMeetingRoom from '@/hooks/useMeetingRoom';
import MeetingStage from '@/components/meeting/MeetingStage';
import MeetingControls from '@/components/meeting/MeetingControls';
import MeetingChat from '@/components/meeting/MeetingChat';
import ParticipantsPanel from '@/components/meeting/ParticipantsPanel';
import InviteSheet from '@/components/meeting/InviteSheet';
import MediaPermissionBanner from '@/components/meeting/MediaPermissionBanner';

/** شاشة الاجتماع كاملة: المشاركون، التحكم، المحادثة والملفات، والدعوة. */
export default function MeetingExperience({ code, identity, onExit, exitPath = '/meeting', exitLabel = 'رجوع' }) {
  const room = useMeetingRoom({ code, identity });
  const [panel, setPanel] = useState('');
  const [invite, setInvite] = useState(false);
  const [pinnedId, setPinnedId] = useState('');
  const [lightbox, setLightbox] = useState('');
  const [seenCount, setSeenCount] = useState(0);

  const meeting = room.meeting;
  const participants = meeting?.participants || [];
  const messages = meeting?.chat || [];
  const isHost = !!meeting && meeting.host_id === identity.id;

  useEffect(() => {
    if (panel === 'chat') setSeenCount(messages.length);
  }, [messages.length, panel]);

  const unread = panel === 'chat' ? 0 : Math.max(0, messages.length - seenCount);

  const liveTracks = room.localStream ? room.localStream.getTracks().filter((track) => track.readyState === 'live') : [];
  const hasAudio = liveTracks.some((track) => track.kind === 'audio');
  const hasVideo = liveTracks.some((track) => track.kind === 'video');
  // الحالة الظاهرة أسفل الشاشات: تكشف مكان التعطّل بدقة (إذن الجهاز أو الشبكة أو الإشارات).
  const peerStates = Object.values(room.peerStates);
  const peerOnline = peerStates.length > 0 && peerStates.every((state) => state === 'connected');

  const tiles = useMemo(() => {
    const mine = {
      id: identity.id,
      name: identity.name,
      stream: room.localStream,
      videoOn: room.sharing || room.camOn,
      isMe: true,
      mic: room.micOn && !room.mutedByHost,
      host: isHost,
      sharing: room.sharing,
      mutedByHost: room.mutedByHost
    };
    const others = participants
      .filter((person) => person.id !== identity.id)
      .map((person) => ({
        id: person.id,
        name: person.name,
        stream: room.peers[person.id],
        conn: room.peerStates[person.id] === 'connected' ? '' : room.peerStates[person.id] || 'connecting',
        videoOn: !!person.cam || !!person.sharing,
        isMe: false,
        mic: person.mic,
        host: person.host,
        sharing: person.sharing,
        mutedByHost: person.mutedByHost
      }));
    return [mine, ...others];
  }, [participants, room.peers, room.peerStates, room.localStream, room.camOn, room.sharing, room.micOn, room.mutedByHost, identity.id, identity.name, isHost]);

  const sendText = async (text) => {
    await roomApi('chat', { code, from: identity.id, name: identity.name, kind: 'text', text });
    room.refresh();
  };

  const sendFile = async (file) => {
    try {
      const isImage = String(file.type || '').startsWith('image/');
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri, expires_in: 43200 });
      await roomApi('chat', {
        code,
        from: identity.id,
        name: identity.name,
        kind: isImage ? 'image' : 'file',
        media_url: signed_url,
        media_name: file.name
      });
      room.refresh();
      return false;
    } catch {
      return true;
    }
  };

  const leave = async () => {
    if (isHost) {
      if (!window.confirm('إنهاء الاجتماع يخرج كل المشاركين. متابعة؟')) return;
      await room.hostAction('end', '');
    }
    if (onExit) onExit();
    else window.location.assign(exitPath);
  };

  if (room.blocked) {
    return (
      <div className="mt-gate">
        <div className="mt-gate-card">
          <h1>تم منعك من هذا الاجتماع</h1>
          <p>قام منشئ الاجتماع بحظرك. تواصل معه لرفع الحظر عن الدخول.</p>
          <button type="button" className="buk-btn wide" onClick={() => (onExit ? onExit() : window.location.assign(exitPath))}>{exitLabel}</button>
        </div>
      </div>
    );
  }

  if (room.ended) {
    return (
      <div className="mt-gate">
        <div className="mt-gate-card">
          <h1>انتهى الاجتماع</h1>
          <p>شكرًا لمشاركتك. يمكنك الانضمام مجددًا إذا أعاد المنشئ فتح الغرفة.</p>
          <button type="button" className="buk-btn wide" onClick={() => (onExit ? onExit() : window.location.assign(exitPath))}>{exitLabel}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-room">
      <header className="mt-head">
        <div className="mt-head-text">
          <b>{meeting?.title || 'اجتماع BUK'}</b>
          <span className="mt-code">{code} · {tiles.length} من 12 مشارك{room.joined ? '' : ' · جارٍ الدخول…'}</span>
        </div>
        {isHost ? (
          <button type="button" className="mt-mini" onClick={() => setInvite(true)}>دعوة</button>
        ) : null}
      </header>

      <MeetingStage tiles={tiles} pinnedId={pinnedId} onPin={setPinnedId} />

      <div className="mt-diag">
        <span>{hasVideo ? '🎥 الكاميرا تعمل' : '🎥 الكاميرا مطفأة'}</span>
        <span>{hasAudio ? '🎙️ الصوت يعمل' : '🎙️ الصوت مطفأ'}</span>
        {room.mediaError ? <span className="warn">منع المتصفح: {room.mediaError}</span> : null}
        <span className={peerOnline ? '' : 'warn'}>
          {peerStates.length ? `الشبكة: ${peerStates.join(' · ')}` : 'لا يوجد مشاركون بعد'}
        </span>
        <span className="warn">إشارات: {room.signalCount}</span>
      </div>

      {room.mutedByHost ? <div className="mt-notice warn">المضيف كتم صوتك — يمكنك إلغاء الكتم بنفسك لكنه قد يكتّمك مجددًا.</div> : null}
      {room.sharing ? <div className="mt-notice">أنت تشارك شاشتك الآن.</div> : null}
      {room.notice ? <div className="mt-notice">{room.notice}</div> : null}
      {room.mediaAsked && (!hasAudio || !hasVideo) ? (
        <MediaPermissionBanner
          mediaError={room.mediaError}
          hasAudio={hasAudio}
          hasVideo={hasVideo}
          onRetry={room.retryMedia}
        />
      ) : null}

      {panel === 'people' ? (
        <ParticipantsPanel
          participants={participants}
          meId={identity.id}
          isHost={isHost}
          blockedIds={meeting?.blocked_ids || []}
          onAction={(mode, targetId) => room.hostAction(mode, targetId)}
        />
      ) : null}

      {panel === 'chat' ? (
        <MeetingChat
          messages={messages}
          meId={identity.id}
          onSendText={sendText}
          onSendFile={sendFile}
          onOpenImage={setLightbox}
        />
      ) : null}

      <MeetingControls
        micOn={room.micOn}
        camOn={room.camOn}
        sharing={room.sharing}
        isHost={isHost}
        peopleCount={tiles.length}
        chatUnread={unread}
        onMic={room.toggleMic}
        onCam={room.toggleCam}
        onFlip={room.switchCamera}
        onShare={room.toggleShare}
        onPeople={() => setPanel(panel === 'people' ? '' : 'people')}
        onChat={() => setPanel(panel === 'chat' ? '' : 'chat')}
        onInvite={() => setInvite(true)}
        onLeave={leave}
      />

      {invite ? (
        <InviteSheet meeting={meeting || { code, title: 'اجتماع BUK' }} onClose={() => setInvite(false)} />
      ) : null}

      {lightbox ? (
        <div className="mt-lightbox" onClick={() => setLightbox('')}>
          <img src={lightbox} alt="صورة مكبّرة" />
        </div>
      ) : null}
    </div>
  );
}