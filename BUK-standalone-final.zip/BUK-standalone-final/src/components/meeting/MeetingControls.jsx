import React from 'react';

/** شريط أدوات الاجتماع: الصوت، الكاميرا، تبديل الكاميرا، الشاشة، المشاركون، المحادثة، الدعوة، الخروج. */
export default function MeetingControls({
  micOn,
  camOn,
  sharing,
  isHost,
  peopleCount,
  chatUnread,
  onMic,
  onCam,
  onFlip,
  onShare,
  onPeople,
  onChat,
  onInvite,
  onLeave
}) {
  return (
    <div className="mt-bar">
      <button type="button" className={micOn ? 'mt-ctrl' : 'mt-ctrl off'} onClick={onMic}>
        <span>{micOn ? '🎙️' : '🔇'}</span>
        {micOn ? 'كتم' : 'تشغيل الصوت'}
      </button>
      <button type="button" className={camOn ? 'mt-ctrl' : 'mt-ctrl off'} onClick={onCam}>
        <span>{camOn ? '🎥' : '📷'}</span>
        {camOn ? 'إيقاف الكاميرا' : 'تشغيل الكاميرا'}
      </button>
      <button type="button" className="mt-ctrl" onClick={onFlip}>
        <span>🔄</span>
        تبديل الكاميرا
      </button>
      <button type="button" className={sharing ? 'mt-ctrl on' : 'mt-ctrl'} onClick={onShare}>
        <span>🖥️</span>
        {sharing ? 'إيقاف الشاشة' : 'مشاركة الشاشة'}
      </button>
      <button type="button" className="mt-ctrl" onClick={onPeople}>
        <span>👥</span>
        المشاركون ({peopleCount})
      </button>
      <button type="button" className="mt-ctrl" onClick={onChat}>
        <span>💬</span>
        المحادثة
        {chatUnread ? <i className="mt-dot">{chatUnread}</i> : null}
      </button>
      {isHost ? (
        <button type="button" className="mt-ctrl" onClick={onInvite}>
          <span>✉️</span>
          دعوة
        </button>
      ) : null}
      <button type="button" className="mt-ctrl danger" onClick={onLeave}>
        <span>⏻</span>
        {isHost ? 'إنهاء الاجتماع' : 'خروج'}
      </button>
    </div>
  );
}