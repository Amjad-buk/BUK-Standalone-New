import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Lock, Eye, EyeOff } from "lucide-react";

/** حقل كلمة مرور مع زر لإظهار/إخفاء الكلمة. */
export default function PasswordInput({
  id,
  value,
  onChange,
  autoComplete = "current-password",
  placeholder = "••••••••",
  ...rest
}) {
  const [shown, setShown] = useState(false);

  return (
    <div className="relative">
      <Lock className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
      <Input
        id={id}
        type={shown ? "text" : "password"}
        autoComplete={autoComplete}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="ps-10 pe-11 h-12"
        required
        {...rest}
      />
      <button
        type="button"
        onClick={() => setShown((prev) => !prev)}
        aria-label={shown ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
        title={shown ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
        className="absolute end-2 top-1/2 -translate-y-1/2 grid place-items-center w-9 h-9 rounded-lg text-muted-foreground hover:text-foreground transition-colors"
      >
        {shown ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>
    </div>
  );
}