import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Phone, Loader2 } from "lucide-react";
import PasswordInput from "@/components/auth/PasswordInput";
import { isPhoneLike } from "@/lib/phone";

/** تسجيل الدخول برقم الهاتف وكلمة المرور. */
export default function PhoneLoginForm({ returnTo }) {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!isPhoneLike(phone)) {
      setError("أدخل رقم هاتف صحيحًا");
      return;
    }
    setLoading(true);
    try {
      const response = await base44.functions.invoke("phoneLogin", { phone, password });
      const token = response && response.data && response.data.access_token;
      if (!token) {
        setError("رقم الهاتف أو كلمة المرور غير صحيحة");
        return;
      }
      base44.auth.setToken(token);
      window.location.href = returnTo;
    } catch (err) {
      setError("رقم الهاتف أو كلمة المرور غير صحيحة");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="phone">رقم الهاتف</Label>
        <div className="relative">
          <Phone className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
          <Input
            id="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            autoFocus
            dir="ltr"
            placeholder="+962 79 000 0000"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="ps-10 h-12"
            required
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="phone-password">كلمة المرور</Label>
        <PasswordInput
          id="phone-password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 me-2 animate-spin" />
            جارٍ الدخول…
          </>
        ) : (
          "تسجيل الدخول"
        )}
      </Button>
      <p className="text-center text-xs text-muted-foreground">
        دخول الهاتف يعمل بعد إضافة رقم هاتفك في ملفك الشخصي أو عند إنشاء حساب جديد.
      </p>
    </form>
  );
}