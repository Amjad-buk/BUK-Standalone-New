import React, { useEffect, useState } from 'react';
import BukLogo from '@/components/BukLogo';
import { usePrefs } from '@/lib/prefs';

const alreadyShown = () => {
  try {
    return localStorage.getItem('buk.splash.done') === '1';
  } catch {
    return false;
  }
};

const rememberShown = () => {
  try {
    localStorage.setItem('buk.splash.done', '1');
  } catch {
    /* التخزين غير متاح — نكمل بدون حجب */
  }
};

const FEATURES = [
  { icon: '💬', ar: 'رسائل ومكالمات', en: 'Messages & calls' },
  { icon: '✨', ar: 'My Book الذكي', en: 'My Book AI' },
  { icon: '🌐', ar: 'ترجمة فورية', en: 'Live translation' },
  { icon: '🎥', ar: 'اجتماعات ومشاركة', en: 'Meetings & sharing' }
];

/**
 * شاشة الترحيب: تُعرض مرة واحدة لزائر جديد بتصميم متطور يعرض هوية BUK
 * وميزاته الأساسية فورًا (بدون شاشة تحميل)، مع زر «ابدأ الآن» وتخطٍّ تلقائي.
 */
export default function SplashGate({ children }) {
  const { settings, update } = usePrefs();
  // رابط دعوة الاجتماع يفتح الغرفة مباشرة لضيف جديد دون شاشة ترحيب.
  const [open, setOpen] = useState(() => !alreadyShown() && !window.location.pathname.startsWith('/join/'));
  const [lang, setLang] = useState(settings.language === 'en' ? 'en' : 'ar');
  const isAr = lang !== 'en';

  const finish = (chosen) => {
    rememberShown();
    setOpen(false);
    if (chosen && chosen !== settings.language) update({ language: chosen }).catch(() => {});
  };

  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => finish(lang), 4000);
    return () => clearTimeout(timer);
  }, [open, lang]);

  if (!open) return children;

  return (
    <div className="welcome-gate" dir={isAr ? 'rtl' : 'ltr'}>
      <span className="welcome-glow one" />
      <span className="welcome-glow two" />

      <div className="welcome-card">
        <BukLogo size={150} className="buk-logo-mark" rounded="30px" />
        <h1 className="welcome-name">BUK</h1>
        <p className="buk-muted">
          {isAr
            ? 'تواصل بلا حدود — رسائل ومكالمات ومساعد ذكي في تطبيق واحد.'
            : 'Connect without limits — messaging, calls and a smart assistant in one app.'}
        </p>

        <div className="welcome-features">
          {FEATURES.map((feature) => (
            <div key={feature.en} className="welcome-feature">
              <span>{feature.icon}</span>
              {isAr ? feature.ar : feature.en}
            </div>
          ))}
        </div>

        <div className="welcome-langs">
          <button type="button" className={`buk-btn ${lang === 'ar' ? '' : 'secondary'}`} onClick={() => setLang('ar')}>
            العربية
          </button>
          <button type="button" className={`buk-btn ${lang === 'en' ? '' : 'secondary'}`} onClick={() => setLang('en')}>
            English
          </button>
        </div>

        <button type="button" className="buk-btn wide" style={{ marginTop: '14px' }} onClick={() => finish(lang)}>
          {isAr ? 'ابدأ الآن' : 'Get started'}
        </button>
        <div className="buk-small">{isAr ? 'وإن لم تضغط، نتابع تلقائيًا بعد لحظات.' : 'Continuing automatically in a moment.'}</div>
      </div>
    </div>
  );
}