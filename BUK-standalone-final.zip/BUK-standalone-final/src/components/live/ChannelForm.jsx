import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePrefs } from '@/lib/prefs';
import { handleFor } from '@/lib/live';
import { Image } from '@/components/ui/image';

/** إنشاء قناة BUK مباشر أو تعديل بياناتها: الاسم والمعرّف والوصف والصورة. */
export default function ChannelForm({ channel, onSaved }) {
  const { user, L } = usePrefs();
  const [name, setName] = useState(channel?.name || '');
  const [description, setDescription] = useState(channel?.description || '');
  const [avatar, setAvatar] = useState(null);
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(!channel);

  if (channel && !editing) {
    return (
      <button type="button" className="buk-btn secondary" onClick={() => setEditing(true)}>
        {L('تعديل بيانات القناة', 'Edit channel details')}
      </button>
    );
  }

  const save = async () => {
    const clean = name.trim();
    if (!clean || busy) return;
    setBusy(true);
    setStatus(L('جارٍ الحفظ…', 'Saving…'));
    let avatarUrl = channel?.avatar_url || '';
    if (avatar) {
      const uploaded = await base44.integrations.Core.UploadPublicFile({ file: avatar }).catch(() => ({}));
      if (uploaded.file_url) avatarUrl = uploaded.file_url;
    }
    const payload = {
      name: clean,
      handle: channel?.handle || handleFor(clean),
      description: description.trim(),
      avatar_url: avatarUrl
    };
    if (channel) {
      await base44.entities.LiveChannel.update(channel.id, payload);
    } else {
      await base44.entities.LiveChannel.create({
        ...payload,
        owner_id: user.id,
        owner_name: user.full_name || user.email || 'صاحب القناة'
      });
    }
    setBusy(false);
    setStatus('');
    setEditing(false);
    if (onSaved) onSaved();
  };

  return (
    <div>
      <label className="buk-muted">{L('اسم القناة', 'Channel name')}</label>
      <input className="buk-field" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} placeholder={L('مثلاً: قناة أحمد', 'e.g. Ahmed channel')} />
      <label className="buk-muted">{L('وصف القناة', 'Channel description')}</label>
      <input className="buk-field" maxLength={160} value={description} onChange={(e) => setDescription(e.target.value)} placeholder={L('عن ماذا تبث؟', 'What do you stream about?')} />
      <label className="buk-muted">{L('صورة القناة', 'Channel picture')}</label>
      <input className="buk-field" type="file" accept="image/*" onChange={(e) => setAvatar(e.target.files && e.target.files[0])} />
      {channel?.avatar_url ? (
        <div className="buk-avatar round" style={{ marginTop: 10 }}>
          <Image src={channel.avatar_url} alt="" fittingType="fill" className="w-full h-full" />
        </div>
      ) : null}
      <button type="button" className="buk-btn wide" style={{ marginTop: 10 }} onClick={save} disabled={busy}>
        {channel ? L('حفظ التعديلات', 'Save changes') : L('إنشاء القناة', 'Create channel')}
      </button>
      {status ? <p className="buk-small">{status}</p> : null}
    </div>
  );
}